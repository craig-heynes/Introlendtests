SET FOREIGN_KEY_CHECKS=0;
set SQL_SAFE_UPDATES=0;
update core_estaleauser set password = 'InMHB7TC8qL1bmo3+mXYXvsoi4o=';

-- stub
-- update smn_associated_firm set firm_id = 12 where adviser_id = 157425;
-- update smn_firm set reference_id = 50210, reference_type = 'BUYER_ID' where id = 12;
-- update core_estaleauser set email = 'mtstage1+90000@gmail.com' where id = 193;
-- update smn_firm set reference_id = null where reference_id not in (50210);

-- actual
-- update smn_associated_firm set firm_id = 12 where adviser_id = 157425;
-- update smn_firm set reference_id = 1389, reference_type = 'BUYER_ID' where id = 12;
-- update core_estaleauser set email = 'mtstage1+90000@gmail.com' where id = 193;
-- update smn_firm set reference_id = null where reference_id not in (1389);

-- test
update smn_associated_firm set firm_id = 12 where adviser_id = 157425;-- 
update smn_firm set reference_id = 1, reference_type = 'BUYER_ID' where id = 12;
update core_estaleauser set email = 'mtstage1+90001@gmail.com' where id = 193;
update smn_firm set reference_id = null where reference_id not in (1);

update core_estaleauser set verified = 1;

-- setting all smart mails off by default
-- update dest_app_config set system_property_value = 'false'
-- where system_property_function = 'SMART_EMAIL' 
-- and data_type = 'BOOLEAN';

UPDATE core_email_definition SET enabled = false WHERE unique_id in ("email.credit.refresh",
                                                                    "email.member.birthday",
                                                                    "email.member.anniversary",
                                                                    "email.credit.score.change",
                                                                    "email.member.ccm.alert",
                                                                    "email.member.credit.card.expiry",
                                                                    "email.member.alert.link.reminder",
                                                                    "email.essential.member.upgrade.premium",
                                                                    "email.elite.upgrade.welcome",
                                                                    "email.member.home.value.analysis"
);


update QRTZ_TRIGGERS set trigger_state = 'PAUSED' where trigger_name in ('credit_refresh_email_sender_job_trigger', 'credit_report_inquiry_email_sender_job_trigger', 'credit_score_changed_email_sender_job_trigger'
'credit_summary_email_sender_job_trigger', 'debt_consolidation_email_sender_job_trigger', 'home_value_email_sender_job_trigger', 'link_email_and_phone_reminder_email_sender_job_trigger',
'member_anniversary_email_sender_job_trigger', 'member_birthday_email_sender_job_trigger', 'member_credit_card_expiry_email_sender_job_trigger', 'member_credit_prime_email_sender_job_trigger',
'member_credit_sub_prime_email_sender_job_trigger', 'member_email_verify_email_sender_job_trigger', 'member_inactive_email_sender_job_trigger', 'member_verify_phone_email_sender_job_trigger', 
'member_winback_email_sender_job_trigger', 'premium_upgrade_email_sender_job_trigger');


##reset email sending preferences to "Off"
delete from smn_email_preference;
update smn_email_definition_options set default_email_frequency = 'Off';

set SQL_SAFE_UPDATES=1;
SET FOREIGN_KEY_CHECKS=1;

-- assign existing client key's to existing members
update smn_member set client_key = 'd85bf2f8-12f4-4f22-b25d-12f7dfc9c67f', membership_type = 'PREMIUM', tu_enrolled_status = 'ENROLLED', 
braintree_customer_id = '844025309', payment_method_token = '47vg7v', braintree_subscription_id = '2pptz6', experian_enrolled_status = 'ENROLLED' where id = 4130361;
update smn_member set client_key = 'dc4c256e-fef7-45ae-8344-1740679bf6b6', membership_type = 'ESSENTIAL', tu_enrolled_status = 'ENROLLED' where id = 4088481;
update smn_member set client_key = 'bb7fe82a-f3a3-4dce-a615-8f4558185c78', membership_type = 'ELITE', tu_enrolled_status = 'ENROLLED', 
braintree_customer_id = '636014831', payment_method_token = '8hgznv', braintree_subscription_id = '9nvnv6', experian_enrolled_status = 'ENROLLED' where id = 4167186;
update smn_member set client_key = '9df77249-b278-406e-bf6b-00a6140fb295', membership_type = 'ESSENTIAL', tu_enrolled_status = 'ENROLLED' where id = 4225029;
update smn_member set client_key = 'd7df39e3-187d-4167-9faf-8fd05c2996d2', membership_type = 'ESSENTIAL', tu_enrolled_status = 'ENROLLED' where id = 4083534;
update smn_member set client_key = '877de7be-e3b5-41b9-bd90-6ebb7e272bc5', membership_type = 'ESSENTIAL', tu_enrolled_status = 'ENROLLED' where id = 4137514;
update smn_member set client_key = '17a8388d-800e-411f-880b-d965a9e12bc6', membership_type = 'ESSENTIAL', tu_enrolled_status = 'ENROLLED' where id = 4137385;
update smn_member set client_key = 'd427c7e6-fc93-427a-9b18-ce36d9e32b15', membership_type = 'ESSENTIAL', tu_enrolled_status = 'ENROLLED' where id = 4100826;
update smn_member set client_key = '1fd41eb7-4cbb-40ef-8265-1e4ee3c2e6b3', membership_type = 'PREMIUM', tu_enrolled_status = 'ENROLLED' where id = 4204795;
update smn_member set client_key = 'dd9aa1e9-1de2-4fec-9b29-ae0d1b250ddc', membership_type = 'PREMIUM', tu_enrolled_status = 'ENROLLED' where id = 4071231;
update smn_member set client_key = 'd031d016-9820-4848-be96-074a231a9eb4', membership_type = 'PREMIUM', tu_enrolled_status = 'ENROLLED' where id = 4066187;
update smn_member set client_key = '1ace34d2c-ef42-46d0-987a-be3ff0b4a664', membership_type = 'PREMIUM', tu_enrolled_status = 'ENROLLED' where id = 4088197;
update smn_member set client_key = '23d58c03-13f7-4727-a76f-653cd7b97f8e', membership_type = 'PREMIUM', tu_enrolled_status = 'ENROLLED', 
braintree_customer_id = '638888711', payment_method_token = 'chsyxz', braintree_subscription_id = 'hs2nt2', experian_enrolled_status = 'ENROLLED' where id = 7;
update smn_member set client_key = '55317fe1-4956-4a1c-bf76-455f5353025d', membership_type = 'ESSENTIAL', tu_enrolled_status = 'ENROLLED' where id = 489156;

-- removing members from email block list
delete from smn_blacklisted_email where email in ('007bridges@gmail.com','007graham@comcast.net',
'007jnperkins@gmail.com','007keytopia@gmail.com','007peggy@gmail.com','007Pirates@att.net',
'009tbarker@gmail.com','00davidbrown@gmail.com','00sinful@gmail.com','00millies@outlook.com',
'0112lizraeallen@gmail.com','00fallgirl00@gmail.com','erin8899@yahoo.com');

update dest_app_config set system_property_value = 'false' where id = 80;

update core_email_definition set sendgrid_unique_id= 'd-b23796121d744653a61e75afb724dd1b', email_template_type = 'SENDGRID' where unique_id = 'accountmanagement.forgotpassword.email';
update core_email_definition set sendgrid_unique_id= 'd-26de4cea97aa4f7db4b8b2e713b8a9f1', email_template_type = 'SENDGRID' where unique_id = 'email.member.welcome';
update core_email_definition set sendgrid_unique_id= 'd-a185dd303ff34f12b9163dd22b2a57a8', email_template_type = 'SENDGRID' where unique_id = 'email.member.new.welcome';
update core_email_definition set sendgrid_unique_id= 'd-42a491b6cc34424392cfc344b9469ce2', email_template_type = 'SENDGRID' where unique_id = 'email.verification';
update core_email_definition set sendgrid_unique_id= 'd-242fdab050624506b2954d69d6a21f96', email_template_type = 'SENDGRID' where unique_id = 'email.credit.refresh';
update core_email_definition set sendgrid_unique_id= 'd-f5dda50a9af7401a82317ecb9d8df0ff', email_template_type = 'SENDGRID' where unique_id = 'email.credit.score.change';
update core_email_definition set sendgrid_unique_id= 'd-faf2efab8e2441bd96814b39204f60f7', email_template_type = 'SENDGRID' where unique_id = 'email.member.new.welcome.essential';
update core_email_definition set sendgrid_unique_id= 'd-0142832ca5644595bad46f57fe6c526a', email_template_type = 'SENDGRID' where unique_id = 'email.member.new.welcome.premium';
update core_email_definition set sendgrid_unique_id= 'd-57dd877d60d24dbe9c7e4f43e6e2b138', email_template_type = 'SENDGRID' where unique_id = 'email.member.new.welcome.elite';
update core_email_definition set sendgrid_unique_id= 'd-a7d2c724f81a494092a36efb507c6d4e', email_template_type = 'SENDGRID' where unique_id = 'email.essential.member.upgrade.premium';
update core_email_definition set sendgrid_unique_id= 'd-c5069ad6c4dc4e958cf14a23185c805c', email_template_type = 'SENDGRID' where unique_id = 'email.elite.upgrade.welcome';
update core_email_definition set sendgrid_unique_id= 'd-90fb76474cf84ab1a0bb52a39a288f97', email_template_type = 'SENDGRID' where unique_id = 'email.member.offer.credit.prime';
update core_email_definition set sendgrid_unique_id= 'd-454bdc2999db4e788b6233aef86dfb95', email_template_type = 'SENDGRID' where unique_id = 'email.member.offer.credit.subprime';
update core_email_definition set sendgrid_unique_id= 'd-0016856eb6e4415a91bc53eb7f78a568', email_template_type = 'SENDGRID' where unique_id = 'email.member.ccm.alert';
update core_email_definition set sendgrid_unique_id= 'd-b6a59706ff374e36a1ca45a2ac72d395', email_template_type = 'SENDGRID' where unique_id = 'email.member.upgrade.premium';
update core_email_definition set sendgrid_unique_id= 'd-1a6570fe8434440e91ecdc350201fbc9', email_template_type = 'SENDGRID' where unique_id = 'email.member.debt.consolidation';
update core_email_definition set sendgrid_unique_id= 'd-e8b392013c26447891a147077429e0bc', email_template_type = 'SENDGRID' where unique_id = 'email.member.birthday';
update core_email_definition set sendgrid_unique_id= 'd-c5ab07b39d664e26b7af74672263a8f3', email_template_type = 'SENDGRID' where unique_id = 'email.member.inactive';
update core_email_definition set sendgrid_unique_id= 'd-83da390ebbac46cc994e959ac0fe53b6', email_template_type = 'SENDGRID' where unique_id = 'email.member.home.value.analysis';
update core_email_definition set sendgrid_unique_id= 'd-87cc4109b8b24265a77259e7434c1be5', email_template_type = 'SENDGRID' where unique_id = 'email.member.report.inquiry';
update core_email_definition set sendgrid_unique_id= 'd-91179f40271d4762802aaa5887020518', email_template_type = 'SENDGRID' where unique_id = 'email.member.anniversary';
update core_email_definition set sendgrid_unique_id= 'd-c2b531b89a6341ffb0c1c8515e18822e', email_template_type = 'SENDGRID' where unique_id = 'email.member.winback';
update core_email_definition set sendgrid_unique_id= 'd-d9c80c7b51194a6faa1bbd13a173727a', email_template_type = 'SENDGRID' where unique_id = 'email.member.verify.email';
update core_email_definition set sendgrid_unique_id= 'd-49f402663b3e4ee2aa99b71c75e1935d', email_template_type = 'SENDGRID' where unique_id = 'email.member.verify.phone';
update core_email_definition set sendgrid_unique_id= 'd-a0a035c04c154aae86dcb682ec2736a4', email_template_type = 'SENDGRID' where unique_id = 'email.member.credit.card.expiry';
update core_email_definition set sendgrid_unique_id= 'd-54f7f9ca21334c019b39e0dd6f59a72d', email_template_type = 'SENDGRID' where unique_id = 'email.member.credit.summary';
update core_email_definition set sendgrid_unique_id= 'd-2629a4dc96954dcab563ee865af684b1', email_template_type = 'SENDGRID' where unique_id = 'email.no.quote.selected';
update core_email_definition set sendgrid_unique_id= 'd-6d4e50e831d14f0da55dc3f037c72dcf', email_template_type = 'SENDGRID' where unique_id = 'email.lender.matched.confirmation';
update core_email_definition set sendgrid_unique_id= 'd-d9252b567cff4169bc9ed0e3e1354512', email_template_type = 'SENDGRID' where unique_id = 'email.quote.sendto.lender.confirmation';
update core_email_definition set sendgrid_unique_id= 'd-04da0151c5844af98978904757b25e60', email_template_type = 'SENDGRID' where unique_id = 'email.add.quote.reminder';
update core_email_definition set sendgrid_unique_id= 'd-7eced01c99a044958386dcd28b2e4720', email_template_type = 'SENDGRID' where unique_id = 'email.mortgage.application.quote.request.confirmation';
update core_email_definition set sendgrid_unique_id= 'd-7bc7a5e557d6484a808671f95ce4b344', email_template_type = 'SENDGRID' where unique_id = 'email.mortgage.application.consumer.matched.lenders';
update core_email_definition set sendgrid_unique_id= 'd-33b63f47cbb2423d8c82c01122e04d2f', email_template_type = 'SENDGRID' where unique_id = 'email.mortgage.application.quote.received.from.lender';
update core_email_definition set sendgrid_unique_id= 'd-23aec53515b54abba95d3946b4635363', email_template_type = 'SENDGRID' where unique_id = 'email.mortgage.application.select.quote.reminder';
update core_email_definition set sendgrid_unique_id = 'd-84af300f9ecc4ac8bf73d0468df19d7f' where unique_id = 'email.mortgage.application.preapproval';
update core_email_definition set sendgrid_unique_id = 'd-95fabc8d29fa4c97b026588f0b79b019' where unique_id = 'email.member.request.quotes';

update dest_app_config set system_property_value = 'true' where system_property_name = 'MORTGAGE_APPLICATION_BUTTON_ENABLED';
update dest_app_config set system_property_value = 'false' where system_property_name = 'MORTGAGE_APPLICATION_GET_SSN_FROM_CCM';

update smn_member set lpkey = null where lpkey = 'OHg1NDUzOTA4OW1WOUdaaUlBOUlPY2E5ZG9DcElWM0xJVEV4Yz0';

truncate smn_member_instruction;