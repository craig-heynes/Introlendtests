package smartemails;

import data.ApiData;
import data.ApiRequestBuilder;
import data.GlobalVariables;
import data.OperatorData;
import helperutil.CCMUnenrolment;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import org.junit.Assert;
import org.testng.annotations.Test;
import pages.OperatorPage;
import uitests.base.BaseTestBeforeClass;
import uitests.base.CreateEssentialMember;
import util.DatabaseUtil;
import util.EnvironmentReader;
import util.LoggingDatabaseUtil;

import java.util.Map;

public class CreditSummaryEmailTest extends BaseTestBeforeClass
{
    CreateEssentialMember essentialMember;
    DatabaseUtil util = new DatabaseUtil();
    LoggingDatabaseUtil loggingUtil = new LoggingDatabaseUtil();
    OperatorPage operatorPage;
    String clientKey;
    EnvironmentReader fileReader = new EnvironmentReader();
    String baseUri = fileReader.getApiBaseUri();
    ApiRequestBuilder apiRequestBuilder = new ApiRequestBuilder();

    private static final String endpoint = "/members";

    @Test(dataProvider = "createEssentialMember", dataProviderClass = ApiData.class)
    public void testCreditSummaryEmail (String emailAddress, String password, String visitorId, String firstName, String lastName,
                                       String address, String zipCode, String dateOfBirth, String phoneNumber,
                                       String ssn9, String planType, String redirectUrl, Boolean doThreeBTest) throws Exception
    {
        util.setLastRefreshDateForMember(emailAddress);

        clientKey = GlobalVariables.ESSENTIALCLIENTKEY;
        CCMUnenrolment unEnrol = new CCMUnenrolment();
        unEnrol.deleteEssentialClientKey();

        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");
        request.body(apiRequestBuilder.getMemberCreateRequestForEssential(emailAddress, password, visitorId, firstName, lastName, address, zipCode, dateOfBirth, phoneNumber,
                ssn9, planType, redirectUrl, clientKey, null, null, null).toJSONString());
        Response response = request.post(baseUri + endpoint);

        ResponseBody body = response.getBody();
        String bodyStringValue = body.asString();

        System.out.println(bodyStringValue);

        JsonPath jsonPathEvaluator = response.jsonPath();
        Map<String, String> successResponseMap = jsonPathEvaluator.get("response");
        Object value = successResponseMap.get("memberId");

        util.setCreditSummaryDataForMember(value.toString());
        util.setEmailPhoneVerified(emailAddress);
        util.enableDisableSmartEmail(1, OperatorData.CREDITSUMMARY_ID); // enable smartemail
        util.setLastRefreshDateBack(emailAddress, 1);

        operatorPage = new OperatorPage(getDriver(),"");
        operatorPage.signInOperator();
        operatorPage.runOperatorJob(OperatorData.CREDITSUMMARY_JOB, emailAddress);

//        util.enableDisableSmartEmail(0, OperatorData.CREDITSUMMARY_ID); // disable smartemail

        Assert.assertEquals("CREDIT_SUMMARY_EMAIL", loggingUtil.getSmartEmailSentStatus(emailAddress));
    }
}
