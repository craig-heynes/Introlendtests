package smartemails;

import data.ApiData;
import data.OperatorData;
import org.junit.Assert;
import org.testng.annotations.Test;
import pages.OperatorPage;
import uitests.base.BaseTestBeforeClass;
import uitests.base.CreateEssentialMember;
import util.DatabaseUtil;
import util.LoggingDatabaseUtil;

public class PrimeEmailTest extends BaseTestBeforeClass
{
    CreateEssentialMember essentialMember;
    DatabaseUtil util = new DatabaseUtil();
    LoggingDatabaseUtil loggingUtil = new LoggingDatabaseUtil();
    OperatorPage operatorPage;

    @Test (dataProviderClass = ApiData.class, dataProvider = "createEssentialMemberForUISignUp")
    public void testPrimeEmailJob(String emailAddress, String password, String firstName, String lastName, String address,
                                          String zipCode, String dateOfBirth,
                                          String phoneNumber, String ssn, Boolean doThreeBTest) throws Exception
    {
        util.updatePrimeAllMembers();

        essentialMember = new CreateEssentialMember(getDriver());
        essentialMember.testCreateEssentialMember(emailAddress, password, firstName, lastName, address, zipCode, dateOfBirth,
                phoneNumber, ssn, doThreeBTest);

        util.setEmailPhoneVerified(emailAddress);
        util.enableDisableSmartEmail(1, OperatorData.PRIME_ID); // enable smartemail
        util.setPrimeEmailData(emailAddress);

        operatorPage = new OperatorPage(getDriver(),"");
        operatorPage.signInOperator();
        operatorPage.runOperatorJob(OperatorData.PRIME_JOB, emailAddress);

        util.enableDisableSmartEmail(0, OperatorData.PRIME_ID); // disable smartemail

        Assert.assertEquals("CREDIT_CARD_PRIME_EMAIL", loggingUtil.getSmartEmailSentStatus(emailAddress));
    }
}
