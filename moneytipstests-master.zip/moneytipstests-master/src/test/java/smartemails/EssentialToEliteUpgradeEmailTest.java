package smartemails;

import data.*;
import helperutil.CCMUnenrolment;
import io.restassured.RestAssured;
import io.restassured.specification.RequestSpecification;
import org.junit.Assert;
import org.testng.annotations.Test;
import pages.CreditCardHostedFieldsPage;
import pages.OperatorPage;
import pages.SignInAndUpgradePage;
import uitests.base.BaseTestBeforeMethod;
import uitests.base.CreateEssentialMember;
import util.DatabaseUtil;
import util.EnvironmentReader;
import util.LoggingDatabaseUtil;

public class EssentialToEliteUpgradeEmailTest extends BaseTestBeforeMethod
{
    CreateEssentialMember essentialMember;
    DatabaseUtil util = new DatabaseUtil();
    LoggingDatabaseUtil loggingUtil = new LoggingDatabaseUtil();
    OperatorPage operatorPage;
    String clientKey;
    EnvironmentReader fileReader = new EnvironmentReader();
    String baseUri = fileReader.getApiBaseUri();
    ApiRequestBuilder apiRequestBuilder = new ApiRequestBuilder();

    SignInAndUpgradePage signInAndUpgradePage;
    CreditCardHostedFieldsPage creditCardHostedFieldsPage;

    String emailToLogin;
    String passwordToLogin;

    private static final String ELITE_UPGRADE_SENDGRID_ID = "d-c5069ad6c4dc4e958cf14a23185c805c";
    private static final String endpoint = "/members";

    @Test(dataProvider = "createEssentialMember", dataProviderClass = ApiData.class)
    public void a_testEliteUpgradeEmail (String emailAddress, String password, String visitorId, String firstName, String lastName,
                                       String address, String zipCode, String dateOfBirth, String phoneNumber,
                                       String ssn9, String planType, String redirectUrl, Boolean doThreeBTest) throws Exception
    {
        clientKey = GlobalVariables.ESSENTIALCLIENTKEY;
        CCMUnenrolment unEnrol = new CCMUnenrolment();
        unEnrol.deleteEssentialClientKey();

        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");
        request.body(apiRequestBuilder.getMemberCreateRequestForEssential(emailAddress, password, visitorId, firstName, lastName, address, zipCode, dateOfBirth, phoneNumber,
                ssn9, planType, redirectUrl, clientKey, null, null, null).toJSONString());
        request.post(baseUri + endpoint);

        emailToLogin = emailAddress;
        passwordToLogin = password;

        System.out.println("Email Address: " + emailAddress);
        System.out.println("Password: " + password);

        util.setEmailPhoneVerified(emailAddress);
        util.enableDisableSmartEmail(1, OperatorData.ESSENTIAL_TO_ELITE_UPGRADE_ID); // enable smartemail
    }

    @Test (dataProviderClass = SignUpData.class, dataProvider = "validCardInfo")
    public void b_upgradeEssentialToEliteTest(String cardNum, String cardCvv, String cardExpiry, String cardZipCode) throws Exception
    {
        signInAndUpgradePage = new SignInAndUpgradePage(getDriver(), "");
        creditCardHostedFieldsPage = new CreditCardHostedFieldsPage(getDriver());
        signInAndUpgradePage.clickSignInLink();
        signInAndUpgradePage.setSignInCred(emailToLogin, passwordToLogin);
        signInAndUpgradePage.clickBtnSignIn();
        signInAndUpgradePage.clickUpgradeLink();
        signInAndUpgradePage.clickBtnUpgradeToElite();
        creditCardHostedFieldsPage.setCreditCardDetails(cardNum, cardCvv, cardExpiry, cardZipCode);
        signInAndUpgradePage.clickBtnIDProtect();

        util.enableDisableSmartEmail(0, OperatorData.ESSENTIAL_TO_ELITE_UPGRADE_ID); // disable smartemail

        Assert.assertEquals("ELITE", util.getMemberShipType(emailToLogin));
        Assert.assertEquals("ENROLLED", util.getTUEnrollStatus(emailToLogin));
        Assert.assertEquals("ENROLLED", util.getExperianEnrollStatus(emailToLogin));
        Assert.assertEquals("1", loggingUtil.getSendGridEmailSentStatus(emailToLogin, ELITE_UPGRADE_SENDGRID_ID));
    }
}
