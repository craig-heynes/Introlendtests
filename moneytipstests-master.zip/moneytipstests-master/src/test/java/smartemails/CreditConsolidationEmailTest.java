package smartemails;

import data.ApiData;
import data.OperatorData;
import org.testng.annotations.Test;
import pages.OperatorPage;
import uitests.base.BaseTestBeforeClass;
import uitests.base.CreateEssentialMember;
import util.DatabaseUtil;
import util.LoggingDatabaseUtil;

public class CreditConsolidationEmailTest extends BaseTestBeforeClass
{
    CreateEssentialMember essentialMember;
    DatabaseUtil util = new DatabaseUtil();
    LoggingDatabaseUtil loggingUtil = new LoggingDatabaseUtil();
    OperatorPage operatorPage;

    @Test (dataProviderClass = ApiData.class, dataProvider = "createEssentialMemberForUISignUp")
    public void testConsolidationEmailJob(String emailAddress, String password, String firstName, String lastName, String address,
                                          String zipCode, String dateOfBirth,
                                          String phoneNumber, String ssn, Boolean doThreeBTest) throws Exception
    {
        util.updateCardDebtAllMembers();

        essentialMember = new CreateEssentialMember(getDriver());
        essentialMember.testCreateEssentialMember(emailAddress, password, firstName, lastName, address, zipCode, dateOfBirth,
                phoneNumber, ssn, doThreeBTest);

        util.setEmailPhoneVerified(emailAddress);
        util.enableDisableSmartEmail(1, OperatorData.DEBTCONSOLIDATION_ID); // enable smartemail
        util.setDebtConsolidationData(emailAddress);

//        operatorPage = new OperatorPage(getDriver(),"");
//        operatorPage.signInOperator();
//        operatorPage.runOperatorJob(OperatorData.DEBTCONSOLIDATION_JOB, emailAddress);
//
//        util.enableDisableSmartEmail(0, OperatorData.DEBTCONSOLIDATION_ID); // disable smartemail
//
//        Assert.assertEquals("DEBT_CONSOLIDATION_EMAIL", loggingUtil.getSmartEmailSentStatus(emailAddress));
    }
}
