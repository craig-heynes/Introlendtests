package smartemails;

import data.ApiData;
import data.OperatorData;
import org.junit.Assert;
import org.testng.annotations.Test;
import pages.OperatorPage;
import uitests.base.BaseTestBeforeClass;
import uitests.base.CreateEssentialMember;
import util.DatabaseUtil;
import util.LoggingDatabaseUtil;

public class AlertEmailTest extends BaseTestBeforeClass
{
    CreateEssentialMember essentialMember;
    DatabaseUtil util = new DatabaseUtil();
    LoggingDatabaseUtil loggingUtil = new LoggingDatabaseUtil();
    OperatorPage operatorPage;

    @Test (dataProviderClass = ApiData.class, dataProvider = "createEssentialMemberForUISignUp")
    public void testEssentialAlertEmailJob(String emailAddress, String password, String firstName, String lastName, String address,
                                          String zipCode, String dateOfBirth,
                                          String phoneNumber, String ssn, Boolean doThreeBTest) throws Exception
    {
        essentialMember = new CreateEssentialMember(getDriver());
        essentialMember.testCreateEssentialMember(emailAddress, password, firstName, lastName, address, zipCode, dateOfBirth,
                phoneNumber, ssn, doThreeBTest);

        util.setEmailPhoneVerified(emailAddress);
        util.enableDisableSmartEmail(1, OperatorData.CCMALERT_ID); // enable smartemail
        util.clearAlertsClientKey(emailAddress);
        util.setAlertsClientKey(emailAddress);

        operatorPage = new OperatorPage(getDriver(),"");
        operatorPage.signInOperator();
        operatorPage.runOperatorJob("populate_alerts_queue_job", emailAddress);
        Thread.sleep(5000);
        operatorPage.runOperatorJob("batch_alerts_consumer_job", emailAddress);
        Thread.sleep(5000);
        operatorPage.runOperatorJob("instant_alerts_consumer_job", emailAddress);
        Thread.sleep(5000);

        util.enableDisableSmartEmail(0, OperatorData.CCMALERT_ID); // disable smartemail

        Assert.assertEquals("CREDIT_CARD_SUB_PRIME_EMAIL", loggingUtil.getSmartEmailSentStatus(emailAddress));
    }
}
