package apitests.registrant;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import org.junit.Assert;
import org.testng.annotations.Test;
import util.EnvironmentReader;

public class GetRegistrantTest
{
    private static EnvironmentReader fileReader = new EnvironmentReader();
    String baseUri = fileReader.getApiBaseUri();
    private static final String endpoint = "/registrants/loan-application-id/";
    private static final String VALID_LOANAPPID = "11d86373-afeb-4370-ba62-7b7eefbc9afd";
    private static final String INVALID_LOANAPPID = "blah";

    @org.testng.annotations.Test
    public void testGetRegistrant_200()
    {
        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");
        Response response = request.get(baseUri + endpoint + VALID_LOANAPPID);
        ResponseBody body = response.getBody();

        String bodyStringValue = body.asString();
        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");
        int statusCode = response.getStatusCode();

        System.out.println(bodyStringValue);

        Assert.assertEquals(200,statusCode);
        Assert.assertEquals(status,"SUCCESS");
    }

    @Test
    public void testGetRegistrant_400()
    {
        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");
        Response response = request.get(baseUri + endpoint + INVALID_LOANAPPID);
        ResponseBody body = response.getBody();

        String bodyStringValue = body.asString();
        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");
        int statusCode = response.getStatusCode();

        System.out.println(bodyStringValue);

        Assert.assertEquals(400,statusCode);
        Assert.assertEquals(status,"FAILED");
    }
}
