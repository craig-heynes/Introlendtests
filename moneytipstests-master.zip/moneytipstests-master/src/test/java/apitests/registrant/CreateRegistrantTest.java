package apitests.registrant;

import data.ApiData;
import data.ApiRequestBuilder;
import data.GlobalVariables;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import org.junit.Assert;
import util.EnvironmentReader;

import java.util.Map;

public class CreateRegistrantTest {

    private static EnvironmentReader fileReader = new EnvironmentReader();
    private static String baseUri = fileReader.getApiBaseUri();
    private static String endpoint = "/registrants";
    private static ApiRequestBuilder apiRequestBuilder = new ApiRequestBuilder();
    private String registrantId_Test1;

    @org.testng.annotations.Test (dataProvider = "createRegistrantEssential", dataProviderClass = ApiData.class)
    public void testCreateEssentialRegistrant_200(String firstName, String lastName, String emailAddress, String password, String visitorId, String planType)
    {
        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");
        request.body(apiRequestBuilder.getRegistrantCreateRequest(firstName, lastName,
                emailAddress, password, planType, visitorId).toJSONString());

        Response response = request.post(baseUri + endpoint);
        ResponseBody body = response.getBody();

        String bodyStringValue = body.asString();
        System.out.println(bodyStringValue);
        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");
        Map<String, String> successResponseMap = jsonPathEvaluator.get("response");

        if (successResponseMap.containsKey("registrantId")) {
            Object value = successResponseMap.get("registrantId");
            registrantId_Test1 = value.toString();
            GlobalVariables.registrantId = value.toString();
        }

        int statusCode = response.getStatusCode();

        org.testng.Assert.assertEquals(200,statusCode);
        org.testng.Assert.assertEquals(status,"SUCCESS");
        org.testng.Assert.assertFalse(registrantId_Test1.isEmpty());
    }

    public String getRegistrantIdForTest()
    {
        return registrantId_Test1;
    }

    @org.testng.annotations.Test (dataProvider = "createRegistrantPremium", dataProviderClass = ApiData.class)
    public void testCreatePremiumRegistrant_200(String firstName, String lastName, String emailAddress, String password, String visitorId, String planType)
    {
        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");
        request.body(apiRequestBuilder.getRegistrantCreateRequest(firstName, lastName,
                emailAddress, password, planType, visitorId).toJSONString());
        Response response = request.post(baseUri + endpoint);

        ResponseBody body = response.getBody();
        String bodyStringValue = body.asString();
        System.out.println(bodyStringValue);
        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");
        String registrantIdCreated="";

        Map<String, String> successResponseMap = jsonPathEvaluator.get("response");

        if (successResponseMap.containsKey("registrantId")) {
            Object value = successResponseMap.get("registrantId");
            registrantIdCreated=value.toString();
            GlobalVariables.registrantId = value.toString();
        }

        int statusCode = response.getStatusCode();

        org.testng.Assert.assertEquals(200,statusCode);
        org.testng.Assert.assertEquals(status,"SUCCESS");
        org.testng.Assert.assertFalse(registrantIdCreated.isEmpty());
    }

    @org.testng.annotations.Test (dataProvider = "createRegistrantElite", dataProviderClass = ApiData.class)
    public void testCreateEliteRegistrant_200(String firstName, String lastName, String emailAddress, String password, String visitorId, String planType)
    {
        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");
        request.body(apiRequestBuilder.getRegistrantCreateRequest(firstName, lastName,
                emailAddress, password, planType, visitorId).toJSONString());

        Response response = request.post(baseUri + endpoint);
        ResponseBody body = response.getBody();
        String bodyStringValue = body.asString();
        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");
        String registrantIdCreated="";

        Map<String, String> successResponseMap = jsonPathEvaluator.get("response");

        if (successResponseMap.containsKey("registrantId")) {
            Object value = successResponseMap.get("registrantId");
            registrantIdCreated = value.toString();
            GlobalVariables.registrantId = value.toString();
        }

        int statusCode = response.getStatusCode();

        System.out.println(bodyStringValue);

        org.testng.Assert.assertEquals(200,statusCode);
        org.testng.Assert.assertEquals(status,"SUCCESS");
        org.testng.Assert.assertFalse(GlobalVariables.registrantId.isEmpty());
    }

    @org.testng.annotations.Test (dataProvider = "createRegistrantEssential", dataProviderClass = ApiData.class)
    public void testCreateRegistrantWithoutEmail_400(String firstName, String lastName,
                                                     String emailAddress, String password, String visitorId, String planType)
    {
        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");
        request.body(apiRequestBuilder.getRegistrantCreateRequest(firstName, lastName,
                "", password, planType, visitorId).toJSONString());

        Response response = request.post(baseUri + endpoint);
        ResponseBody body = response.getBody();
        String bodyStringValue = body.asString();
        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");
        int statusCode = response.getStatusCode();

        System.out.println(bodyStringValue);

        org.testng.Assert.assertEquals(400,statusCode);
        org.testng.Assert.assertEquals(status,"FAILED");
    }

    @org.testng.annotations.Test (dataProvider = "createRegistrantEssential", dataProviderClass = ApiData.class)
    public void testCreateRegistrantWithoutPassword_200(String firstName, String lastName, String emailAddress, String password, String visitorId, String planType)
    {
        password = null;

        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");
        request.body(apiRequestBuilder.getRegistrantCreateRequest(firstName, lastName,
                emailAddress, password, planType, visitorId).toJSONString());
        Response response = request.post(baseUri + endpoint);

        ResponseBody body = response.getBody();
        String bodyStringValue = body.asString();
        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");
        int statusCode = response.getStatusCode();

        System.out.println(bodyStringValue);

        org.testng.Assert.assertEquals(200,statusCode);
        org.testng.Assert.assertEquals(status,"SUCCESS");
    }

    @org.testng.annotations.Test (dataProvider = "createRegistrantEssential", dataProviderClass = ApiData.class)
    public void testCreateRegistrantInvalidPassword_400(String firstName, String lastName, String emailAddress, String password, String visitorId, String planType)
    {
        password = "terra";

        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");
        request.body(apiRequestBuilder.getRegistrantCreateRequest(firstName, lastName,
                emailAddress, password, planType, visitorId).toJSONString());
        Response response = request.post(baseUri + endpoint);

        ResponseBody body = response.getBody();
        String bodyStringValue = body.asString();
        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");
        int statusCode = response.getStatusCode();

        System.out.println(bodyStringValue);

        org.testng.Assert.assertEquals(400,statusCode);
        org.testng.Assert.assertEquals(status,"FAILED");
        org.testng.Assert.assertTrue(bodyStringValue.contains("Password must be a minimum of 6 characters"));
    }

    @org.testng.annotations.Test (dataProviderClass = ApiData.class, dataProvider = "createEssentialRegistrantAllFields")
    public void testUpdateEssentialRegistrant_200(String firstName, String lastName, String emailAddress, String password, String visitorId, String address,
                                        String city, String state, String zipCode, String dateOfBirth, String phoneNumber, String clientKey, String planType,
                                                  String memberSignupSource, String loanPurpose, String lpKey)
    {
        RequestSpecification requestCreate = RestAssured.given();
        requestCreate.header("Content-Type", "application/json");
        requestCreate.body(apiRequestBuilder.getRegistrantCreateRequest(firstName, lastName,
                emailAddress, password, planType, visitorId).toJSONString());

        Response responseCreate = requestCreate.post(baseUri + endpoint);
        ResponseBody bodyCreate = responseCreate.getBody();

        String bodyCreateStringValue = bodyCreate.asString();
        System.out.println(bodyCreateStringValue);
        JsonPath jsonPathEvaluatorCreate = responseCreate.jsonPath();
        String statusCreate = jsonPathEvaluatorCreate.get("status");
        String registrantIdCreated="";
        Map<String, String> successResponseMap = jsonPathEvaluatorCreate.get("response");

        if (successResponseMap.containsKey("registrantId")) {
            Object value = successResponseMap.get("registrantId");
            registrantIdCreated = value.toString();
        }

        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");
        request.body(apiRequestBuilder.getRegistrantUpdateRequest(address, city, state, zipCode, dateOfBirth, phoneNumber, clientKey,
                null, null).toJSONString());
        Response response = request.put(baseUri + endpoint + "/" + registrantIdCreated);
        ResponseBody body = response.getBody();

        String bodyStringValue = body.asString();
        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");
        int statusCode = response.getStatusCode();

        System.out.println(bodyStringValue);

        org.testng.Assert.assertEquals(200,statusCode);
        org.testng.Assert.assertEquals(status,"SUCCESS");
        org.testng.Assert.assertTrue(bodyStringValue.contains(registrantIdCreated));
    }

    @org.testng.annotations.Test (dataProvider = "createPremiumRegistrantAllFields", dataProviderClass = ApiData.class)
    public void testUpdatePremiumRegistrant_200(String firstName, String lastName, String emailAddress, String password, String visitorId, String address,
                                         String city, String state, String zipCode, String dateOfBirth, String phoneNumber, String clientKey, String planType, String nonce, String brainTreePlanId)
    {
        RequestSpecification requestCreate = RestAssured.given();
        requestCreate.header("Content-Type", "application/json");
        requestCreate.body(apiRequestBuilder.getRegistrantCreateRequest(firstName, lastName,
                emailAddress, password, planType, visitorId).toJSONString());

        Response responseCreate = requestCreate.post(baseUri + endpoint);
        ResponseBody bodyCreate = responseCreate.getBody();

        String bodyCreateStringValue = bodyCreate.asString();
        System.out.println(bodyCreateStringValue);
        JsonPath jsonPathEvaluatorCreate = responseCreate.jsonPath();
        String registrantIdCreated="";
        Map<String, String> successResponseMap = jsonPathEvaluatorCreate.get("response");

        if (successResponseMap.containsKey("registrantId")) {
            Object value = successResponseMap.get("registrantId");
            registrantIdCreated = value.toString();
        }

        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");
        request.body(apiRequestBuilder.getRegistrantUpdateRequest(address, city, state, zipCode, dateOfBirth, phoneNumber,
                clientKey, nonce, brainTreePlanId).toJSONString());
        Response response = request.put(baseUri + endpoint + "/" + registrantIdCreated);
        ResponseBody body = response.getBody();

        String bodyStringValue = body.asString();
        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");
        int statusCode = response.getStatusCode();

        System.out.println(bodyStringValue);

        org.testng.Assert.assertEquals(200,statusCode);
        org.testng.Assert.assertEquals(status,"SUCCESS");
        org.testng.Assert.assertTrue(bodyStringValue.contains(registrantIdCreated));
    }

    @org.testng.annotations.Test (dataProvider = "createEliteRegistrantAllFields", dataProviderClass = ApiData.class)
    public void testUpdateEliteRegistrant_200(String firstName, String lastName, String emailAddress, String password, String visitorId, String address,
                                                String city, String state, String zipCode, String dateOfBirth, String phoneNumber,
                                              String clientKey, String planType, String nonce, String brainTreePlanId)
    {
        RequestSpecification requestCreate = RestAssured.given();
        requestCreate.header("Content-Type", "application/json");
        requestCreate.body(apiRequestBuilder.getRegistrantCreateRequest(firstName, lastName,
                emailAddress, password, planType, visitorId).toJSONString());

        Response responseCreate = requestCreate.post(baseUri + endpoint);
        ResponseBody bodyCreate = responseCreate.getBody();

        String bodyCreateStringValue = bodyCreate.asString();
        System.out.println(bodyCreateStringValue);
        JsonPath jsonPathEvaluatorCreate = responseCreate.jsonPath();
        String registrantIdCreated="";
        Map<String, String> successResponseMap = jsonPathEvaluatorCreate.get("response");

        if (successResponseMap.containsKey("registrantId")) {
            Object value = successResponseMap.get("registrantId");
            registrantIdCreated = value.toString();
        }

        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");
        request.body(apiRequestBuilder.getRegistrantUpdateRequest(address, city, state, zipCode, dateOfBirth, phoneNumber,
                clientKey, nonce, brainTreePlanId).toJSONString());
        Response response = request.put(baseUri + endpoint + "/" + registrantIdCreated);
        ResponseBody body = response.getBody();

        String bodyStringValue = body.asString();
        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");
        int statusCode = response.getStatusCode();

        System.out.println(bodyStringValue);

        org.testng.Assert.assertEquals(200,statusCode);
        org.testng.Assert.assertEquals(status,"SUCCESS");
        org.testng.Assert.assertTrue(bodyStringValue.contains(registrantIdCreated));
    }

    @org.testng.annotations.Test(dataProvider = "createEssentialRegistrantAllFields", dataProviderClass = ApiData.class)
    public void testCreateEssentialRegistrantAllFields_200(String firstName, String lastName, String emailAddress, String password,
                                                           String visitorId, String address, String city, String state,
                                                           String zipCode, String dateOfBirth, String phoneNumber,
                                                           String clientKey, String planType, String memberSignupSource, String loanPurpose, String lpKey)
    {
        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");
        request.body(apiRequestBuilder.getRegistrantCreateRequestAllFields(firstName, lastName,
                emailAddress, password, planType, visitorId, address, city, state, zipCode, dateOfBirth, phoneNumber,
                clientKey, null, null, lpKey, memberSignupSource, loanPurpose).toJSONString());
        Response response = request.post(baseUri + endpoint);
        ResponseBody body = response.getBody();

        String bodyStringValue = body.asString();
        JsonPath jsonPathEvaluator = response.jsonPath();
        Map<String, String> successResponseMap = jsonPathEvaluator.get("response");
        String registrantIdCreated="";

        if (successResponseMap.containsKey("registrantId")) {
            Object value = successResponseMap.get("registrantId");
            registrantIdCreated = value.toString();
            GlobalVariables.registrantId = value.toString();
        }

        String status = jsonPathEvaluator.get("status");
        int statusCode = response.getStatusCode();

        System.out.println(bodyStringValue);

        org.testng.Assert.assertEquals(200,statusCode);
        org.testng.Assert.assertEquals(status,"SUCCESS");
        org.testng.Assert.assertTrue(bodyStringValue.contains(registrantIdCreated));
    }

    @org.testng.annotations.Test (dataProvider = "createEssentialRegistrantAllFields", dataProviderClass = ApiData.class)
    public void testUpdateRegistrant_400(String firstName, String lastName, String emailAddress, String password,
                                         String visitorId, String address, String city, String state,
                                         String zipCode, String dateOfBirth, String phoneNumber,
                                         String clientKey, String planType, String memberSignupSource, String loanPurpose, String lpKey)
    {
        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");
        request.body(apiRequestBuilder.getRegistrantUpdateRequest(address, city, state, zipCode, dateOfBirth, phoneNumber, clientKey, null, null).toJSONString());
        Response response = request.put(baseUri + endpoint + "/999999999");
        ResponseBody body = response.getBody();

        String bodyStringValue = body.asString();
        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");
        int statusCode = response.getStatusCode();

        System.out.println(bodyStringValue);

        org.testng.Assert.assertEquals(400,statusCode);
        org.testng.Assert.assertEquals(status,"FAILED");
        org.testng.Assert.assertTrue(bodyStringValue.contains("UPDATE_REGISTRANT_FAILED"));
    }
}
