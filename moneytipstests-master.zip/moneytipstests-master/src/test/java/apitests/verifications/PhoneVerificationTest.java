package apitests.verifications;

import apitests.registrant.CreateRegistrantTest;
import data.ApiData;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.testng.annotations.Test;
import util.DatabaseUtil;
import util.EnvironmentReader;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class PhoneVerificationTest
{
    private static EnvironmentReader fileReader = new EnvironmentReader();
    String baseUri = fileReader.getApiBaseUri();
    String endpoint = "/verifications";
    String endpointMember = "/members";
    String phoneEndpoint = "/phone/verification";

    @org.testng.annotations.Test(dataProviderClass = ApiData.class, dataProvider = "createRegistrantEssential")
    public void testPhoneVerificationAgainstRegistrant_200(String name, String surname, String emailAddress,
                                                           String password, String visitorId, String planType) throws  Exception
    {
        CreateRegistrantTest createRegistrant = new CreateRegistrantTest();
        createRegistrant.testCreateEssentialRegistrant_200(name, surname, emailAddress, password, visitorId, planType);

        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");

        request.body("{\n    " +
                "\"registrantId\": " + createRegistrant.getRegistrantIdForTest() + ",\n    " +
                "\"mobileNumber\": \"3012089857\",\n    " +
                "\"phoneVerificationDate\": \"04/11/2019\"\n}");

        Response response = request.put(baseUri + phoneEndpoint);
        ResponseBody body = response.getBody();
        String bodyStringValue = body.asString();
        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");

        DatabaseUtil getVerificationStatus = new DatabaseUtil();
        int phoneVerified = Integer.valueOf(getVerificationStatus.getRegistrantVerificationPhoneStatus(emailAddress));
        int statusCode = response.getStatusCode();

        System.out.println(bodyStringValue);

        Assert.assertEquals(200,statusCode);
        Assert.assertEquals(status,"SUCCESS");
        Assert.assertTrue(bodyStringValue.contains("true"));
        Assert.assertEquals(1, phoneVerified);
    }

    @Test (dataProviderClass = ApiData.class, dataProvider = "createRegistrantEssential")
    public void testPhoneVerificationAgainstRegistrant_400(String name, String surname, String emailAddress,
                                                           String password, String visitorId, String planType) throws  Exception
    {
        CreateRegistrantTest createRegistrant = new CreateRegistrantTest();
        createRegistrant.testCreateEssentialRegistrant_200(name, surname, emailAddress, password, visitorId, planType);

        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");

        request.body("{\n    " +
                "\"registrantId\": " + createRegistrant.getRegistrantIdForTest() + ",\n    " +
                "\"phoneVerificationDate\": \"04/11/2019\"\n}");

        Response response = request.put(baseUri + phoneEndpoint);
        ResponseBody body = response.getBody();
        String bodyStringValue = body.asString();
        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");

        DatabaseUtil getVerificationStatus = new DatabaseUtil();
        int phoneVerified = Integer.valueOf(getVerificationStatus.getRegistrantVerificationPhoneStatus(emailAddress));
        int statusCode = response.getStatusCode();

        System.out.println(bodyStringValue);

        Assert.assertEquals(400,statusCode);
        Assert.assertEquals(status,"FAILED");
        Assert.assertTrue(bodyStringValue.contains("mobileNumber"));
        Assert.assertEquals(0, phoneVerified);
    }
}
