package apitests.verifications;

import data.ApiData;
import data.ApiRequestBuilder;
import data.GlobalVariables;
import helperutil.CCMUnenrolment;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import org.testng.Assert;
import org.testng.annotations.Test;
import util.DatabaseUtil;
import util.EnvironmentReader;

import java.util.Map;

public class EmailVerificationMemberTest_200
{
    EnvironmentReader fileReader = new EnvironmentReader();
    String baseUri = fileReader.getApiBaseUri();
    String endpoint = "/verifications";
    String endpointMember = "/members";

    @Test(dataProviderClass = ApiData.class, dataProvider = "createEssentialMember")
    public void testSetEmailVerificationEssentialMember_200(String emailAddress, String password, String visitorId, String firstName, String lastName,
                                                            String address, String zipCode, String dateOfBirth, String phoneNumber,
                                                            String ssn9, String planType, String redirectUrl, Boolean doThreeBTest,
                                                            String city, String state, String ccmDob) throws Exception
    {
//        ApiMemberCreate memberCreate = new ApiMemberCreate (getDriver());
//        memberCreate.memberCreateForClientKey(firstName, lastName, emailAddress, password, address,
//                zipCode, phoneNumber, dateOfBirth, "1234", ssn9, "fakecard", "fakecvv",
//                "fakeexpiry", "fakezipcode");
//
//        LoggingDatabaseUtil loggingDatabaseUtil = new LoggingDatabaseUtil();

        String clientKey = GlobalVariables.ESSENTIALCLIENTKEY;

        CCMUnenrolment unenrolment = new CCMUnenrolment();
        unenrolment.deleteEssentialClientKey();

        RequestSpecification requestEnroll = RestAssured.given();
        requestEnroll.header("Content-Type", "application/json");

        ApiRequestBuilder apiRequestBuilder = new ApiRequestBuilder();
        requestEnroll.body(apiRequestBuilder.getMemberCreateRequestForEssential(emailAddress, password, visitorId, firstName, lastName, address, zipCode, dateOfBirth, phoneNumber,
                ssn9, planType, redirectUrl, clientKey, null, null, null).toJSONString());

        Response response = requestEnroll.post(baseUri + endpointMember);

        ResponseBody bodyCreate = response.getBody();
        String bodyStringValue = bodyCreate.asString();

        System.out.println(bodyStringValue);

        String memberId;
        JsonPath jsonPathEvaluator = response.jsonPath();
        Map<String, String> successResponseMap = jsonPathEvaluator.get("response");

        Object value = successResponseMap.get("memberId");
        memberId = value.toString();

        RequestSpecification requestForVerification = RestAssured.given();
        requestForVerification.header("Content-Type", "application/json");
        requestForVerification.body("{\n    " +
                "\"memberId\": \"" + memberId + "\",\n    " +
                "\"email\": \"" + emailAddress + "\",\n    " +
                "\"emailVerificationDate\": \"04/11/2019\"\n}");

        Response responseForVerification = requestForVerification.patch(baseUri + endpoint);
        ResponseBody body = responseForVerification.getBody();
        bodyStringValue = body.asString();

        System.out.println(bodyStringValue);

        JsonPath jsonPathEvaluatorVerify = responseForVerification.jsonPath();
        String status = jsonPathEvaluatorVerify.get("status");

        DatabaseUtil databaseUtil = new DatabaseUtil();
        int emailVerified = databaseUtil.getMemberVerificationEmailStatus(emailAddress);
        int statusCode = responseForVerification.getStatusCode();

        Assert.assertEquals(200,statusCode);
        Assert.assertEquals(status,"SUCCESS");
        Assert.assertTrue(bodyStringValue.contains("true"));
        Assert.assertEquals(emailVerified, 1);
    }
}
