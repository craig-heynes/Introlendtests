package apitests.verifications;

import apitests.registrant.CreateRegistrantTest;
import data.ApiData;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.testng.annotations.Test;
import util.DatabaseUtil;
import util.EnvironmentReader;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class EmailVerificationTest
{
    private static EnvironmentReader fileReader = new EnvironmentReader();
    String baseUri = fileReader.getApiBaseUri();
    String endpoint = "/verifications";

    @org.testng.annotations.Test (dataProviderClass = ApiData.class, dataProvider = "newVistor")
    public void testEmailVerificationUrl_200(String emailAddress, String visitorId)
    {
        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");

        request.body("{\n    " +
                "\"visitorId\": \"" + visitorId + "\",\n    " +
                "\"email\": \"" + emailAddress + "\",\n    " +
                "\"firstName\": \"Jay\",\n    " +
                "\"lastName\": \"Iron\",\n    " +
                "\"redirectUrl\": \"http://stage3.moneytips.com?utm_source=leadpoint&utm_medium=email&utm_campaign=12345&amp;\"\n}");

        Response response = request.post(baseUri + endpoint);
        ResponseBody body = response.getBody();
        String bodyStringValue = body.asString();
        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");
        int statusCode = response.getStatusCode();

        System.out.println(bodyStringValue);

        Assert.assertEquals(statusCode,200);
        Assert.assertEquals(status,"SUCCESS");
    }

    @org.testng.annotations.Test(dataProviderClass = ApiData.class, dataProvider = "newVistor")
    public void testEmailVerificationUrl_400(String emailAddress, String visitorId)
    {
        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");

        request.body("{\n    " +
                "\"visitorId\": \"" + visitorId + "\",\n    " +
                "\"firstName\": \"Jay\",\n    " +
                "\"lastName\": \"Iron\",\n    " +
                "\"redirectUrl\": \"https://tmm.form.com?AID=LP-email-12345&utm_source=leadpoint&utm_medium=email&utm_campaign=12345\"\n}");

        Response response = request.post(baseUri + endpoint);
        ResponseBody body = response.getBody();
        String bodyStringValue = body.asString();
        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");
        int statusCode = response.getStatusCode();

        System.out.println(bodyStringValue);

        Assert.assertEquals(statusCode,400);
        Assert.assertEquals(status,"FAILED");
    }

    @org.testng.annotations.Test(dataProviderClass = ApiData.class, dataProvider = "createRegistrantEssential")
    public void testEmailVerificationAgainstRegistrant_200(String name, String surname, String emailAddress,
                                                      String password, String visitorId, String planType) throws  Exception
    {
        CreateRegistrantTest createRegistrant = new CreateRegistrantTest();
        createRegistrant.testCreateEssentialRegistrant_200(name, surname, emailAddress, password, visitorId, planType);

        testEmailVerificationUrl_200(emailAddress, visitorId);
        DatabaseUtil getVerificationStatus = new DatabaseUtil();
        String verificationCode = getVerificationStatus.getEmailVerificationCode(emailAddress);

        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");

        request.body("{\n    " +
                "\"email\": \"" + emailAddress + "\",\n    " +
                "\"registrantId\": "+ createRegistrant.getRegistrantIdForTest() +",\n    " +
                "\"verificationCode\": " + verificationCode + "\n}");

        Response response = request.put(baseUri + endpoint);
        ResponseBody body = response.getBody();
        String bodyStringValue = body.asString();
        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");
        int emailVerified = Integer.valueOf(getVerificationStatus.getRegistrantVerificationEmailStatus(emailAddress));
        int statusCode = response.getStatusCode();

        System.out.println(bodyStringValue);

        org.testng.Assert.assertEquals(200,statusCode);
        org.testng.Assert.assertEquals(status,"SUCCESS");
        org.testng.Assert.assertTrue(bodyStringValue.contains("true"));
        org.testng.Assert.assertEquals(1, emailVerified);
    }

    @org.testng.annotations.Test(dataProviderClass = ApiData.class, dataProvider = "createRegistrantEssential")
    public void testSetEmailVerificationAgainstRegistrant_200(String name, String surname, String emailAddress,
                                                         String password, String visitorId, String planType) throws  Exception
    {
        CreateRegistrantTest createRegistrant = new CreateRegistrantTest();
        createRegistrant.testCreateEssentialRegistrant_200(name, surname, emailAddress, password, visitorId, planType);

        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");

        request.body("{\n    " +
                "\"registrantId\": \"" + createRegistrant.getRegistrantIdForTest() +
                "\",\n    \"email\": \"" + emailAddress + "\",\n    " +
                "\"emailVerificationDate\": \"04/11/2019\"\n}");

        Response response = request.patch(baseUri + endpoint);
        ResponseBody body = response.getBody();
        String bodyStringValue = body.asString();
        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");

        DatabaseUtil getVerificationStatus = new DatabaseUtil();

        int emailVerified = Integer.valueOf(getVerificationStatus.getRegistrantVerificationEmailStatus(emailAddress));
        int statusCode = response.getStatusCode();

        System.out.println(bodyStringValue);

        Assert.assertEquals(200,statusCode);
        Assert.assertEquals(status,"SUCCESS");
        Assert.assertTrue(bodyStringValue.contains("true"));
        Assert.assertEquals(1, emailVerified);
    }

    @Test(dataProviderClass = ApiData.class, dataProvider = "createRegistrantEssential")
    public void testSetEmailVerificationAgainstRegistrant_400(String name, String surname, String emailAddress,
                                                         String password, String visitorId, String planType) throws  Exception
    {
        CreateRegistrantTest createRegistrant = new CreateRegistrantTest();
        createRegistrant.testCreateEssentialRegistrant_200(name, surname, emailAddress, password, visitorId, planType);

        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");

        String registrantId = "9999999999";

        request.body("{\n    " +
                "\"registrantId\": \"" + registrantId + "\",\n    " +
                "\"email\": \"" + emailAddress + "\",\n    " +
                "\"emailVerificationDate\": \"04/11/2019\"\n}");

        Response response = request.patch(baseUri + endpoint);
        ResponseBody body = response.getBody();
        String bodyStringValue = body.asString();

        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");
        int statusCode = response.getStatusCode();
        DatabaseUtil getVerificationStatus = new DatabaseUtil();
        int emailVerified = Integer.valueOf(getVerificationStatus.getRegistrantVerificationEmailStatus(emailAddress));

        System.out.println(bodyStringValue);

        Assert.assertEquals(400,statusCode);
        Assert.assertEquals(status,"FAILED");
        Assert.assertEquals(0, emailVerified);
    }
}
