package apitests;

import data.SignUpData;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import pages.SignUpPage;

public class ApiMemberCreate{

    private SignUpPage signUp;
    private WebDriver driver;

    public ApiMemberCreate(WebDriver driver){
        this.driver = driver;
    }

    @Test(dataProvider = "validPremiumCredsThreeQs", dataProviderClass = SignUpData.class )
    public void memberCreateForClientKey(String firstname, String lastname, String email, String password,
                                        String address, String zipcode, String phonenumber, String dob, String ssn4, String ssn9,
                                        String cardnumber, String cardcvv, String cardexpiry, String cardzipcode) throws Exception{

        signUp = new SignUpPage(driver,"premium");
        signUp.setStepOneFields(firstname,lastname,email,password);
        signUp.clickBtnNextStepOne(firstname,lastname,email,password);
        signUp.setStepTwoFields(address,zipcode, phonenumber, dob,ssn4);
        signUp.clickBtnNextStepTwo();
        signUp.setStepTwoSSNNine(ssn9);
        signUp.clickBtnNextAfterSsn9StepTwo();
        signUp.setCorrectAnswersToQuestionsOneToThree();
        signUp.clickIAgreeCheck();
        signUp.clickBtnNextStepTwo();
        System.out.println("Email Address: " + email);
        System.out.println("Password: " + password);
    }
}

