package apitests.email;

import data.ApiRequestBuilder;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.testng.annotations.Test;
import util.EnvironmentReader;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class SignUpEmailTest {

    EnvironmentReader fileReader = new EnvironmentReader();
    ApiRequestBuilder apiRequestBuilder = new ApiRequestBuilder();
    String baseUri = fileReader.getApiBaseUri();
    String endpoint = "/email";

    @org.testng.annotations.Test
    public  void testSignUpEmailWithFromName_200()
    {
        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");

        request.body(apiRequestBuilder.getEmailCreateRequest("d-654b58bfde5046098fe8ac6353fa9071", "ACCOUNT",
                "mtstage1@gmail.com", "Call Center Create Password", "MoneyTips",
                "test subject", "account@account.moneytips.com", "TMM Form Server",
                "https://www.moneytips.com", "MGE").toJSONString());

        Response response = request.post(baseUri + endpoint);
        ResponseBody body = response.getBody();

        String bodyStringValue = body.asString();
        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");
        int statusCode = response.getStatusCode();

        System.out.println(bodyStringValue);

        Assert.assertEquals(200,statusCode);
        Assert.assertEquals(status,"SUCCESS");
        Assert.assertTrue(bodyStringValue.contains("true"));
    }

    @org.testng.annotations.Test
    public  void testSignUpEmailWithoutFromName_200()
    {
        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");

        request.body(apiRequestBuilder.getEmailCreateRequest("d-654b58bfde5046098fe8ac6353fa9071", "ACCOUNT",
                "mtstage1@gmail.com", "Call Center Create Password", "MoneyTips",
                "test subject", "account@account.moneytips.com", null,
                "https://www.moneytips.com", "MGE").toJSONString());

        Response response = request.post(baseUri + endpoint);
        ResponseBody body = response.getBody();

        String bodyStringValue = body.asString();
        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");
        int statusCode = response.getStatusCode();

        System.out.println(bodyStringValue);

        Assert.assertEquals(200,statusCode);
        Assert.assertEquals(status,"SUCCESS");
        Assert.assertTrue(bodyStringValue.contains("true"));
    }

    @Test
    public void testSignUpEmail_400()
    {

        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");

        request.body(apiRequestBuilder.getEmailCreateRequest("d-654b58bfde5046098fe8ac6353fa9071", "ACCOUNT",
                null, "Call Center Create Password", "MoneyTips",
                "test subject", "account@account.moneytips.com", null,
                "https://www.moneytips.com", "MGE").toJSONString());

        Response response = request.post(baseUri + endpoint);
        ResponseBody body = response.getBody();

        String bodyStringValue = body.asString();
        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");
        int statusCode = response.getStatusCode();

        System.out.println(bodyStringValue);

        Assert.assertEquals(400,statusCode);
        Assert.assertEquals(status,"FAILED");
    }
}
