package apitests.sms;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.testng.annotations.Test;
import util.EnvironmentReader;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class SignUpSmsTest {

    EnvironmentReader fileReader = new EnvironmentReader();
    String mobileNumber = "9072001212";
    String baseUri = fileReader.getApiBaseUri();
    String endpoint = "/sms";

    @org.testng.annotations.Test
    public  void testSignUpSms_200()
    {
        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");

        request.body("{\n    " +
                "\"mobileNumber\": \"" + mobileNumber + "\",\n    " +
                "\"body\": \"test sms body text\"\n    " +
                "}\n}");

        Response response = request.post(baseUri + endpoint);
        ResponseBody body = response.getBody();
        String bodyStringValue = body.asString();

        System.out.println(bodyStringValue);

        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");

        int statusCode = response.getStatusCode();

        Assert.assertEquals(200,statusCode);
        Assert.assertEquals(status,"SUCCESS");
        Assert.assertTrue(bodyStringValue.contains("true"));
    }

    @Test
    public void testSignUpSms_400()
    {
        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");

        request.body("{\n    " +
                "\"mobileNumber\": \"" + "" + "\",\n    " +
                "\"body\": \"test sms body text\"\n    " +
                "}\n}");

        Response response = request.post(baseUri + endpoint);
        ResponseBody body = response.getBody();
        String bodyStringValue = body.asString();

        System.out.println(bodyStringValue);

        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");
        int statusCode = response.getStatusCode();

        Assert.assertEquals(400,statusCode);
        Assert.assertEquals(status,"FAILED");
        Assert.assertTrue(bodyStringValue.contains("Mobile Number is Invalid"));
    }
}
