package apitests.introlend;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.testng.annotations.Test;
import util.EnvironmentReader;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RealtorTMMDataTest {

    private static EnvironmentReader fileReader = new EnvironmentReader();
    private static String baseUri = fileReader.getApiBaseUri();
    private static String endpoint = "/professional/real-estate-agent/";
    private static String validRealtor = "06ce4a12-9b9d-4757-86e7-a3b798d57c89";
    private static String invalidRealtor = "invalidrealtor";

    @org.testng.annotations.Test
    public  void testValidRealtorResponse()
    {
        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");
        request.header("Token", "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIwNmNlNGExMi05" +
                "YjlkLTQ3NTctODZlNy1hM2I3OThkNTdjODkiLCJpby5hdmVudS5jbGFpbXMuZmlyc3RuYW1lIjoiSG91Z2giLCJpby5hdmVudS5j" +
                "bGFpbXMucGhvbmVudW1iZXIiOiI4MDEyMzIzNDIzIiwiaW8uYXZlbnUuY2xhaW1zLmNhbl9zdWJtaXRfbG9hbl9hcHBsaWNhdGlv" +
                "bnMiOiJ0cnVlIiwiaXNzIjoiY29tLmxlYWRwb2ludC5pZGVudGl0eSIsImlvLmF2ZW51LmNsYWltcy5lbnJpY2hlZCI6InRydWUi" +
                "LCJpby5hdmVudS5jbGFpbXMub3JnYW5pemF0aW9uaWQiOiJDQ0JCNTY4Qy0yODNFLTQ1MTYtQTg0MC01QTczQjJBRDE0OUEiLCJh" +
                "dWQiOiJhdmVudSIsImlvLmF2ZW51LmNsYWltcy5jYW5fY3JlYXRlX2xvYW5fYXBwbGljYXRpb25zIjoidHJ1ZSIsImlvLmF2ZW51" +
                "LmNsYWltcy5jYW5fcmVhZF9sb29rdXBzIjoidHJ1ZSIsIm5iZiI6MTU2NzU5ODQyNSwiaW8uYXZlbnUuY2xhaW1zLnVzZXJzdGF0" +
                "dXMiOiJBY3RpdmUiLCJpby5hdmVudS5jbGFpbXMuY2FuX21hbmFnZV9sb2FuX2FwcGxpY2F0aW9ucyI6InRydWUiLCJpby5hdmVu" +
                "dS5jbGFpbXMubGFzdG5hbWUiOiJ2YW4gV3lrIiwiaW8uYXZlbnUuY2xhaW1zLnJvbGUiOiJBR0VOVCIsImV4cCI6MTU2NzY4NDgy" +
                "NSwianRpIjoiZTgyZjc2YWUtZmVlZi00NWUzLTg2NTEtMDk2MTk5YTM0YzBjIiwiZW1haWwiOiJob3VnaEBlc3RhbGVhLmNvbSJ9" +
                ".9GUwC_Y5pTFE2r_sujD3WQT1CNB8jdrAdlQVbQiGiVc");

        Response response = request.get(baseUri + endpoint + validRealtor);
        ResponseBody body = response.getBody();
        String bodyStringValue = body.asString();
        System.out.println(bodyStringValue);
        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");
        int statusCode = response.getStatusCode();

        org.testng.Assert.assertEquals(200,statusCode);
        org.testng.Assert.assertEquals(status,"SUCCESS");
        org.testng.Assert.assertTrue(bodyStringValue.contains("Hough van Wyk"));
    }

    @Test
    public  void testInvalidRealtorResponse()
    {
        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");
        request.header("Token", "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIwNmNlNGExMi05YjlkLTQ3NTctODZlNy1hM2I3OThkNTdjODkiLCJpby5hdmVudS5jbGFpbXMuZmlyc3RuYW1lIjoiSG91Z2giLCJpby5hdmVudS5jbGFpbXMucGhvbmVudW1iZXIiOiI4MDEyMzIzNDIzIiwiaW8uYXZlbnUuY2xhaW1zLmNhbl9zdWJtaXRfbG9hbl9hcHBsaWNhdGlvbnMiOiJ0cnVlIiwiaXNzIjoiY29tLmxlYWRwb2ludC5pZGVudGl0eSIsImlvLmF2ZW51LmNsYWltcy5lbnJpY2hlZCI6InRydWUiLCJpby5hdmVudS5jbGFpbXMub3JnYW5pemF0aW9uaWQiOiJDQ0JCNTY4Qy0yODNFLTQ1MTYtQTg0MC01QTczQjJBRDE0OUEiLCJhdWQiOiJhdmVudSIsImlvLmF2ZW51LmNsYWltcy5jYW5fY3JlYXRlX2xvYW5fYXBwbGljYXRpb25zIjoidHJ1ZSIsImlvLmF2ZW51LmNsYWltcy5jYW5fcmVhZF9sb29rdXBzIjoidHJ1ZSIsIm5iZiI6MTU2NzU5ODQyNSwiaW8uYXZlbnUuY2xhaW1zLnVzZXJzdGF0dXMiOiJBY3RpdmUiLCJpby5hdmVudS5jbGFpbXMuY2FuX21hbmFnZV9sb2FuX2FwcGxpY2F0aW9ucyI6InRydWUiLCJpby5hdmVudS5jbGFpbXMubGFzdG5hbWUiOiJ2YW4gV3lrIiwiaW8uYXZlbnUuY2xhaW1zLnJvbGUiOiJBR0VOVCIsImV4cCI6MTU2NzY4NDgyNSwianRpIjoiZTgyZjc2YWUtZmVlZi00NWUzLTg2NTEtMDk2MTk5YTM0YzBjIiwiZW1haWwiOiJob3VnaEBlc3RhbGVhLmNvbSJ9.9GUwC_Y5pTFE2r_sujD3WQT1CNB8jdrAdlQVbQiGiVc");
        String path = baseUri + endpoint + invalidRealtor;
        Response response = request.get(path);
        ResponseBody body = response.getBody();
        String bodyStringValue = body.asString();
        System.out.println(bodyStringValue);
        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");
        int statusCode = response.getStatusCode();

        org.testng.Assert.assertEquals(400,statusCode);
        org.testng.Assert.assertEquals(status,"FAILED");
        org.testng.Assert.assertTrue(bodyStringValue.contains("FETCH_DATA_FROM_INTROLEND_FAILED"));
    }
}
