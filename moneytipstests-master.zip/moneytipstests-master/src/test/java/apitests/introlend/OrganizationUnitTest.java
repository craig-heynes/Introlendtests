package apitests.introlend;

import data.ApiData;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.testng.annotations.Test;
import util.EnvironmentReader;

import java.util.Map;
import java.util.UUID;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class OrganizationUnitTest {

    private static EnvironmentReader fileReader = new EnvironmentReader();
    private static String loanApplicationID;
    String baseUri = fileReader.getApiBaseUri();
    private static String endpoint = "/introlend/application";

    @org.testng.annotations.Test (dataProviderClass = ApiData.class, dataProvider = "createApplicationId")
    public void a_getApplicationId(String token) throws Exception
    {
        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");
        request.header("x-requestid", UUID.randomUUID());
        request.header("Authorization", "Bearer " + token);

        request.body("{\n " +
                "\"externalID\": \"8d7b1504-ceae-41a3-8edb-994ac9985c12\",\n" +
                "\"firstName\": \"Joel\",\n" +
                "\"lastName\": \"Arbic\",\n" +
                "\"emailAddress\": \"mtstage1+566545@gmail.com\",\n" +
                "\"mobilePhoneNumber\": \"4045049000\",\n" +
                "\"address1\": \"101 1st Ave\",\n" +
                "\"unitNumber\": \"string\",\n" +
                "\"city\": \"New York\",\n" +
                "\"state\": \"NY\",\n" +
                "\"zipCode\": \"10025\",\n" +
                "\"loanOfficers\": [\n {\n" +
                "\"guid\": \"93667bc0-0626-40c0-a4cb-c60bc56e9b7f\",\n" +
                "\"firstName\": \"Jim\",\n" +
                "\"lastName\": \"Officer\",\n" +
                "\"emailAddress\": \"mtstage1+90@gmail.com\",\n" +
                "\"phoneNumber\": \"4045049001\",\n" +
                "\"companyName\": \"Real Co\"\n},\n        {\n" +
                "\"guid\": \"93667bc0-0626-40c0-a4cb-c60bc56e9b7c\",\n" +
                "\"firstName\": \"Beans\",\n" +
                "\"lastName\": \"Officer2\",\n" +
                "\"emailAddress\": \"mtstage1+91@gmail.com\",\n" +
                "\"phoneNumber\": \"4045049002\",\n" +
                "\"companyName\": \"Real Co2\"\n        }\n    ],\n    " +
                "\"suppressUserCorrespondence\": false,\n    " +
                "\"suppressLenderCorrespondence\": false\n}");

        Response response = request.post("https://lending-api-dev.avenu.io/api/v1/Mortgage");

        JsonPath jsonPathEvaluator = response.jsonPath();
        loanApplicationID = jsonPathEvaluator.get("applicationID");
        System.out.println(loanApplicationID);
        int statusCode = response.getStatusCode();

        org.testng.Assert.assertEquals(200,statusCode);
    }

    @org.testng.annotations.Test
    public void testOrganizationUnit200()
    {
        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");

        request.body("{\n    " +
                "\"loanApplicationID\": \"" + loanApplicationID + "\"\n}");

        Response response = request.post(baseUri + endpoint);
        ResponseBody body = response.getBody();
        String bodyStringValue = body.asString();
        System.out.println(bodyStringValue);

        JsonPath jsonPathEvaluator = response.jsonPath();

        Map<String, String> successResponseMap = jsonPathEvaluator.get("response");
        Object state = successResponseMap.get("state");
        Object nmls = successResponseMap.get("nmls");
        Object chapter = successResponseMap.get("chapter");

        String status = jsonPathEvaluator.get("status");
        int statusCode = response.getStatusCode();

        org.testng.Assert.assertEquals(200,statusCode);
        org.testng.Assert.assertEquals("SUCCESS", status);
        org.testng.Assert.assertEquals("UT", state.toString());
        org.testng.Assert.assertEquals("NMLS123", nmls.toString());
        org.testng.Assert.assertEquals("IntroLend LeadPoint", chapter.toString());
    }

    @Test
    public void testOrganizationUnit400()
    {
        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");

        request.body("{\n    " +
                "\"loanApplicationID\": \"444444444444444\"\n}");

        Response response = request.post(baseUri + endpoint);
        ResponseBody body = response.getBody();
        String bodyStringValue = body.asString();
        System.out.println(bodyStringValue);

        JsonPath jsonPathEvaluator = response.jsonPath();

        String status = jsonPathEvaluator.get("status");
        int statusCode = response.getStatusCode();

        org.testng.Assert.assertEquals(400,statusCode);
        org.testng.Assert.assertEquals(status,"FAILED");
    }
}
