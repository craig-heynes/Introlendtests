package apitests.bttoken;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import org.junit.Assert;
import org.testng.annotations.Test;
import util.EnvironmentReader;

public class BtTokenTest {

    private static EnvironmentReader fileReader = new EnvironmentReader();
    String baseUri = fileReader.getApiBaseUri();
    String endpoint = "/bt-token";

    @Test
    public void testBtToken()
    {
        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");
        Response response = request.get(baseUri + endpoint);

        ResponseBody body = response.getBody();
        String bodyStringValue = body.asString();
        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");
        int statusCode = response.getStatusCode();

        System.out.println(bodyStringValue);

        Assert.assertEquals(200,statusCode);
        Assert.assertEquals(status,"SUCCESS");
    }
}
