package apitests.member.otp;

import apitests.member.ApiResponseHandler;
import apitests.registrant.CreateRegistrantTest;
import data.ApiData;
import data.ApiRequestBuilder;
import helperutil.CCMClientKey;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import org.testng.annotations.Test;
import util.DatabaseUtil;
import util.EnvironmentReader;
import util.UrlBuilder;

public class EssentialMemberFromRegistrantOTP_200_Purchase
{
    String clientKey;
    EnvironmentReader fileReader = new EnvironmentReader();
    CreateRegistrantTest createRegistrant = new CreateRegistrantTest();
    DatabaseUtil databaseUtil = new DatabaseUtil();
    UrlBuilder urlBuilder = new UrlBuilder();
    String baseUrl = fileReader.getApplicationUrl();
    String baseUri = fileReader.getApiBaseUri();
    ApiRequestBuilder apiRequestBuilder = new ApiRequestBuilder();

    private static final String endpoint = "/members";
    private static final String emailendpoint = "/verifications";
    private static final String phoneEndpoint = "/phone/verification";

    @Test(dataProvider = "createEssentialMember", dataProviderClass = ApiData.class)
    public void createMember (String emailAddress, String password, String visitorId, String firstName,
                              String lastName, String address, String zipCode, String dateOfBirth,
                              String phoneNumber, String ssn9, String planType, String redirectUrl, Boolean threeBTest,
                              String city, String state, String ccmDob) throws Exception
    {
        redirectUrl = "/mortgage-application";
        String loanPurpose = "Purchase";

//        ApiMemberCreate memberCreate = new ApiMemberCreate (getDriver());
//        memberCreate.memberCreateForClientKey(firstName, lastName, emailAddress, password, address,
//                zipCode, phoneNumber, dateOfBirth, "1234", ssn9, "fakecard", "fakecvv",
//                "fakeexpiry", "fakezipcode");
//
//        LoggingDatabaseUtil loggingDbUtil = new LoggingDatabaseUtil();

        CCMClientKey getNewClientKey = new CCMClientKey();
        clientKey = getNewClientKey.getClientKey(firstName, lastName, ccmDob, address, city, state, zipCode, phoneNumber, emailAddress, ssn9);

        createRegistrant.testCreateEssentialRegistrantAllFields_200(firstName, lastName, emailAddress, password, visitorId, address,
                "city", "state", zipCode, dateOfBirth, phoneNumber, clientKey, planType, "MT_OVER_THE_PHONE", loanPurpose, null);

        //set email verification
        RequestSpecification requestSetEmail = RestAssured.given();
        requestSetEmail.header("Content-Type", "application/json");
        requestSetEmail.body(apiRequestBuilder.getEmailVerificationRequestForRegistrant(emailAddress , "04/11/2019"));

        Response responseEmailApi = requestSetEmail.patch(baseUri + emailendpoint);

        ResponseBody body = responseEmailApi.getBody();
        String bodyStringValue = body.asString();
        System.out.println("Email Verification: " + bodyStringValue);

        //set phoneverification
        RequestSpecification requestSetPhone = RestAssured.given();
        requestSetPhone.header("Content-Type", "application/json");
        requestSetPhone.body(apiRequestBuilder.getMobileVerificationRequestForRegistrant("3012089857","04/11/2019"));
        Response responsePhoneApi = requestSetPhone.put(baseUri + phoneEndpoint);

        body = responsePhoneApi.getBody();
        bodyStringValue = body.asString();
        System.out.println("Phone Verification: " + bodyStringValue);

        //create member
        RequestSpecification requestEnroll = RestAssured.given();
        requestEnroll.header("Content-Type", "application/json");

        requestEnroll.body(apiRequestBuilder.getMemberCreateRequestFromRegistrant(redirectUrl));
        Response response = requestEnroll.post(baseUri + endpoint);

        ApiResponseHandler responseHandler = new ApiResponseHandler();
        responseHandler.onExpectedSuccess(response, emailAddress, planType, clientKey, redirectUrl);

        org.testng.Assert.assertEquals(databaseUtil.getMemberVerificationEmailStatus(emailAddress), 1);
        org.testng.Assert.assertEquals(databaseUtil.getMemberVerificationMobileStatus(emailAddress), 1);
        org.testng.Assert.assertEquals(databaseUtil.getMemberSignUpSource(emailAddress), "MT_OVER_THE_PHONE");

        String[] applicationSet = databaseUtil.getApplicationSetForMember(emailAddress);

        org.testng.Assert.assertEquals(applicationSet[0], "PURCHASE");
    }
}
