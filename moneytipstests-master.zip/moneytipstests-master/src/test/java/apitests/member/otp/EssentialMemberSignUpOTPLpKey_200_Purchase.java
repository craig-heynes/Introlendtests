package apitests.member.otp;

import apitests.ApiBaseTest2;
import apitests.member.ApiResponseHandler;
import data.ApiData;
import data.ApiRequestBuilder;
import helperutil.CCMClientKey;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.annotations.Test;
import util.DatabaseUtil;
import util.EnvironmentReader;

public class EssentialMemberSignUpOTPLpKey_200_Purchase extends ApiBaseTest2
{
    String clientKey;
    EnvironmentReader fileReader = new EnvironmentReader();
    String baseUri = fileReader.getApiBaseUri();
    ApiRequestBuilder apiRequestBuilder = new ApiRequestBuilder();
    DatabaseUtil databaseUtil = new DatabaseUtil();

    private static final String endpoint = "/members";

    @Test(dataProvider = "createEssentialMember", dataProviderClass = ApiData.class)
    public void createEssentialMember (String emailAddress, String password, String visitorId, String firstName, String lastName,
                                       String address, String zipCode, String dateOfBirth, String phoneNumber,
                                       String ssn9, String planType, String redirectUrl, Boolean doThreeBTest,
                                       String city, String state, String ccmDob) throws Exception
    {
        String lpKey = "OHg1NDUzOTA4OW1WOUdaaUlBOUlPY2E5ZG9DcElWM0xJVEV4Yz0";
        databaseUtil.clearLpKey(lpKey);
        redirectUrl = "/mortgage-application";
        String loanPurpose = "Purchase";

//        ApiMemberCreate memberCreate = new ApiMemberCreate (getDriver());
//        memberCreate.memberCreateForClientKey(firstName, lastName, emailAddress, password, address,
//                zipCode, phoneNumber, dateOfBirth, "1234", ssn9, "fakecard", "fakecvv",
//                "fakeexpiry", "fakezipcode");
//
//        LoggingDatabaseUtil loggingDatabaseUtil = new LoggingDatabaseUtil();

        CCMClientKey getNewClientKey = new CCMClientKey();
        clientKey = getNewClientKey.getClientKey(firstName, lastName, ccmDob, address, city, state, zipCode, phoneNumber, emailAddress, ssn9);

        RequestSpecification requestEnrollTC1 = RestAssured.given();
        requestEnrollTC1.header("Content-Type", "application/json");

        requestEnrollTC1.body(apiRequestBuilder.getMemberCreateRequestForEssential(emailAddress, password, visitorId, firstName, lastName, address, zipCode, dateOfBirth, phoneNumber,
                ssn9, planType, redirectUrl, clientKey, loanPurpose, "OTP", lpKey).toJSONString());

        Response response = requestEnrollTC1.post(baseUri + endpoint);
        ApiResponseHandler responseHandler = new ApiResponseHandler();
        responseHandler.onExpectedSuccess(response, emailAddress, planType, clientKey, redirectUrl);
    }
}
