package apitests.member.threeB;

import apitests.ApiBaseTest2;
import apitests.ApiMemberCreate;
import data.ApiData;
import data.ApiRequestBuilder;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import util.EnvironmentReader;
import util.LoggingDatabaseUtil;

import java.util.Map;

public class buyThreeBTest_200 extends ApiBaseTest2
{
    private static EnvironmentReader fileReader = new EnvironmentReader();
    private static String baseUri = fileReader.getApiBaseUri();
    private static String endpoint = "/bt/three-b/purchase";
    private static final String memberEndpoint = "/members";

    @org.testng.annotations.Test (dataProviderClass = ApiData.class, dataProvider = "createEssentialMemberForThreeB")
    public void buyThreeBTest_200(String emailAddress, String password, String visitorId, String firstName, String lastName,
                                      String address, String zipCode, String dateOfBirth, String phoneNumber, String ssn9, String planType, String redirectUrl, Boolean threeBTest) throws Exception
    {
        String environment = fileReader.getccmEndPoint();

        if (environment.contains("stage-1"))
        {
            ApiMemberCreate memberCreate = new ApiMemberCreate (getDriver());

            memberCreate.memberCreateForClientKey(firstName, lastName, emailAddress, password, address,
                    zipCode, phoneNumber, dateOfBirth, "1234", ssn9, "fakecard", "fakecvv",
                    "fakeexpiry", "fakezipcode");

            LoggingDatabaseUtil loggingDatabaseUtil = new LoggingDatabaseUtil();
            String clientKey = loggingDatabaseUtil.getClientKeyForApiEnrollByEmail(emailAddress);

            RequestSpecification requestEnrollTC1 = RestAssured.given();
            requestEnrollTC1.header("Content-Type", "application/json");

            ApiRequestBuilder apiRequestBuilder = new ApiRequestBuilder();
            requestEnrollTC1.body(apiRequestBuilder.getMemberCreateRequestForEssential(emailAddress, password, visitorId, firstName, lastName, address, zipCode, dateOfBirth, phoneNumber,
                    ssn9, planType, redirectUrl, clientKey, null, null, null).toJSONString());

            Response memberResponse = requestEnrollTC1.post(baseUri + memberEndpoint);

            ResponseBody body = memberResponse.getBody();
            String bodyStringValue = body.asString();

            System.out.println(bodyStringValue);

            JsonPath jsonPathEvaluator = memberResponse.jsonPath();
            Map<String, String> successResponseMap = jsonPathEvaluator.get("response");
            Object value = successResponseMap.get("memberId");
            String memberId = value.toString();

            RequestSpecification requestEnroll = RestAssured.given();
            requestEnroll.header("Content-Type", "application/json");

            ApiRequestBuilder requestBuilder = new ApiRequestBuilder();
            requestEnroll.body(requestBuilder.getThreeBPurchaseRequest(memberId,"29.99").toJSONString());
            Response response = requestEnroll.post(baseUri + endpoint);
            body = response.getBody();
            bodyStringValue = body.asString();

            System.out.println(bodyStringValue);

            jsonPathEvaluator = response.jsonPath();
            String status = jsonPathEvaluator.get("status");
            int statusCode = response.getStatusCode();

            org.testng.Assert.assertEquals(200,statusCode);
            org.testng.Assert.assertEquals(status,"SUCCESS");
        }
        else {
            System.out.println("Cannot run test as we are not pointing to ccm-stage-1");
            return;
        }
    }
}
