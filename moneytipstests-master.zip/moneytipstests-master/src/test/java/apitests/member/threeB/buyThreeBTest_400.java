package apitests.member.threeB;

import data.ApiRequestBuilder;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import org.testng.annotations.Test;
import util.EnvironmentReader;

public class buyThreeBTest_400
{
    private static EnvironmentReader fileReader = new EnvironmentReader();
    private static String baseUri = fileReader.getApiBaseUri();
    private static String endpoint = "/bt/three-b/purchase";

    @Test
    public void buyThreeBTest_400()
    {
        String environment = fileReader.getccmEndPoint();

        if (environment.contains("stage-1"))
        {
            RequestSpecification requestEnroll = RestAssured.given();
            requestEnroll.header("Content-Type", "application/json");

            ApiRequestBuilder requestBuilder = new ApiRequestBuilder();
            requestEnroll.body(requestBuilder.getThreeBPurchaseRequest("1234","29.99").toJSONString());

            Response response = requestEnroll.post(baseUri + endpoint);
            ResponseBody body = response.getBody();
            String bodyStringValue = body.asString();

            System.out.println(bodyStringValue);

            JsonPath jsonPathEvaluator = response.jsonPath();
            String status = jsonPathEvaluator.get("status");
            int statusCode = response.getStatusCode();

            org.testng.Assert.assertEquals(400, statusCode);
            org.testng.Assert.assertEquals(status,"FAILED");
            org.testng.Assert.assertTrue(bodyStringValue.contains("memberId is invalid"));
        }
        else {
            System.out.println("Cannot run test as we are not pointing to ccm-stage-1");
            return;
        }
    }
}
