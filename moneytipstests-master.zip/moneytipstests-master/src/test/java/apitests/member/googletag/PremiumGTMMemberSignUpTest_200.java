package apitests.member.googletag;

import apitests.ApiAutoLogin1;
import apitests.ApiBaseTest2;
import apitests.ApiMemberCreate;
import apitests.member.ApiResponseHandler;
import data.ApiData;
import data.ApiRequestBuilder;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.annotations.Test;
import util.EnvironmentReader;
import util.LoggingDatabaseUtil;
import util.UrlBuilder;

import java.util.Map;

public class PremiumGTMMemberSignUpTest_200 extends ApiBaseTest2
{
    String clientKey;
    EnvironmentReader fileReader = new EnvironmentReader();
    LoggingDatabaseUtil loggingDatabaseUtil = new LoggingDatabaseUtil();
    String baseUri = fileReader.getApiBaseUri();
    ApiRequestBuilder apiRequestBuilder = new ApiRequestBuilder();

    private static final String endpoint = "/members";

    @Test(dataProvider = "createPremiumMember", dataProviderClass = ApiData.class)
    public void createPremiumMember (String emailAddress, String password, String visitorId, String firstName, String lastName,
                                     String address, String zipCode, String dateOfBirth, String phoneNumber, String ssn9, String planType,
                                     String nonce, String btSubscriptionPlan, String redirectUrl,
                                     String city, String state, String ccmDob) throws Exception
    {
        ApiMemberCreate memberCreate = new ApiMemberCreate (getDriver());
        memberCreate.memberCreateForClientKey(firstName, lastName, emailAddress, password, address,
                zipCode, phoneNumber, dateOfBirth, "1234", ssn9, "fakecard", "fakecvv",
                "fakeexpiry", "fakezipcode");

        clientKey = loggingDatabaseUtil.getClientKeyForApiEnrollByEmail(emailAddress);

        RequestSpecification requestEnroll = RestAssured.given();
        requestEnroll.header("Content-Type", "application/json");

        requestEnroll.body(apiRequestBuilder.getMemberCreateRequestForPremium
                (emailAddress, password, visitorId, firstName, lastName, address, zipCode,
                        dateOfBirth, phoneNumber, ssn9, planType, redirectUrl, clientKey,
                        nonce, btSubscriptionPlan).toJSONString());

        Response response = requestEnroll.post(baseUri + endpoint);

        String authToken;
        JsonPath jsonPathEvaluator = response.jsonPath();
        Map<String, String> successResponseMap = jsonPathEvaluator.get("response");

        UrlBuilder urlBuilder = new UrlBuilder();
        ApiResponseHandler apiResponseHandler = new ApiResponseHandler();
        Object value = successResponseMap.get("authToken");
        authToken = value.toString();
        ApiAutoLogin1 login = new ApiAutoLogin1(getDriver(),urlBuilder.getAutoLoginUrl(planType,clientKey,authToken), redirectUrl);
        login.testLogin();
        apiResponseHandler.verifyGTM(planType, getDriver());
    }
}
