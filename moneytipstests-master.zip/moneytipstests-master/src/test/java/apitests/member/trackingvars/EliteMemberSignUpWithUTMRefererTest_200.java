package apitests.member.trackingvars;

import apitests.ApiBaseTest2;
import apitests.ApiMemberCreate;
import apitests.member.ApiResponseHandler;
import data.ApiData;
import data.ApiRequestBuilder;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.Assert;
import org.testng.annotations.Test;
import util.DatabaseUtil;
import util.EnvironmentReader;
import util.LoggingDatabaseUtil;
import util.UrlBuilder;

import java.util.Map;


public class EliteMemberSignUpWithUTMRefererTest_200 extends ApiBaseTest2
{
    String clientKey;
    EnvironmentReader fileReader = new EnvironmentReader();
    DatabaseUtil databaseUtil = new DatabaseUtil();
    String baseUri = fileReader.getApiBaseUri();
    ApiRequestBuilder apiRequestBuilder = new ApiRequestBuilder();
    UrlBuilder urlBuilder = new UrlBuilder();
    String baseUrl = fileReader.getApplicationUrl();

    private static final String endpoint = "/members";

    @Test(dataProvider = "createEliteMember", dataProviderClass = ApiData.class)
    public void createMember (String emailAddress, String password, String visitorId, String firstName, String lastName,
                              String address, String zipCode, String dateOfBirth, String phoneNumber, String ssn9, String planType,
                              String nonce, String btSubscriptionPlan, String redirectUrl,
                              String city, String state, String ccmDob) throws Exception
    {
        ApiMemberCreate memberCreate = new ApiMemberCreate (getDriver());
        memberCreate.memberCreateForClientKey(firstName, lastName, emailAddress, password, address,
                zipCode, phoneNumber, dateOfBirth, "1234", ssn9, "fakecard", "fakecvv",
                "fakeexpiry", "fakezipcode");

        LoggingDatabaseUtil loggingDatabaseUtil = new LoggingDatabaseUtil();
        clientKey = loggingDatabaseUtil.getClientKeyForApiEnrollByEmail(emailAddress);

        Response response;
        String utm_source = "utm_source=Bing";
        String utm_medium = "utm_medium=Search";
        String utm_campaign = "utm_campaign=Headterms";
        String utm_content = "utm_content=Moneytips-general-free-credit-score";
        String utm_term = "utm_term=General";
        String referer_url = "https://www.google.com";
        String referer_domain = "www.google.com";

        RequestSpecification requestEnroll = RestAssured.given();
        requestEnroll.header("Content-Type", "application/json");
        requestEnroll.header("Referer", referer_url);

        requestEnroll.body(apiRequestBuilder.getMemberCreateRequestForPremium(emailAddress, password, visitorId, firstName, lastName, address, zipCode, dateOfBirth, phoneNumber,
                ssn9, planType, redirectUrl, clientKey, nonce, btSubscriptionPlan).toJSONString());

        response = requestEnroll.post(baseUri + endpoint + "?" + utm_source + "&" + utm_medium + "&" + utm_campaign + "&" + utm_content + "&" + utm_term);

        ApiResponseHandler responseHandler = new ApiResponseHandler();
        responseHandler.onExpectedSuccess(response, emailAddress, planType, clientKey, redirectUrl);

        String authToken;
        JsonPath jsonPathEvaluator = response.jsonPath();
        Map<String, String> successResponseMap = jsonPathEvaluator.get("response");

        if (successResponseMap.containsKey("authToken")) {
            Object value = successResponseMap.get("authToken");
            authToken = value.toString();
            getDriver().navigate().to((baseUrl + urlBuilder.getAutoLoginUrl(planType, clientKey, authToken)));
            Thread.sleep(10000);
            Assert.assertTrue(getDriver().getCurrentUrl().contains(redirectUrl));
            Assert.assertEquals(utm_source + "&" + utm_medium + "&" + utm_campaign + "&" + utm_content + "&" + utm_term + "&landing_referer_url=" +
                    referer_url + "&landing_referrer_domain=" + referer_domain, databaseUtil.getTrackingVars(emailAddress));
            Assert.assertEquals(referer_url, databaseUtil.getLandingRefererUrl(emailAddress));
            Assert.assertEquals(referer_domain, databaseUtil.getLandingRefererDomain(emailAddress));
        }
    }
}
