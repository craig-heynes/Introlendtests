package apitests.member.trackingvars;

import apitests.ApiBaseTest2;
import apitests.ApiMemberCreate;
import apitests.member.ApiResponseHandler;
import data.ApiData;
import data.ApiRequestBuilder;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.Assert;
import org.testng.annotations.Test;
import util.DatabaseUtil;
import util.EnvironmentReader;
import util.LoggingDatabaseUtil;

public class PremiumMemberSignUpWithUTMTest_200 extends ApiBaseTest2
{
    String clientKey;
    EnvironmentReader fileReader = new EnvironmentReader();
    DatabaseUtil databaseUtil = new DatabaseUtil();
    String baseUri = fileReader.getApiBaseUri();
    ApiRequestBuilder apiRequestBuilder = new ApiRequestBuilder();
    LoggingDatabaseUtil loggingDbUtil = new LoggingDatabaseUtil();

    private static final String endpoint = "/members";

    @Test(dataProvider = "createPremiumMember", dataProviderClass = ApiData.class)
    public void createMember (String emailAddress, String password, String visitorId, String firstName, String lastName,
                              String address, String zipCode, String dateOfBirth, String phoneNumber, String ssn9, String planType,
                              String nonce, String btSubscriptionPlan, String redirectUrl,
                              String city, String state, String ccmDob) throws Exception
    {
        ApiMemberCreate memberCreate = new ApiMemberCreate (getDriver());
        memberCreate.memberCreateForClientKey(firstName, lastName, emailAddress, password, address,
                zipCode, phoneNumber, dateOfBirth, "1234", ssn9, "fakecard", "fakecvv",
                "fakeexpiry", "fakezipcode");

        clientKey = loggingDbUtil.getClientKeyForApiEnrollByEmail(emailAddress);

        RequestSpecification requestEnroll = RestAssured.given();
        requestEnroll.header("Content-Type", "application/json");

        requestEnroll.body(apiRequestBuilder.getMemberCreateRequestForPremium(emailAddress,
                password, visitorId, firstName, lastName, address, zipCode, dateOfBirth,
                phoneNumber, ssn9, planType, redirectUrl, clientKey, nonce, btSubscriptionPlan).toJSONString());

        String utm_source = "utm_source=Facebook-Ads";
        String utm_medium = "utm_medium=static-single_image";
        String utm_campaign = "utm_campaign=MT-brand";
        String utm_content = "utm_content=Positive";
        String utm_term = "utm_term=Prospecting";

        Response response = requestEnroll.post(baseUri + endpoint + "?" + utm_source + "&" + utm_medium + "&" + utm_campaign + "&" + utm_content + "&" + utm_term);
        ApiResponseHandler responseHandler = new ApiResponseHandler();
        responseHandler.onExpectedSuccess(response, emailAddress, planType, clientKey, redirectUrl);

        Assert.assertEquals(utm_source + "&" + utm_medium + "&" + utm_campaign + "&" + utm_content + "&" + utm_term, databaseUtil.getTrackingVars(emailAddress));
    }
}
