package apitests.member.introlend;

import apitests.ApiMemberCreate;
import data.ApiData;
import data.IntroLendRequestBuilder;
import helperutil.CCMClientKey;
import helperutil.IntroLendHelper;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.MortgageApplicationPage;
import uitests.base.CreateEssentialMember;
import util.DatabaseUtil;
import util.EnvironmentReader;
import util.LoggingDatabaseUtil;
import util.UrlBuilder;

import java.util.Map;
import java.util.UUID;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class FastTrackRefinanceTest
{
    EnvironmentReader fileReader = new EnvironmentReader();
    IntroLendRequestBuilder  requestBuilder = new IntroLendRequestBuilder();
    ApiMemberCreate memberCreate;
    CreateEssentialMember essentialMember;
    HomePage homePage;
    MortgageApplicationPage mortgageApplicationPage;
    LoggingDatabaseUtil loggingDbUtil = new LoggingDatabaseUtil();
    DatabaseUtil dbutil = new DatabaseUtil();

    String emailToLogin = "";
    String passwordToLogin;
    String baseUri = fileReader.getApiBaseUri();
    String endpoint = "/members";
    String loanApplicationId;
    String clientKey;

    String authToken;
    UrlBuilder getLoginUrl = new UrlBuilder();
    String clientKeyUsed;
    String planTypeUsed;
    String redirectUrlUsed = "/mortgage-application";
    IntroLendHelper introLendHelper = new IntroLendHelper();

    @Test(dataProviderClass = ApiData.class, dataProvider = "createApplicantEmailAddress")
    public void a_getApplicationId(String emailAddress, String token) throws Exception
    {
        emailToLogin = emailAddress;

        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");
        request.header("x-requestid", UUID.randomUUID());
        request.header("Authorization", "Bearer " + token);

        request.body(requestBuilder.getMemberCreateRequestForAgentWithAddress(emailAddress, "Refinance").toJSONString());

        Response response = request.post("https://lending-api-dev.avenu.io/api/v1/Mortgage");

        JsonPath jsonPathEvaluator = response.jsonPath();
        loanApplicationId = jsonPathEvaluator.get("applicationID");
        int statusCode = response.getStatusCode();

        Assert.assertEquals(200,statusCode);

        System.out.println("Application ID: " + loanApplicationId);
    }

    @Test(dataProviderClass = ApiData.class, dataProvider = "createEssentialMemberForFastTrack")
    public void b_createMemberForApplication(String emailAddress, String password, String visitorId, String firstName, String lastName,
                                      String address, String zipCode, String dateOfBirth, String phoneNumber,
                                      String ssn9, String planType, String redirectUrl, Boolean doThreeBTest, String city,
                                             String state, String ccmDob) throws Exception
    {
        redirectUrlUsed = "/mortgage-application";

        CCMClientKey getNewClientKey = new CCMClientKey();
        clientKey = getNewClientKey.getClientKey(firstName, lastName, ccmDob, address, city, state, zipCode, phoneNumber, emailAddress, ssn9);

        RequestSpecification requestEnroll = RestAssured.given();
        requestEnroll.header("Content-Type", "application/json");

        requestEnroll.body(requestBuilder.getMemberCreateRequestForIntroLend(emailToLogin, password, visitorId, firstName,
                lastName, address, zipCode, dateOfBirth, phoneNumber, ssn9, planType, redirectUrlUsed, clientKey, loanApplicationId).toJSONString());

        Response response = requestEnroll.post(baseUri + endpoint);

        JsonPath jsonPathEvaluator = response.jsonPath();
        Map<String, String> successResponseMap = jsonPathEvaluator.get("response");
        Object value = successResponseMap.get("authToken");

        authToken = value.toString();

        UrlBuilder urlBuilder = new UrlBuilder();
        urlBuilder.getAutoLoginUrl(planType,clientKey,authToken);

        org.testng.Assert.assertEquals(dbutil.getMemberSignUpSource(emailToLogin), "MT_ORGANIC");

        System.out.println("Email Address: " + emailToLogin);
        System.out.println("Password: " + password);
    }
}
