package apitests.member.creditscore;

import com.tngtech.java.junit.dataprovider.DataProviderRunner;
import data.ApiData;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.runner.RunWith;
import org.junit.runners.MethodSorters;
import org.testng.annotations.Test;
import util.EnvironmentReader;

@RunWith(DataProviderRunner.class)
@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class CreditScoreTest {

    private static EnvironmentReader fileReader = new EnvironmentReader();
    String baseUri = fileReader.getApiBaseUri();
    String endpoint = "/member/memberId/credit/score";

    @Test (dataProviderClass = ApiData.class, dataProvider = "getCreditScore")
    public void testResponse200(String[] creditScoreInfo)
    {
        RequestSpecification request = RestAssured.given();
        JSONObject requestParams = new JSONObject();
        requestParams.put("clientKey", creditScoreInfo[0]);
        request.header("Content-Type", "application/json");

        request.body(requestParams.toString());
        Response response = request.post(baseUri + endpoint.replace("memberId",creditScoreInfo[1]));

        ResponseBody body = response.getBody();
        String bodyStringValue = body.asString();
        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");

        int statusCode = response.getStatusCode();

        Assert.assertEquals(200,statusCode);
        Assert.assertEquals(status,"SUCCESS");
        Assert.assertTrue(bodyStringValue.contains(creditScoreInfo[2]));
    }

    @Test
    public void testResponseCode400_1()
    {
        RequestSpecification request = RestAssured.given();

        JSONObject requestParams = new JSONObject();
        requestParams.put("clientKey", "xxxxx");
        request.header("Content-Type", "application/json");

        request.body(requestParams.toString());
        Response response = request.post(baseUri + endpoint);

        ResponseBody body = response.getBody();
        String bodyStringValue = body.asString();
        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");
        int statusCode = response.getStatusCode();

        Assert.assertEquals(400,statusCode);
        Assert.assertEquals(status,"FAILED");
        Assert.assertTrue(bodyStringValue.contains("INTERNAL_SERVER_ERROR"));
    }

    @Test
    public void testResponseCode400_2()
    {
        RequestSpecification request = RestAssured.given();

        JSONObject requestParams = new JSONObject();
        requestParams.put("clientKey", "xxxxx");

        request.header("Content-Type", "application/json");

        request.body(requestParams.toString());
        Response response = request.post(baseUri + "/member/4130361/credit/score");

        ResponseBody body = response.getBody();
        String bodyStringValue = body.asString();
        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");
        int statusCode = response.getStatusCode();

        Assert.assertEquals(400,statusCode);
        Assert.assertEquals(status,"FAILED");
        Assert.assertTrue(bodyStringValue.contains("CREDIT_SCORE_FETCH_FAILED"));
    }
}
