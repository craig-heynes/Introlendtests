package apitests.member.tmm;

import apitests.member.ApiResponseHandler;
import data.ApiData;
import data.ApiRequestBuilder;
import helperutil.CCMClientKey;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.annotations.Test;
import util.DatabaseUtil;
import util.EnvironmentReader;

public class PremiumMemberSignUpTest_200
{
    String clientKey;
    EnvironmentReader fileReader = new EnvironmentReader();
    String baseUri = fileReader.getApiBaseUri();
    ApiRequestBuilder apiRequestBuilder = new ApiRequestBuilder();
    DatabaseUtil util = new DatabaseUtil();

    private static final String endpoint = "/members";

    @Test(dataProvider = "createPremiumMember", dataProviderClass = ApiData.class)
    public void createPremiumMember (String emailAddress, String password, String visitorId, String firstName, String lastName,
                                     String address, String zipCode, String dateOfBirth, String phoneNumber, String ssn9, String planType,
                                     String nonce, String btSubscriptionPlan, String redirectUrl,
                                     String city, String state, String ccmDob) throws Exception
    {
//        ApiMemberCreate memberCreate = new ApiMemberCreate (getDriver());
//        memberCreate.memberCreateForClientKey(firstName, lastName, emailAddress, password, address,
//                zipCode, phoneNumber, dateOfBirth, "1234", ssn9, "fakecard", "fakecvv",
//                "fakeexpiry", "fakezipcode");
//
//        LoggingDatabaseUtil loggingDatabaseUtil = new LoggingDatabaseUtil();

        CCMClientKey getNewClientKey = new CCMClientKey();
        clientKey = getNewClientKey.getClientKey(firstName, lastName, ccmDob, address, city, state, zipCode, phoneNumber, emailAddress, ssn9);

        RequestSpecification requestEnrollTC2 = RestAssured.given();
        requestEnrollTC2.header("Content-Type", "application/json");

        requestEnrollTC2.body(apiRequestBuilder.getMemberCreateRequestForPremium
                (emailAddress, password, visitorId, firstName, lastName, address, zipCode,
                        dateOfBirth, phoneNumber, ssn9, planType, redirectUrl, clientKey,
                        nonce, btSubscriptionPlan).toJSONString());

        Response response = requestEnrollTC2.post(baseUri + endpoint);
        System.out.println(response.cookies().toString());
        ApiResponseHandler responseHandler = new ApiResponseHandler();
        responseHandler.onExpectedSuccess(response, emailAddress, planType, clientKey, redirectUrl);

        org.testng.Assert.assertEquals("PREMIUM", util.getMemberShipType(emailAddress));
        org.testng.Assert.assertEquals("ENROLLED", util.getTUEnrollStatus(emailAddress));
        org.testng.Assert.assertEquals("ENROLLED", util.getExperianEnrollStatus(emailAddress));

        System.out.println("Email Address: " + emailAddress);
        System.out.println("Password: " + password);
    }
}
