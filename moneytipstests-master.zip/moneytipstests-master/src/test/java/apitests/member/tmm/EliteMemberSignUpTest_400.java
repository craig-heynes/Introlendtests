package apitests.member.tmm;

import apitests.member.ApiResponseHandler;
import data.ApiData;
import data.ApiRequestBuilder;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.annotations.Test;
import util.EnvironmentReader;

public class EliteMemberSignUpTest_400
{
    EnvironmentReader fileReader = new EnvironmentReader();
    String baseUri = fileReader.getApiBaseUri();

    private static final String endpoint = "/members";

    @Test(dataProvider = "createEliteMember", dataProviderClass = ApiData.class)
    public void enrollEliteMember_400 (String emailAddress, String password, String visitorId, String firstName, String lastName,
                                       String address, String zipCode, String dateOfBirth, String phoneNumber, String ssn9, String planType,
                                       String nonce, String btSubscriptionPlan, String redirectUrl,
                                       String city, String state, String ccmDob) throws Exception
    {
        RequestSpecification requestEnroll = RestAssured.given();
        requestEnroll.header("Content-Type", "application/json");
        ApiRequestBuilder apiRequestBuilder = new ApiRequestBuilder();
        requestEnroll.body(apiRequestBuilder.getMemberCreateRequestForElite(emailAddress, password, visitorId, firstName, lastName, address, zipCode, dateOfBirth, phoneNumber,
                ssn9, planType, redirectUrl, visitorId, nonce, "").toJSONString());

        Response response = requestEnroll.post(baseUri + endpoint);
        ApiResponseHandler responseHandler = new ApiResponseHandler();
        responseHandler.onExpectedFailure(response);
    }
}
