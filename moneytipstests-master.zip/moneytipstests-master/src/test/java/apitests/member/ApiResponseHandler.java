package apitests.member;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import util.UrlBuilder;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ApiResponseHandler {

    public void onExpectedFailure(Response response)
    {
        ResponseBody body = response.getBody();
        String bodyStringValue = body.asString();

        System.out.println(bodyStringValue);

        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");
        int statusCode = response.getStatusCode();

        org.testng.Assert.assertEquals(400, statusCode);
        org.testng.Assert.assertEquals(status,"FAILED");
    }

    public void onExpectedSuccess(Response response, String emailAddress, String planType, String clientKey, String redirectUrl) throws  Exception
    {
        ResponseBody body = response.getBody();
        String bodyStringValue = body.asString();

        System.out.println(bodyStringValue);

        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");
        int statusCode = response.getStatusCode();
        String authToken;
        Map<String, String> successResponseMap = jsonPathEvaluator.get("response");
        Object value = successResponseMap.get("authToken");
        authToken = value.toString();

        org.testng.Assert.assertEquals(200,statusCode);
        org.testng.Assert.assertEquals(status,"SUCCESS");
        org.testng.Assert.assertTrue(bodyStringValue.contains("clientKey"));
        org.testng.Assert.assertTrue(bodyStringValue.contains("authToken"));

        UrlBuilder urlBuilder = new UrlBuilder();
        urlBuilder.getAutoLoginUrl(planType, clientKey, authToken);
    }

    public void verifyGTM(String planType, WebDriver driver)
    {
        JavascriptExecutor js = (JavascriptExecutor) driver;

        ArrayList<Map<String, List<String>>> myList = new ArrayList<>();

        //Execute GTM script to fetch values
        myList =  (ArrayList) js.executeScript("return window.dataLayer");

        // Parse through GTM arrayList
        for(int a=0; a < myList.size(); a++) {
            for (String key : myList.get(a).keySet()) {

//                System.out.println(key + "      " + myList.get(a).get(key));
                switch (key){
                    case "memberPlanType":
                        Assert.assertEquals(planType, myList.get(a).get(key));
                        System.out.println(key + "      " + myList.get(a).get(key));
                        break;
                    case "dimension6":
                        Assert.assertEquals(planType, myList.get(a).get(key));
                        System.out.println(key + "      " + myList.get(a).get(key));
                        break;
                    case "eventAction":
                        if (String.valueOf(myList.get(a).get(key)).equals("create member")) {
                            Assert.assertEquals("create member", myList.get(a).get(key));
                            System.out.println(key + "      " + myList.get(a).get(key));
                        }
                        else if (String.valueOf(myList.get(a).get(key)).equals("user signin")) {
                            Assert.assertEquals("user signin", myList.get(a).get(key));
                            System.out.println(key + "      " + myList.get(a).get(key));
                        }
                        System.out.println(key + "      " + myList.get(a).get(key));
                        break;
                    case "eventCategory":
                        Assert.assertEquals("commit", myList.get(a).get(key));
                        System.out.println(key + "      " + myList.get(a).get(key));
                        break;
                }
            }
        }
    }
}
