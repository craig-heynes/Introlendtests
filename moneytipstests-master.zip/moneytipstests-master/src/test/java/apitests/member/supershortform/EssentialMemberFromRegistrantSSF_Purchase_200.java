package apitests.member.supershortform;

import apitests.member.ApiResponseHandler;
import apitests.registrant.CreateRegistrantTest;
import data.ApiData;
import data.ApiRequestBuilder;
import helperutil.CCMClientKey;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.testng.annotations.Test;
import util.DatabaseUtil;
import util.EnvironmentReader;
import util.UrlBuilder;

public class EssentialMemberFromRegistrantSSF_Purchase_200
{
    String clientKey;
    EnvironmentReader fileReader = new EnvironmentReader();
    CreateRegistrantTest createRegistrant = new CreateRegistrantTest();
    DatabaseUtil databaseUtil = new DatabaseUtil();
    UrlBuilder urlBuilder = new UrlBuilder();
    String baseUrl = fileReader.getApplicationUrl();
    String baseUri = fileReader.getApiBaseUri();
    ApiRequestBuilder apiRequestBuilder = new ApiRequestBuilder();

    private static final String endpoint = "/members";
    private static final String emailendpoint = "/verifications";
    private static final String phoneEndpoint = "/phone/verification";

    @Test(dataProvider = "createEssentialMember", dataProviderClass = ApiData.class)
    public void createMember (String emailAddress, String password, String visitorId, String firstName,
                              String lastName, String address, String zipCode, String dateOfBirth,
                              String phoneNumber, String ssn9, String planType, String redirectUrl, Boolean threeBTest,
                              String city, String state, String ccmDob) throws Exception
    {
        redirectUrl = "/mortgage-application";
        String loanPurpose = "Purchase";

//        ApiMemberCreate memberCreate = new ApiMemberCreate (getDriver());
//        memberCreate.memberCreateForClientKey(firstName, lastName, emailAddress, password, address,
//                zipCode, phoneNumber, dateOfBirth, "1234", ssn9, "fakecard", "fakecvv",
//                "fakeexpiry", "fakezipcode");
//
//        LoggingDatabaseUtil loggingDbUtil = new LoggingDatabaseUtil();

        CCMClientKey getNewClientKey = new CCMClientKey();
        clientKey = getNewClientKey.getClientKey(firstName, lastName, ccmDob, address, city, state, zipCode, phoneNumber, emailAddress, ssn9);

        createRegistrant.testCreateEssentialRegistrantAllFields_200(firstName, lastName, emailAddress, password, visitorId, address,
                "city", "state", zipCode, dateOfBirth, phoneNumber, clientKey, planType, "TMM", loanPurpose, null);

        //create member
        RequestSpecification requestEnroll = RestAssured.given();
        requestEnroll.header("Content-Type", "application/json");

        requestEnroll.body(apiRequestBuilder.getMemberCreateRequestFromRegistrant(redirectUrl));
        Response response = requestEnroll.post(baseUri + endpoint);

        ApiResponseHandler responseHandler = new ApiResponseHandler();
        responseHandler.onExpectedSuccess(response, emailAddress, planType, clientKey, redirectUrl);

        org.testng.Assert.assertEquals(databaseUtil.getMemberSignUpSource(emailAddress), "TMM");

        String[] applicationSet = databaseUtil.getApplicationSetForMember(emailAddress);
        org.testng.Assert.assertEquals(applicationSet[0], "PURCHASE");
    }
}
