package apitests.auth;

import apitests.ApiAutoLogin1;
import apitests.visitors.VisitorTest;
import data.GlobalVariables;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.testng.annotations.Test;
import uitests.base.BaseTest;
import util.EnvironmentReader;
import util.UrlBuilder;

import java.util.Map;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RedirectLoginTest extends BaseTest {

    private static EnvironmentReader fileReader = new EnvironmentReader();
    private static String validEmailAddress = "freecredit1@gmail.com";
    private static String inValidEmailAddress = "freecredit12345@gmail.com";
    private static String baseUri = fileReader.getApiBaseUri();
    private static final String endpoint = "/members/auth";
    private static String authTokenToUse;
    private static String redirectUrl = "/mortgage-application";
    private static UrlBuilder urlBuilder = new UrlBuilder();

    @org.testng.annotations.Test
    public  void a_testValidLogin_200()
    {
        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");

        request.body("{\n    " +
                "\"username\": \"" + validEmailAddress + "\",\n    " +
                "\"password\": \"terramatrix\"\n}");

        Response response = request.post(baseUri + endpoint);
        ResponseBody body = response.getBody();
        String bodyStringValue = body.asString();

        System.out.println(bodyStringValue);

        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");

        Map<String, String> successResponseMap = jsonPathEvaluator.get("response");
        Object authToken = successResponseMap.get("authToken");
        authTokenToUse = authToken.toString();

        int statusCode = response.getStatusCode();
        org.testng.Assert.assertEquals(200,statusCode);
        org.testng.Assert.assertEquals(status,"SUCCESS");
        org.testng.Assert.assertTrue(!authToken.toString().isEmpty());
        System.out.println("Auth Token: " + authToken.toString());
    }

    @org.testng.annotations.Test
    public void b_testSignUpSms_400()
    {
        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");

        request.body("{\n    " +
                "\"username\": \"" + inValidEmailAddress + "\",\n    " +
                "\"password\": \"terramatrix\"\n}");

        Response response = request.post(baseUri + endpoint);
        ResponseBody body = response.getBody();
        String bodyStringValue = body.asString();

        System.out.println(bodyStringValue);

        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");
        int statusCode = response.getStatusCode();

        org.testng.Assert.assertEquals(400,statusCode);
        org.testng.Assert.assertEquals(status,"FAILED");
    }

    @Test
    public void c_testRedirectLogin() throws Exception
    {
        VisitorTest visitorTest = new VisitorTest();
        visitorTest.testExistingMember_200(validEmailAddress);
        a_testValidLogin_200();
        ApiAutoLogin1 login = new ApiAutoLogin1(driver, urlBuilder.getRedirectLoginUrl(GlobalVariables.memberId,authTokenToUse,redirectUrl), redirectUrl);
//        login.testRedirectLogin();
    }
}
