package apitests;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import pages.HomePage;
import util.EnvironmentReader;

public class ApiAutoLogin1 extends ApiBaseTest1 {

    EnvironmentReader fileReader = new EnvironmentReader();
    HomePage homePage;
    private static String login_Url;
    private static String redirect_Url;
    private WebDriver driver;

    public ApiAutoLogin1(WebDriver driver, String loginUrl, String redirectUrl){
        this.driver = driver;
        login_Url = loginUrl;
        redirect_Url = redirectUrl;
    }

    @org.testng.annotations.Test
    public void testLogin() throws Exception
    {
        homePage = new HomePage(driver,login_Url);
        Thread.sleep(15000); //refactor later
//        Assert.assertEquals(fileReader.getApplicationUrl() + redirect_Url, driver.getCurrentUrl());
        Assert.assertTrue(driver.getCurrentUrl().contains(redirect_Url));
    }

    @org.testng.annotations.Test
    public void testLoginEssentialUnverified() throws Exception
    {
        homePage = new HomePage(driver,login_Url);
        Thread.sleep(15000); //refactor later
        Assert.assertTrue(driver.getCurrentUrl().contains("verify"));
    }

    @Test
    public void testRedirectLogin() throws Exception
    {
        homePage = new HomePage(driver,login_Url);
        Thread.sleep(15000); //refactor later
        Assert.assertTrue(driver.getCurrentUrl().contains("mortgage-application-summary"));
    }
}
