package apitests.visitors;

import data.ApiData;
import data.GlobalVariables;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.testng.annotations.Test;
import util.EnvironmentReader;

import java.util.Map;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class VisitorTest {

    private static EnvironmentReader fileReader = new EnvironmentReader();
    String baseUri = fileReader.getApiBaseUri();
    String endpoint = "/visitors";

    @org.testng.annotations.Test (dataProviderClass = ApiData.class, dataProvider = "newVistor")
    public  void testNewVisitor(String emailAddress, String visitorID)
    {
        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");

        request.body("{\n    " +
                "\"email\": \"" + emailAddress + "\",\n    " +
                "\"visitorId\": \"" + visitorID + "\",\n    " +
                "\"metaData\": {\n        " +
                "\"namea\": \"valueairon\",\n        " +
                "\"nameb\": \"valuebiron\",\n        " +
                "\"namec\": \"valueciron\"\n    " +
                "}\n}");

        Response response = request.post(baseUri + endpoint);
        ResponseBody body = response.getBody();
        String bodyStringValue = body.asString();
        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");
        int statusCode = response.getStatusCode();

        System.out.println(bodyStringValue);

        Assert.assertEquals(200,statusCode);
        Assert.assertEquals(status,"SUCCESS");
        Assert.assertTrue(bodyStringValue.contains("NEW_VISITOR"));
    }

    @org.testng.annotations.Test(dataProviderClass = ApiData.class, dataProvider = "existingMember")
    public void testExistingMember_200(String emailAddress)
    {
        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");

        request.body("{\n    " +
                "\"email\": \"" + emailAddress + "\",\n    " +
                "\"metaData\": {\n        " +
                "\"namea\": \"valueairon\",\n        " +
                "\"nameb\": \"valuebiron\",\n        " +
                "\"namec\": \"valueciron\"\n    " +
                "}\n}");

        Response response = request.post(baseUri+ endpoint);

        ResponseBody body = response.getBody();
        String bodyStringValue = body.asString();
        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");

        Map<String, String> successResponseMap = jsonPathEvaluator.get("response");
        Object memberId = successResponseMap.get("memberId");

        GlobalVariables.memberId = memberId.toString();
        int statusCode = response.getStatusCode();

        System.out.println(bodyStringValue);

        Assert.assertEquals(200,statusCode);
        Assert.assertEquals(status,"SUCCESS");
        Assert.assertTrue(bodyStringValue.contains("EXISTING_MEMBER"));
    }

    @Test
    public void testExistingMember_400()
    {
        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");

        request.body("{\n    " +
                "\"email\": \"7678767676876868\",\n    " +
                "\"metaData\": {\n        " +
                "\"namea\": \"valueairon\",\n        " +
                "\"nameb\": \"valuebiron\",\n        " +
                "\"namec\": \"valueciron\"\n    " +
                "}\n}");

        Response response = request.post(baseUri + endpoint);
        ResponseBody body = response.getBody();
        String bodyStringValue = body.asString();

        JsonPath jsonPathEvaluator = response.jsonPath();
        String status = jsonPathEvaluator.get("status");
        int statusCode = response.getStatusCode();

        System.out.println(bodyStringValue);

        Assert.assertEquals(400,statusCode);
        Assert.assertEquals(status,"FAILED");
        Assert.assertTrue(bodyStringValue.contains("Please enter a valid email address."));
    }
}
