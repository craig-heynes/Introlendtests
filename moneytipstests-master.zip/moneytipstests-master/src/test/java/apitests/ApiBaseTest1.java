package apitests;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import util.DatabaseUtil;
import util.DriverFactory;

import java.util.concurrent.TimeUnit;

public class ApiBaseTest1 {

    WebDriver driver;
    public static DatabaseUtil dbUtil = new DatabaseUtil();

    @BeforeClass
    public void setup() throws Exception
    {
        long id = Thread.currentThread().getId();
        System.out.println("Before test-method. Thread id is: " + id);
        driver = DriverFactory.getDriver(DriverFactory.getBrowserTypeByProperty());
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }

    public WebDriver getDriver()
    {
        return driver;
    }

    @AfterClass
    public void close()
    {
        long id = Thread.currentThread().getId();
        System.out.println("After test-method. Thread id is: " + id);
        try
        {
            driver.close();
        }
        catch (Exception e){
            System.out.println("Nothing to do with it");
        }
        try
        {
            driver.quit();
        }
        catch (Exception e)
        {
            System.out.println("Nothing to do with it");
        }
    }
}
