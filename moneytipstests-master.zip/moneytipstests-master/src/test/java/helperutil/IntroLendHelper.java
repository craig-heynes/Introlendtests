package helperutil;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.simple.JSONObject;
import org.junit.Assert;

import java.util.UUID;

public class IntroLendHelper {
    public boolean isDocuSignComplete(String token, String loanApplicationId)
    {
        boolean completed=false;
        boolean docStatus1=false;
        boolean docStatus2=false;
        boolean docStatus3=false;
        String status1;
        String status2;
        String status3;

        RequestSpecification request = RestAssured.given();
        request.header("Authorization", "Bearer " + token);

        Response response = request.get("https://lending-api-dev.avenu.io/api/v1/LoanApplications/" + loanApplicationId + "/docusign");

        while (!completed) {
            if (!response.jsonPath().getString("status[0]").isEmpty()) {
                status1 = response.jsonPath().getString("status[0]");
                if (status1.equals("Completed")) {
                    docStatus1 = true;
                }

                status2 = response.jsonPath().getString("status[1]");
                if (status2.equals("Completed")) {
                    docStatus2 = true;
                }

                status3 = response.jsonPath().getString("status[2]");
                if (status3!=null) {
                    if (status3.equals("Completed")) {
                        docStatus3 = true;
                    }
                }
            }

            if (docStatus3) {
                if ((docStatus1) && (docStatus2) && (docStatus3)) {
                    completed = true;
                }
                else {
                    completed = false;
                }
            }
            else if ((docStatus1) && (docStatus2)) {
                completed = true;
            }
        }

        return completed;
    }

    public void loadBids1(String bidId, String token, String loanApplicationID)
    {
        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");
        request.header("x-requestid", UUID.randomUUID());
        request.header("Authorization", "Bearer " + token);

        request.body("{\n  \"loanApplicationID\": \"" + loanApplicationID + "\",\n  " +
                "\"lenderBidID\": \"" + bidId + "\",\n  " +
                "\"dateReceived\": \"2019-09-09T12:31:13.712Z\",\n  " +
                "\"interestRate\": 0.0353,\n  " +
                "\"discountPoints\": 0,\n  " +
                "\"loanFee\": 20,\n  " +
                "\"originationFee\": 5,\n  " +
                "\"lenderFee\": 1000,\n  " +
                "\"brokerFee\": 3000,\n  " +
                "\"otherFees\": 700,\n  " +
                "\"appraisalFee\": 15,\n  " +
                "\"monthlyPayment\": 1400,\n  " +
                "\"apr\": 0.04\n}");

        Response response = request.post("https://lending-api-dev.avenu.io/api/v1/Mortgage/" + loanApplicationID + "/bids/" + bidId);
        int statusCode = response.getStatusCode();
        Assert.assertEquals(200,statusCode);
    }

    public void loadBids2(String bidId, String token, String loanApplicationID)
    {
        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");
        request.header("x-requestid", UUID.randomUUID());
        request.header("Authorization", "Bearer " + token);

        request.body("{\n  \"loanApplicationID\": \"" + loanApplicationID + "\",\n  " +
                "\"lenderBidID\": \"" + bidId + "\",\n  " +
                "\"dateReceived\": \"2019-09-09T12:31:13.712Z\",\n  " +
                "\"interestRate\": 0.0153,\n  " +
                "\"discountPoints\": 0,\n  " +
                "\"loanFee\": 20,\n  " +
                "\"originationFee\": 5,\n  " +
                "\"lenderFee\": 100,\n  " +
                "\"brokerFee\": 300,\n  " +
                "\"otherFees\": 70,\n  " +
                "\"appraisalFee\": 15,\n  " +
                "\"monthlyPayment\": 2400,\n  " +
                "\"apr\": 0.04\n}");

        Response response = request.post("https://lending-api-dev.avenu.io/api/v1/Mortgage/" + loanApplicationID + "/bids/" + bidId);
        int statusCode = response.getStatusCode();
        Assert.assertEquals(200,statusCode);
    }

    public void loadBids3(String bidId, String token, String loanApplicationID)
    {
        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");
        request.header("x-requestid", UUID.randomUUID());
        request.header("Authorization", "Bearer " + token);

        request.body("{\n  \"loanApplicationID\": \"" + loanApplicationID + "\",\n  " +
                "\"lenderBidID\": \"" + bidId + "\",\n  " +
                "\"dateReceived\": \"2019-09-09T12:31:13.712Z\",\n  " +
                "\"interestRate\": 0.0253,\n  " +
                "\"discountPoints\": 0,\n  " +
                "\"loanFee\": 200,\n  " +
                "\"originationFee\": 50,\n  " +
                "\"lenderFee\": 2000,\n  " +
                "\"brokerFee\": 1000,\n  " +
                "\"otherFees\": 7900,\n  " +
                "\"appraisalFee\": 15,\n  " +
                "\"monthlyPayment\": 700,\n  " +
                "\"apr\": 0.04\n}");

        Response response = request.post("https://lending-api-dev.avenu.io/api/v1/Mortgage/" + loanApplicationID + "/bids/" + bidId);
        int statusCode = response.getStatusCode();
        Assert.assertEquals(200,statusCode);
    }

    public void selectBid(String bidId, String token, String loanApplicationID)
    {
        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");
        request.header("x-requestid", UUID.randomUUID());
        request.header("Authorization", "Bearer " + token);

        JSONObject loadBid = new JSONObject();
        loadBid.put("lenderBidID", bidId);
        loadBid.put("loanApplicationID", loanApplicationID);
        request.body(loadBid.toJSONString());

        Response response = request.put("https://lending-api-dev.avenu.io/api/v1/Mortgage/" + loanApplicationID + "/bids/" + bidId + "/select");
        int statusCode = response.getStatusCode();
        Assert.assertEquals(200,statusCode);
    }
}
