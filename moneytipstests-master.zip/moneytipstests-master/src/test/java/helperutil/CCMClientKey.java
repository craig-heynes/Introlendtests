package helperutil;

import data.ApiRequestBuilder;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import org.json.simple.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class CCMClientKey
{
    String username = "MoneyTips_stage";
    String password = "leadpoint";
    ApiRequestBuilder apiRequestBuilder = new ApiRequestBuilder();
    String clientKey;
    String examLocation;

    public String getClientKey(String firstName, String lastName, String dateOfBirth,
                                  String address, String city, String state, String zipCode,
                                  String phoneNumber, String emailAdress, String socialSecurity)
    {
        postPersonalInfo(firstName, lastName, dateOfBirth,
                 address, city, state, zipCode,
                 phoneNumber, emailAdress, socialSecurity);

        postAnswers();

        return clientKey;
    }

    public void postPersonalInfo(String firstName, String lastName, String dateOfBirth,
                                 String address, String city, String state, String zipCode,
                                 String phoneNumber, String emailAdress, String socialSecurity)
    {
        RequestSpecification request = RestAssured.given();
        request.auth().basic(username, password);
        request.header("Content-Type", "application/json");
        request.body(apiRequestBuilder.getCcmPersonalInfoRequest(firstName, lastName, dateOfBirth,
                address, city, state, zipCode, phoneNumber, emailAdress, socialSecurity).toJSONString());

        Response response = request.post("http://ccm-stage-2.us-east-1.elasticbeanstalk.com/v1/signup/clients");
        ResponseBody body = response.getBody();
        String bodyStringValue = body.asString();
        System.out.println(bodyStringValue);

        clientKey = response.jsonPath().getString("clientKey");
                System.out.println(clientKey);
        examLocation = response.jsonPath().getString("examLocation");
    }

    public void postAnswers()
    {
        RequestSpecification request = RestAssured.given();
        request.auth().basic(username, password);
        request.header("Content-Type", "application/json");
        request.body(getAnswerExamQuestions().toJSONString());

        Response response = request.post("http://ccm-stage-2.us-east-1.elasticbeanstalk.com/v1/signup/clients/" + clientKey + "/exam/choices");
        System.out.println(response.getStatusCode());
    }

    public JSONObject getAnswerExamQuestions()
    {
        JsonPath jsonPathEvaluator = getExamQuestions().jsonPath();

        Map qMap = jsonPathEvaluator.get("exam");
        Object qList = qMap.get("questions");

        String fulfillmentKey = qMap.get("fulfillmentKey").toString();

        Object answers;
        String answerId;
        String answerNOAId;

        JSONObject answerRequest = new JSONObject();
        JSONObject answerObject = new JSONObject();
        org.json.JSONArray answersArray = new org.json.JSONArray();

        answerRequest.put("clientKey", clientKey);
        answerRequest.put("fulfillmentKey", fulfillmentKey);

        String questionId;

        for (int i = 0; i < ((ArrayList) qList).size() ; i++) {
            answers = ((HashMap) ((ArrayList) qList).get(i)).get("answers");
            questionId = ((HashMap) ((ArrayList) qList).get(i)).get("questionId").toString();

            answerId=null;
            answerNOAId=null;

            for (int j = 0; j < ((ArrayList) answers).size(); j++) {
                    if (getPossibleAnswers().contains(((HashMap) ((ArrayList) answers).get(j)).get("text").toString())) {
                        answerId = ((HashMap) ((ArrayList) answers).get(j)).get("answerId").toString();
                    }
                    if (((HashMap) ((ArrayList) answers).get(j)).get("text").toString().equals("None of the Above")) {
                        answerNOAId = ((HashMap) ((ArrayList) answers).get(j)).get("answerId").toString();
                    }
            }
            if (answerId == null) {
                answerId = answerNOAId;
            }

            answerObject.put("answerId", answerId);
            answerObject.put("questionId", questionId);
            answersArray.put(answerObject);

        }
        answerRequest.put("answers", answersArray);

        return answerRequest;
    }

    public Response getExamQuestions()
    {
        RequestSpecification request = RestAssured.given();
        request.auth().basic(username, password);
        request.header("Content-Type", "application/json");
        Response response = request.get(examLocation);
//        ResponseBody body = response.getBody();
//        String bodyStringValue = body.asString();
//        System.out.println(bodyStringValue);

        return response;
    }

    private String getPossibleAnswers()
    {
        JSONObject answers = new JSONObject();
        answers.put("1", "Ashwood");
        answers.put("2", "Bond");
        answers.put("3", "Iec");
        answers.put("4", "New Hampshire");
        answers.put("5", "Bowen");
        answers.put("6", "Pepsi Co.");
        answers.put("7", "Alpine");

        return answers.toJSONString();
    }
}
