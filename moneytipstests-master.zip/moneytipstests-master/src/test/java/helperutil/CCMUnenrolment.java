package helperutil;

import data.GlobalVariables;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import util.DatabaseUtil;

public class CCMUnenrolment
{
    DatabaseUtil util = new DatabaseUtil();

    public void deleteEssentialClientKey() throws Exception
    {
        util.setClientKeyToNull(GlobalVariables.ESSENTIALCLIENTKEY);

        RequestSpecification request = RestAssured.given();
        request.auth().basic("Moneytips_stage", "leadpoint");
        Response response = request.delete("http://ccm-stage-2.us-east-1.elasticbeanstalk.com/v1/reports/clients/" + GlobalVariables.ESSENTIALCLIENTKEY + "/enrollment");

        int statusCode = response.getStatusCode();
        int countAttempts=0;
        System.out.println("Status Code: " + statusCode);

        while (statusCode!=400 && statusCode!=200)
        {
            countAttempts++;
            System.out.println("Attempting to unenroll again. ");
            this.deleteEssentialClientKey();
        }
    }

    public void deletePremiumClientKey() throws Exception
    {
        RequestSpecification request = RestAssured.given();
        request.auth().basic("Moneytips_stage", "leadpoint");
        Response response = request.get("http://ccm-stage-2.us-east-1.elasticbeanstalk.com/v1/reports/clients/" + GlobalVariables.PREMIUMCLIENTKEY + "/enrollment");

        int statusCode = response.getStatusCode();
        System.out.println("Status Code: " + statusCode);

        if (statusCode!=200 && statusCode!=400)
        {
            System.exit(0);
        }
        else {
            util.setClientKeyToNull(GlobalVariables.PREMIUMCLIENTKEY);
        }
    }

    public void deleteEliteClientKey() throws Exception
    {
        RequestSpecification request = RestAssured.given();
        request.auth().basic("Moneytips_stage", "leadpoint");
        Response response = request.get("http://ccm-stage-2.us-east-1.elasticbeanstalk.com/v1/reports/clients/" + GlobalVariables.ELITECLIENTKEY + "/enrollment");

        int statusCode = response.getStatusCode();
        System.out.println("Status Code: " + statusCode);

        if (statusCode!=200 && statusCode!=400)
        {
            System.exit(0);
        }
        else {
            util.setClientKeyToNull(GlobalVariables.ELITECLIENTKEY);
        }
    }
}
