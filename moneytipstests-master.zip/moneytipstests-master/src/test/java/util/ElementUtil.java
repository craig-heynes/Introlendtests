package util;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ElementUtil {

    public void scrollToElement(WebDriver driver, WebElement element) throws Exception{

        JavascriptExecutor js = (JavascriptExecutor) driver;

        //scroll to element minus the offset of the header
        js.executeScript ("arguments[0].scrollIntoView(true);",element);
        js.executeScript("javascript:window.scrollBy(0,-150)");
    }

    public void waitForElement(WebDriver driver, WebElement element)throws Exception{
        Thread.sleep(4000);
        Wait<WebDriver> wait = new WebDriverWait(driver,100);
        wait.until(ExpectedConditions.elementToBeClickable(element));
    }

    public boolean waitForElementToBeDisplayed(WebElement element) throws Exception{

        Boolean elementExists = false;

            while (!elementExists)
            {
                try {
                    if (element.isDisplayed())
                    {
                        elementExists = true;
                    }
                }
                catch (NoSuchElementException e){
                    elementExists = false;
                    Thread.sleep(1000);
                }
            }

        return elementExists;
    }

    public Boolean elementExists(WebElement element){

        Boolean elementExists = false;

        try{
            if (element.isDisplayed())
            {
                elementExists = true;
            }
        }
        catch (NoSuchElementException e){
        }
        return elementExists;
    }
}
