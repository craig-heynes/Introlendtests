package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class LoggingDatabaseUtil {

    // Object of Connection from the Database
    Connection conn = null;

    // Object of Statement. It is used to create a Statement to execute the query
    Statement stmt = null;

    //Object of ResultSet => 'It maintains a cursor that points to the current row in the result set'
    ResultSet resultSet = null;

    private static EnvironmentReader fileReader = new EnvironmentReader();

    public Connection connectDB() throws Exception{
//        private Connection connectDB() throws Exception{

        // Open a connection

        Class.forName("com.mysql.jdbc.Driver");

        if(conn != null && !conn.isClosed()){
            conn.close();
        }

//        conn = DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/dest_oltp", "root", "");
        conn = DriverManager.getConnection("jdbc:mysql://" + fileReader.getLoggingDbUrl() + ":" + fileReader.getLoggingDbPort()
                + "/" + fileReader.getLoggingDbName(), fileReader.getDbUsername() , fileReader.getDbPassword());
        return  conn;
    }

    public String getClientKeyForApiEnroll() throws Exception{
        connectDB();
        String clientKey = "";
        String query = "select client_key from dest_user_activity order by doe desc limit 1";
        stmt = conn.createStatement();
        resultSet = stmt.executeQuery(query);
        while(resultSet .next()) {
            clientKey=(resultSet.getString("client_key"));
        }
        closeResultsSet();
        System.out.println("Client Key = " + clientKey);
        return clientKey;
    }

    public String getClientKeyForApiEnrollByEmail(String emailAddress) throws Exception{
        connectDB();
        String clientKey = "";
        String query = "select client_key from dest_user_activity where email = \'" + emailAddress + "\' order by doe desc limit 1";
        stmt = conn.createStatement();
        resultSet = stmt.executeQuery(query);
        while(resultSet .next()) {
            clientKey=(resultSet.getString("client_key"));
        }
        closeResultsSet();
        conn.close();
        System.out.println("Client Key = " + clientKey);
        return clientKey;
    }

    public void truncateDestSmartAlertTransaction() throws Exception{
        connectDB();
        String query = "truncate dest_smart_alert_transaction";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public String getSmartEmailSentStatus(String emailAddress) throws Exception{
        connectDB();
        String result = "";
        String query = "select email, alert_type from dest_smart_alert_transaction where email = \"" + emailAddress + "\"";
        stmt = conn.createStatement();
        resultSet = stmt.executeQuery(query);
        while(resultSet .next()) {
            result = resultSet.getString("alert_type");
            if (result!="")
            {break;}
        }
        closeResultsSet();
        return result;
    }

    public String getSendGridEmailSentStatus(String emailAddress, String templateId) throws Exception{
        connectDB();
        String result = "";
        String query = "select success \n" +
                "from dest_sendgrid_mail_transaction\n" +
                "where recipient = '"+emailAddress+"'\n" +
                "AND sendgrid_template_id = '"+templateId+"'";
        stmt = conn.createStatement();
        resultSet = stmt.executeQuery(query);
        while(resultSet .next()) {
            result = resultSet.getString("success");
        }
        closeResultsSet();
        return result;
    }

    private void closeResultsSet(){

        if (resultSet != null) {
            try {
                resultSet.close();
            } catch (Exception e) {
            }
        }

        if (stmt != null) {
            try {
                stmt.close();
            } catch (Exception e) {
            }
        }

        if (conn != null) {
            try {
                conn.close();
            } catch (Exception e) {
            }
        }
    }

}


