package util;

import java.nio.file.Path;
import java.nio.file.Paths;

public class ConfigUtil{

    public String getRelativeSystemPath()
    {
        Path currentRelativePath = Paths.get("");
        return currentRelativePath.toAbsolutePath().toString();
    }
}
