/*
 * Copyright (C) 2015 by Estalea, Inc. All rights reserved.
 * This is proprietary software of Estalea, Inc.
 */
package util;

import data.BrowserStackLoginCreds;
import data.GlobalVariables;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import java.net.URL;

public class DriverFactory {

    public enum BrowserType{
        FIREFOX("firefox"),
        CHROME("chrome"),
        CHROMEHEADLESS("chromeheadless"),
        CHROMEBROWSERSTACK("chromebrowserstack"),
        IE("internet_explorer"),
        SARARI("safari");

        private String value;

        BrowserType(String value){
            this.value = value;
        }

        public String getBrowserName(){
            return this.value;
        }
    }

    public static WebDriver getDriver(BrowserType type) throws Exception
    {
        WebDriver driver=null;
        ConfigFileReader fileReader = new ConfigFileReader();

        switch (type){
            case FIREFOX:
                System.setProperty("webdriver.gecko.driver",fileReader.getDriverPath());
                driver = new FirefoxDriver();
                System.out.println(fileReader.getDriverPath());
                return driver;
            case CHROME:
                System.setProperty("webdriver.chrome.driver",fileReader.getDriverPath());
                driver = new ChromeDriver();
                return driver;
            case CHROMEHEADLESS:
                System.setProperty("webdriver.chrome.driver",fileReader.getDriverPath());
                ChromeOptions options = new ChromeOptions();
                options.addArguments("headless");
                options.addArguments("window-size=1200x600");
                driver = new ChromeDriver(options);
                return driver;
            case CHROMEBROWSERSTACK:
                DesiredCapabilities caps = new DesiredCapabilities();
                caps.setCapability("browser", "Chrome");
                caps.setCapability("browser_version", "81.0 beta");
                caps.setCapability("os", "Windows");
                caps.setCapability("os_version", "10");
                caps.setCapability("resolution", "1920x1080");
                caps.setCapability("name", "Bstack-[Java] Sample Test");
                caps.setCapability("browserstack.local", "true");
                caps.setCapability("browserstack.localIdentifier", "Test123");
                driver = new RemoteWebDriver(new URL(BrowserStackLoginCreds.URL), caps);
                return driver;
        }
        return driver;
    }

    public static BrowserType getBrowserTypeByProperty() throws Exception
    {
        BrowserType type = null;
        ConfigFileReader fileReader = new ConfigFileReader();

        for (BrowserType bType : BrowserType.values()){
            if ((GlobalVariables.isIntroLendTest) && (!fileReader.getBrowser().equals("chromebrowserstack")))
            {
                return BrowserType.CHROME;
            }
            if (bType.getBrowserName().equalsIgnoreCase(fileReader.getBrowser())){
                type = bType;
                System.out.println("BROWSER = " + type.getBrowserName());
            }
        }
        return type;
    }
}

