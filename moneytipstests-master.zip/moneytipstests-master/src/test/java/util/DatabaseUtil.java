package util;

import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import org.apache.ibatis.jdbc.ScriptRunner;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.Reader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class DatabaseUtil {

    // Object of Connection from the Database
    private static Connection conn = null;

    private static Session session = null;

    // Object of Statement. It is used to create a Statement to execute the query
    private static Statement stmt = null;

    //Object of ResultSet => 'It maintains a cursor that points to the current row in the result set'
    private static ResultSet resultSet = null;

    private static EnvironmentReader fileReader = new EnvironmentReader();

    private static int lport = 1239;

    private static int rport = Integer.valueOf(fileReader.getDbPort());

    ConfigUtil util = new ConfigUtil();

    private final String destPrepareFilePath = util.getRelativeSystemPath() + "/files//dest_prepare_stage.sql";

    public Connection connectDB() throws Exception{
//        private Connection connectDB() throws Exception{

        // Open a connection

        Class.forName("com.mysql.jdbc.Driver");

        if(conn != null && !conn.isClosed())
        {
            conn.close();
//            session.disconnect();
        }

        try {
            if (!fileReader.getDbUrl().equals("127.0.0.1"))
            {
                if (!session.isConnected()) {
                    doSSHConnection();
                }
            }
            else {
                lport = 3306;
            }
        }
        catch (Exception e)
        {
            doSSHConnection();
        }

        String url = "jdbc:mysql://127.0.0.1:" + lport
                + "/" + fileReader.getDbName();

//        System.out.println("DB Url: " + url);
//        System.out.println("DB Username: " + fileReader.getDbUsername());
//        System.out.println("DB Password: " + fileReader.getDbPassword() );
//        System.out.println("Session active? : " + session.isConnected());

        conn = DriverManager.getConnection(url, fileReader.getDbUsername() , fileReader.getDbPassword());
        return  conn;
    }

    public void doSSHConnection()
    {
        String user = "rmanuel@estalea.com";
        String password = "@Vengers1";
        String host = fileReader.getSshHost();

        try
        {
            JSch jsch = new JSch();
            session = jsch.getSession(user,host);
            String rhost = fileReader.getDbUrl();
            session.setPassword(password);
            session.setConfig("StrictHostKeyChecking", "no");
//            System.out.println("Establishing Connection...");
            session.connect();
            int assinged_port=session.setPortForwardingL(lport, rhost, rport);
//            System.out.println("localhost:"+assinged_port+" -> "+rhost+":"+rport);
        }
        catch(Exception e){System.err.print(e);}
    }

    public String getMemberShipType(String findByEmail) throws Exception{
        connectDB();
        String membershipType = "";

        String query = "select * from smn_member a\n" +
                "inner join tmm_user b on b.id = a.id\n" +
                "inner join core_estaleauser c on c.id = b.estaleauser_id\n" +
                "where c.email = \'" + findByEmail + "\'";

        stmt = conn.createStatement();
        resultSet = stmt.executeQuery(query);

        while(resultSet .next()) {
            membershipType=(resultSet.getString("membership_type"));
        }

        closeResultsSet();

        return membershipType;
    }

    public String getClientKey(String findByEmail) throws Exception{
        connectDB();
        String clientKey = "";

        String query = "select client_key from smn_member a\n" +
                "inner join tmm_user b on b.id = a.id\n" +
                "inner join core_estaleauser c on c.id = b.estaleauser_id\n" +
                "where c.email = \'" + findByEmail + "\'";

        stmt = conn.createStatement();
        resultSet = stmt.executeQuery(query);

        while(resultSet .next()) {
            clientKey=(resultSet.getString("client_key"));
        }

        closeResultsSet();

        return clientKey;
    }

    public String getMemberSignUpSource(String findByEmail) throws Exception{
        connectDB();
        String signupSource = "";

        String query = "select signup_source from smn_member a\n" +
                "inner join tmm_user b on b.id = a.id\n" +
                "inner join core_estaleauser c on c.id = b.estaleauser_id\n" +
                "where c.email = \'" + findByEmail + "\'";

        stmt = conn.createStatement();
        resultSet = stmt.executeQuery(query);

        while(resultSet .next()) {
            signupSource=(resultSet.getString("signup_source"));
        }

        closeResultsSet();

        return signupSource;
    }

    public String[] getApplicationSetForMember(String findByEmail) throws Exception{
        connectDB();

        String[] data = new String[2];

        String query = "select * from smn_ma_application_set a\n" +
                "inner join smn_member b on b.id = a.member_id\n" +
                "inner join tmm_user c on c.id = b.id\n" +
                "inner join core_estaleauser d on d.id = c.estaleauser_id\n" +
                "where d.email = '" + findByEmail + "'";

        stmt = conn.createStatement();
        resultSet = stmt.executeQuery(query);

        while(resultSet .next()) {
            data[0]=(resultSet.getString("loan_purpose"));
            data[1]=(resultSet.getString("loan_application_id"));
        }

        closeResultsSet();

        return data;
    }

    public String getApplicationIdByUOE(String findByEmail) throws Exception{
        connectDB();
        String applicationId = "";
        String query = "select * from smn_ma_application_set where uoe = \"" + findByEmail + "\"";

        stmt = conn.createStatement();
        resultSet = stmt.executeQuery(query);

        while(resultSet .next()) {
            applicationId=(resultSet.getString("loan_application_id"));
        }
        closeResultsSet();
        return applicationId;
    }

    public String getApplicationIdByULU(String findByEmail) throws Exception{
        connectDB();
        String applicationId = "";
        String query = "select * from smn_ma_application_set where ulu = \"" + findByEmail + "\"";

        stmt = conn.createStatement();
        resultSet = stmt.executeQuery(query);

        while(resultSet .next()) {
            applicationId=(resultSet.getString("loan_application_id"));
        }
        closeResultsSet();
        return applicationId;
    }

    public String getMemberId(String findByEmail) throws Exception{

        connectDB();

        String membershipId = "";

        String query = "select * from smn_member a\n" +
                "inner join tmm_user b on b.id = a.id\n" +
                "inner join core_estaleauser c on c.id = b.estaleauser_id\n" +
                "where c.email = \'" + findByEmail + "\'";

//        System.out.println(query);

        stmt = conn.createStatement();

        resultSet = stmt.executeQuery(query);

        while(resultSet .next()) {
            membershipId=(resultSet.getString("id"));
        }

        closeResultsSet();

        return membershipId;
    }

    public String getTUEnrollStatus(String findByEmail) throws Exception{

        connectDB();

        String enrollStatus = "";

        String query = "select * from smn_member a\n" +
                "inner join tmm_user b on b.id = a.id\n" +
                "inner join core_estaleauser c on c.id = b.estaleauser_id\n" +
                "where c.email = \'" + findByEmail + "\'";

//         System.out.println(query);

        stmt = conn.createStatement();

        resultSet = stmt.executeQuery(query);

        while(resultSet .next()) {
            enrollStatus=(resultSet.getString("tu_enrolled_status"));
        }

        closeResultsSet();

        return enrollStatus;
    }

    public String getExperianEnrollStatus(String findByEmail) throws Exception{

        connectDB();

        String enrollStatus = "";

        String query = "select * from smn_member a\n" +
                "inner join tmm_user b on b.id = a.id\n" +
                "inner join core_estaleauser c on c.id = b.estaleauser_id\n" +
                "where c.email = \'" + findByEmail + "\'";

//         System.out.println(query);

        stmt = conn.createStatement();

        resultSet = stmt.executeQuery(query);

        while(resultSet .next()) {
            enrollStatus=(resultSet.getString("experian_enrolled_status"));
        }

        closeResultsSet();

        return enrollStatus;
    }

    public String getEmailVerificationCode(String findByEmail) throws Exception{

        connectDB();

        String verificationCode = "";

        String query = "select * from smn_registrant a\n" +
                "where a.email = \'" + findByEmail + "\'";

//         System.out.println(query);

        stmt = conn.createStatement();

        resultSet = stmt.executeQuery(query);

        while(resultSet .next()) {
            verificationCode=(resultSet.getString("email_verification_code"));
        }

        closeResultsSet();

        return verificationCode;
    }

    public String getRegistrantVerificationEmailStatus(String findByEmail) throws Exception{

        connectDB();

        String emailVerificationStatus = "";

        String query = "select * from smn_registrant a\n" +
                "where a.email = \'" + findByEmail + "\'";

        stmt = conn.createStatement();

        resultSet = stmt.executeQuery(query);

        while(resultSet .next()) {
            emailVerificationStatus=(resultSet.getString("email_verified"));
        }

        closeResultsSet();

        return emailVerificationStatus;
    }

    public int getMemberVerificationEmailStatus(String findByEmail) throws Exception{

        connectDB();

        int emailVerificationStatus = 0;

        String query = "select * from core_estaleauser a\n" +
                "where a.email = \'" + findByEmail + "\'";

        stmt = conn.createStatement();

        resultSet = stmt.executeQuery(query);

        while(resultSet .next()) {
            emailVerificationStatus=(resultSet.getInt("verified"));
        }

        closeResultsSet();
        conn.close();
        return emailVerificationStatus;
    }

    public int getMemberVerificationMobileStatus(String findByEmail) throws Exception{

        connectDB();

        int emailVerificationStatus = 0;

        String query = "select * from core_estaleauser a\n" +
                "where a.email = \'" + findByEmail + "\'";

        stmt = conn.createStatement();

        resultSet = stmt.executeQuery(query);

        while(resultSet .next()) {
            emailVerificationStatus=(resultSet.getInt("phone_verified"));
        }

        closeResultsSet();
        conn.close();
        return emailVerificationStatus;
    }

    public String getRegistrantVerificationPhoneStatus(String findByEmail) throws Exception{

        connectDB();

        String phoneVerificationStatus = "";

        String query = "select * from smn_registrant a\n" +
                "where a.email = \'" + findByEmail + "\'";

//         System.out.println(query);

        stmt = conn.createStatement();

        resultSet = stmt.executeQuery(query);

        while(resultSet .next()) {
            phoneVerificationStatus=(resultSet.getString("phone_verified"));
        }

        closeResultsSet();

        return phoneVerificationStatus;
    }

    public Boolean checkEmailExists(String findByEmail) throws Exception{

        connectDB();
        boolean exists = false;

        String query = "select * from core_estaleauser a\n" +
                "where email = \'" + findByEmail + "\'";

        stmt = conn.createStatement();
        resultSet = stmt.executeQuery(query);

        while(resultSet.next()) {
            if (resultSet.getString("email").equals(findByEmail)) {
                exists = true;
            }
        }
        closeResultsSet();

        return exists;
    }

    public void setEmailPhoneVerified(String findByEmail) throws Exception{

        connectDB();
        String query = "update core_estaleauser\n" +
                "set verified = 1,\n" +
                "phone_verified = 1\n" +
                "where email = \'" + findByEmail + "\'";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void setLastCreatedUserEmailPhoneVerified() throws Exception{

        connectDB();
        String query = "update core_estaleauser\n" +
                "set verified = 1,\n" +
                "phone_verified = 1\n" +
                "order by id desc limit 1";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void setClientKeyToNull(String clientKey) throws Exception{

        connectDB();
        String query = "update smn_member set client_key = null\n" +
                "where client_key = '" + clientKey + "'";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void setEmailVerified(String findByEmail) throws Exception
    {
        connectDB();
        String query = "update core_estaleauser\n" +
                "set verified = 1\n" +
                "where email = '" + findByEmail + "'";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void clearLpKey(String lpKey) throws Exception
    {
        connectDB();
        String query = "update smn_member set lpkey = null where lpkey = '" + lpKey + "'";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void setLastCreatedUserAsVerified() throws Exception{

        connectDB();
        String query = "update core_estaleauser set verified = 1, phone_verified = 1 order by id desc limit 1;";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void executeDestPrepare() throws Exception{
        connectDB();
        ScriptRunner sr = new ScriptRunner(conn);
        Reader reader = new BufferedReader(new FileReader(destPrepareFilePath));
        sr.runScript(reader);
        closeResultsSet();
    }

    public void setNameSurnameForMarketPlace(String findByEmail) throws Exception{

        connectDB();
        String query = "update core_estaleauser set first_name = \"Test\", last_name = \"Test\" where email = \"" + findByEmail + "\"";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void setIntroLendApplicationId(String applicationId, String emailAddress) throws Exception{
        connectDB();
        String query = "update smn_ma_application_set set loan_application_id = \"" + applicationId + "\", create_by_introlend = 1 where uoe = \"" + emailAddress + "\";";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void resetLastApplicationSet() throws Exception{
        connectDB();
        String query = "update smn_ma_application_set set loan_application_id = null, loan_application_state = \"Started\", pre_approval_letter_uri = null order by id desc limit 1;";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void dismissAllBanners(String findByEmail) throws Exception{
        connectDB();
        String query = "update smn_member_alert set dismissed = 1,\n" +
                "active = 0\n" +
                "where member_id = (select a.id from smn_member a \n" +
                "inner join tmm_user b on a.id = b.id \n" +
                "inner join core_estaleauser c on c.id = b.`estaleauser_id` \n" +
                "where email = \'" + findByEmail + "\')";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void setLastRefreshDateForMember(String findByEmail) throws Exception{
        connectDB();
        String query = "update smn_member_financial_profile\n" +
                "set last_refresh_date = current_timestamp()\n" +
                "where member_id = (select a.id from smn_member a \n" +
                "inner join tmm_user b on a.id = b.id\n" +
                "inner join core_estaleauser c on c.id = b.estaleauser_id\n" +
                "where email = '" + findByEmail + "')";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void setLastLoginForAllMembers() throws Exception{
        connectDB();
        String query = "update core_estaleauser\n" +
                "set lastlogin_date = current_timestamp()";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void setDOEForAllMembers() throws Exception{
        connectDB();
        String query = "update core_estaleauser set doe = current_timestamp()";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void setCreditSummaryDataForMember(String memberid) throws Exception{
        connectDB();
        String query = "update smn_member_financial_profile \n" +
                "set credit_score_state = 'GOOD',\n" +
                "total_accounts_state = 'RED',\n" +
                "on_time_payments_state = 'RED',\n" +
                "credit_card_usage_state = 'GREEN',\n" +
                "derogatory_marks_state = 'GREEN'\n" +
                "where member_id = '" + memberid + "';";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void setHomeValueDataForMember(String memberid) throws Exception{
        connectDB();
        String query = "update smn_member_financial_profile \n" +
                "set home_value_email_send = 0, \n" +
                "home_value_email_send_date = null, \n" +
                "mortgage_count = 1 \n" +
                "where member_id = '" + memberid + "'";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void setPremiumUpgradeDataForMember(String emailAddress, Integer daysSince) throws Exception{
        connectDB();
        String query = "update core_estaleauser\n" +
                "set doe = (DATE_SUB(NOW(), INTERVAL " + daysSince + " DAY))\n" +
                "where email = '" + emailAddress + "'";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void dismissCreditRefreshBanner(String findByEmail) throws Exception{
        connectDB();
        String query = "update smn_member_alert set dismissed = 1\n" +
                "where alert_type = 'CREDIT_REFRESH_ALERT'\n" +
                "and member_id = (select a.id from smn_member a \n" +
                "inner join tmm_user b on a.id = b.id \n" +
                "inner join core_estaleauser c on c.id = b.`estaleauser_id` \n" +
                "where email = \'" + findByEmail + "\')";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void dismissMobileUnverifiedBanner(String findByEmail) throws Exception{
        connectDB();
        String query = "update smn_member_alert set dismissed = 1\n" +
                "where alert_type = 'MOBILE_UNVERIFIED_ALERT'\n" +
                "and member_id = (select a.id from smn_member a \n" +
                "inner join tmm_user b on a.id = b.id \n" +
                "inner join core_estaleauser c on c.id = b.`estaleauser_id` \n" +
                "where email = \'" + findByEmail + "\')";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void dismissEmailUnverifiedBanner(String findByEmail) throws Exception{
        connectDB();
        String query = "update smn_member_alert set dismissed = 1\n" +
                "where alert_type = 'EMAIL_UNVERIFIED_ALERT'\n" +
                "and member_id = (select a.id from smn_member a \n" +
                "inner join tmm_user b on a.id = b.id \n" +
                "inner join core_estaleauser c on c.id = b.`estaleauser_id` \n" +
                "where email = \'" + findByEmail + "\')";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void setMemberInstructionDateForToday(String findByEmail) throws Exception{
        connectDB();
        String query = "update smn_member_instruction " +
                "set date_to_effect = (DATE_SUB(NOW(), INTERVAL 1 DAY)) " +
                "where uoe = '" + findByEmail + "\'";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    private String getMemberProfileId(String findByEmail) throws Exception{
        connectDB();
        String profileId = "";
        String query = "select a.profile_id \n" +
                "\t\t\tfrom smn_member a \n" +
                "            inner join smn_member_profile b on a.profile_id = b.id\n" +
                "            inner join tmm_user c on c.id = a.id\n" +
                "            inner join core_estaleauser d on d.id = c.estaleauser_id\n" +
                "            where d.email = \'" + findByEmail + "\'";
        stmt = conn.createStatement();
        resultSet = stmt.executeQuery(query);
        while(resultSet .next()) { profileId=(resultSet.getString("profile_id")); }
        closeResultsSet();
        return profileId;
    }

    public String getPromotionUrl(String brainTreeDiscountId) throws Exception
    {
        connectDB();
        String promourl = "";
        String query = "select promotion_url from smn_discount_offer where braintree_discount_id = '" + brainTreeDiscountId + "'";
        stmt = conn.createStatement();
        resultSet = stmt.executeQuery(query);
        while(resultSet .next()) { promourl=(resultSet.getString("promotion_url")); }
        closeResultsSet();
        return promourl;
    }

    public String getTrackingVars(String emailAddress) throws Exception
    {
        connectDB();
        String trackingVars = "";
        String query = "select tracking_vars from smn_member_signup_tracking_vars a\n" +
                "inner join smn_member b on a.id = b.tracking_vars_id\n" +
                "inner join tmm_user c on b.id = c.id\n" +
                "inner join core_estaleauser d on c.estaleauser_id = d.id\n" +
                "where d.email = '" + emailAddress + "'";
        stmt = conn.createStatement();
        resultSet = stmt.executeQuery(query);
        while(resultSet .next()) { trackingVars=(resultSet.getString("tracking_vars")); }
        closeResultsSet();
        return trackingVars;
    }

    public String getLandingRefererUrl(String emailAddress) throws Exception
    {
        connectDB();
        String landing_referer_url = "";
        String query = "select landing_referer_url from smn_member_signup_tracking_vars a\n" +
                "inner join smn_member b on a.id = b.tracking_vars_id\n" +
                "inner join tmm_user c on b.id = c.id\n" +
                "inner join core_estaleauser d on c.estaleauser_id = d.id\n" +
                "where d.email = '" + emailAddress + "'";
        stmt = conn.createStatement();
        resultSet = stmt.executeQuery(query);
        while(resultSet .next()) { landing_referer_url=(resultSet.getString("landing_referer_url")); }
        closeResultsSet();
        return landing_referer_url;
    }

    public String getLandingRefererDomain(String emailAddress) throws Exception
    {
        connectDB();
        String landing_referer_domain = "";
        String query = "select landing_referrer_domain from smn_member_signup_tracking_vars a\n" +
                "inner join smn_member b on a.id = b.tracking_vars_id\n" +
                "inner join tmm_user c on b.id = c.id\n" +
                "inner join core_estaleauser d on c.estaleauser_id = d.id\n" +
                "where d.email = '" + emailAddress + "'";
        stmt = conn.createStatement();
        resultSet = stmt.executeQuery(query);
        while(resultSet .next()) { landing_referer_domain=(resultSet.getString("landing_referrer_domain")); }
        closeResultsSet();
        return landing_referer_domain;
    }

    public void setMemberMobileNumber(String findByEmail) throws Exception
    {
        String profile_id = getMemberProfileId(findByEmail);
        connectDB();
        String query = "update smn_member_profile\n" +
                "set mobile_phone_number = '5173453453',\n" +
                "mobile_phone_number_country = 'US'\n" +
                "where id = \'" + profile_id + "\'";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void truncateMemberInstruction() throws Exception{
        connectDB();
        String query = "truncate smn_member_instruction";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void updateLastRefeshDateAllMembers() throws Exception{
        connectDB();
        String query = "update smn_member_financial_profile set last_refresh_date = current_timestamp()";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void updateCardDebtAllMembers() throws Exception{
        connectDB();
        String query = "update smn_member_financial_profile set credit_card_debt = 0";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void updateSubPrimeAllMembers() throws Exception{
        connectDB();
        String query = "update smn_member_financial_profile set credit_card_sub_prime_qualified = 0";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void updatePrimeAllMembers() throws Exception{
        connectDB();
        String query = "update smn_member_financial_profile set credit_card_prime_qualified = 0";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void updateJoinDOEAllMembers() throws Exception{
        connectDB();
        String query = "update core_estaleauser set doe = current_timestamp()";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void updateDOBAllMembers() throws Exception{
        connectDB();
        String query = "update smn_member_profile set dob = (DATE_SUB(NOW(), INTERVAL 12 DAY))";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void setLastRefreshDateBack(String emailAddress, Integer numberOfDaysBack) throws Exception{
        connectDB();
        String query = "update smn_member_financial_profile set last_refresh_date = (DATE_SUB(NOW(), INTERVAL " + numberOfDaysBack + " DAY))\n" +
                "where member_id = (select a.id from smn_member a inner join tmm_user b on a.id = b.id\n" +
                "inner join core_estaleauser c on c.id = b.estaleauser_id where email = \"" + emailAddress + "\")";
        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void setLastLoginDateBack(String emailAddress, Integer numberOfDaysBack) throws Exception{
        connectDB();
        String query = "update core_estaleauser \n" +
                "set lastlogin_date = (DATE_SUB(NOW(), INTERVAL 9 DAY)) \n" +
                "where email = '" + emailAddress + "'";
        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void setDebtConsolidationData(String emailAddress) throws Exception{
        connectDB();
        String query = "update smn_member_financial_profile set last_refresh_date = (DATE_SUB(NOW(), INTERVAL 2 DAY)),\n" +
                "credit_card_debt = 3001, credit_card_count = 2 where member_id = (select a.id from smn_member a \n" +
                "inner join tmm_user b on a.id = b.id inner join core_estaleauser c on c.id = b.estaleauser_id\n" +
                "where email = '" + emailAddress + "')";
        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void setSubPrimeEmailData(String emailAddress) throws Exception{
        connectDB();
        String query = "update smn_member_financial_profile set last_refresh_date = (DATE_SUB(NOW(), INTERVAL 3 DAY)),\n" +
                "credit_card_sub_prime_qualified = 1 where member_id = (select a.id from smn_member a \n" +
                "inner join tmm_user b on a.id = b.id inner join core_estaleauser c on c.id = b.estaleauser_id\n" +
                "where email = '" + emailAddress + "')";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void setPrimeEmailData(String emailAddress) throws Exception{
        connectDB();
        String query = "update smn_member_financial_profile set last_refresh_date = (DATE_SUB(NOW(), INTERVAL 3 DAY)),\n" +
                "credit_card_prime_qualified = 1 where member_id = (select a.id from smn_member a \n" +
                "inner join tmm_user b on a.id = b.id inner join core_estaleauser c on c.id = b.estaleauser_id\n" +
                "where email = '" + emailAddress + "')";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void setAlertsClientKey(String emailAddress) throws Exception{
        connectDB();
        String query = "update smn_member \n" +
                "set client_key = '6ddfc3e9-1a01-493c-92a9-cf3f866348d4'\n" +
                "where id = (select b.id from tmm_user b \n" +
                "inner join core_estaleauser c on c.id = b.estaleauser_id\n" +
                "where email = '" + emailAddress + "')";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void clearAlertsClientKey(String emailAddress) throws Exception{
        connectDB();
        String query = "update smn_member set client_key = null where client_key = '6ddfc3e9-1a01-493c-92a9-cf3f866348d4'";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void setAnniversaryJoinData(String emailAddress) throws Exception{
        connectDB();
        String query = "update core_estaleauser set doe = (DATE_SUB(NOW(), INTERVAL 365 DAY)) where email = '" + emailAddress + "'";
        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void setBirthdateData(String emailAddress) throws Exception{
        connectDB();
        String query = "update smn_member_profile a set dob = (DATE_SUB(NOW(), INTERVAL 40 YEAR))\n" +
                "where a.id = (select profile_id from smn_member b\n" +
                "inner join tmm_user c on c.id = b.id\n" +
                "inner join core_estaleauser d on d.id = c.`estaleauser_id`\n" +
                "where email = '" + emailAddress + "')";
        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public void enableDisableSmartEmail(Integer enableOrDisable, String uniqueID) throws Exception{
        connectDB();
        String query = "UPDATE core_email_definition SET enabled = \"" + enableOrDisable + "\" WHERE unique_id = \"" + uniqueID + "\"";

        stmt = conn.createStatement();
        stmt.execute(query);
        closeResultsSet();
    }

    public String getMemberInstructionStatus(String findByEmail) throws Exception{
        connectDB();
        String status = "";
        String query = "select * from smn_member_instruction\n" +
                "where uoe = \'" + findByEmail + "\'";

        stmt = conn.createStatement();
        resultSet = stmt.executeQuery(query);
        while(resultSet .next()) { status=(resultSet.getString("status")); }
        closeResultsSet();
        return status;
    }

    private void closeResultsSet(){

        if (resultSet != null) {
            try {
                resultSet.close();
            } catch (Exception e) {
            }
        }

        if (stmt != null) {
            try {
                stmt.close();
            } catch (Exception e) {
            }
        }

        if (conn != null) {
            try {
                conn.close();
                session.disconnect();
            } catch (Exception e) {
            }
        }
    }

}


