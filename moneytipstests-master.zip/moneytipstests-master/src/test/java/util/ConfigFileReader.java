package util;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ConfigFileReader {

    ConfigUtil util = new ConfigUtil();
    private Properties properties;
    private final String propertyFilePath = util.getRelativeSystemPath() + "/src//test//java//configs//config.properties";

    public ConfigFileReader() {
        BufferedReader reader;
        try {
            reader = new BufferedReader(new FileReader(propertyFilePath));
            properties = new Properties();
            try {
                properties.load(reader);
                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            throw new RuntimeException("config.properties not found at " + propertyFilePath);
        }
    }

    public String getDriverPath() {
        String driverPath = properties.getProperty("driverPath");
        if (driverPath != null) return util.getRelativeSystemPath() + driverPath;
        else throw new RuntimeException("driverPath not specified in the config.properties file.");
    }

    public String getBrowser() {
        String browser = properties.getProperty("browser");
        if (browser != null) return browser;
        else throw new RuntimeException("url not specified in the config.properties file.");
    }

    public String getFormFlowConfigId() {
        String formConfigId = properties.getProperty("formConfigId");
        if (formConfigId != null) return formConfigId;
        else throw new RuntimeException("configid not specified in the config.properties file.");
    }

    public String getFormType() {
        String formtype = properties.getProperty("formtype");
        if (formtype != null) return formtype;
        else throw new RuntimeException("formtype not specified in the config.properties file.");
    }

    public String getFormDomain() {
        String formdomain = properties.getProperty("formdomain");
        if (formdomain != null) return formdomain;
        else throw new RuntimeException("formdomain not specified in the config.properties file.");
    }

    public String getEnvironment() {
        String environment = properties.getProperty("environment");
        if (environment != null) return environment;
        else throw new RuntimeException("operatorUrl not specified in the config.properties file.");
    }

    public String getAutoLoginEndpoint() {
        String autoLoginEndpoint = properties.getProperty("autoLoginEndpoint");
        if (autoLoginEndpoint != null) return autoLoginEndpoint;
        else throw new RuntimeException("autoLoginEndpoint not specified in the config.properties file.");
    }
}
