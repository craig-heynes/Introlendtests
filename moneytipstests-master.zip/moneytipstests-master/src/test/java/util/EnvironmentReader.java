package util;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class EnvironmentReader {

    ConfigUtil util = new ConfigUtil();
    private static ConfigFileReader fileReader = new ConfigFileReader();
    private Properties properties;
    private static String propertyFilePath = "";

    public EnvironmentReader() {
        BufferedReader reader;
        String environment = fileReader.getEnvironment();
        try {
            switch (environment) {
                case "stage1":
                    propertyFilePath = util.getRelativeSystemPath() + "/src//test//java//configs//stage1.properties";
                    break;
                case "stage2":
                    propertyFilePath = util.getRelativeSystemPath() + "/src//test//java//configs//stage2.properties";
                    break;
                case "stage3":
                    propertyFilePath = util.getRelativeSystemPath() + "/src//test//java//configs//Stage3.properties";
                    break;
                case "stage4":
                    propertyFilePath = util.getRelativeSystemPath() + "/src//test//java//configs//stage4.properties";
                    break;
                case "stage6":
                    propertyFilePath = util.getRelativeSystemPath() + "/src//test//java//configs//stage6.properties";
                    break;
                case "stage7":
                    propertyFilePath = util.getRelativeSystemPath() + "/src//test//java//configs//stage7.properties";
                    break;
                case "dev":
                    propertyFilePath = util.getRelativeSystemPath() + "/src//test//java//configs//dev.properties";
                    break;
            }
            reader = new BufferedReader(new FileReader(propertyFilePath));
            properties = new Properties();
            try {
                properties.load(reader);
                reader.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            throw new RuntimeException("Environment properties not found at " + propertyFilePath);
        }
    }

    public String getApplicationUrl() {
        String url = properties.getProperty("url");
        if (url != null) return url;
        else throw new RuntimeException("url not specified in the config.properties file.");
    }

    public String getDbUrl() {
        String dburl = properties.getProperty("dburl");
        if (dburl != null) return dburl;
        else throw new RuntimeException("url not specified in the config.properties file.");
    }

    public String getSshHost() {
        String sshHost = properties.getProperty("sshHost");
        if (sshHost != null) return sshHost;
        else throw new RuntimeException("url not specified in the config.properties file.");
    }

    public String getLoggingDbUrl() {
        String logging_dburl = properties.getProperty("logging_dburl");
        if (logging_dburl != null) return logging_dburl;
        else throw new RuntimeException("url not specified in the config.properties file.");
    }

    public String getDbName() {
        String dbname = properties.getProperty("dbname");
        if (dbname != null) return dbname;
        else throw new RuntimeException("url not specified in the config.properties file.");
    }

    public String getLoggingDbName() {
        String logging_dbname = properties.getProperty("logging_dbname");
        if (logging_dbname != null) return logging_dbname;
        else throw new RuntimeException("url not specified in the config.properties file.");
    }

    public String getDbPort() {
        String dbport = properties.getProperty("dbport");
        if (dbport != null) return dbport;
        else throw new RuntimeException("url not specified in the config.properties file.");
    }

    public String getLoggingDbPort() {
        String logging_db_port = properties.getProperty("logging_db_port");
        if (logging_db_port != null) return logging_db_port;
        else throw new RuntimeException("url not specified in the config.properties file.");
    }

    public String getDbUsername() {
        String dbusername = properties.getProperty("dbusername");
        if (dbusername != null) return dbusername;
        else throw new RuntimeException("url not specified in the config.properties file.");
    }

    public String getDbPassword() {
        String dbpassword = properties.getProperty("dbpassword");
        if (dbpassword != null) return dbpassword;
        else throw new RuntimeException("dbpassword not specified in the config.properties file.");
    }

    public String getApiBaseUri() {
        String baseUri = properties.getProperty("baseUri");
        if (baseUri != null) return baseUri;
        else throw new RuntimeException("baseUri not specified in the config.properties file.");
    }

    public String getccmEndPoint() {
        String ccmEndPoint = properties.getProperty("ccmEndPoint");
        if (ccmEndPoint != null) return ccmEndPoint;
        else throw new RuntimeException("ccmEndPoint not specified in the config.properties file.");
    }

    public String getOperatorUrl() {
        String operatorUrl = properties.getProperty("operatorUrl");
        if (operatorUrl != null) return operatorUrl;
        else throw new RuntimeException("operatorUrl not specified in the config.properties file.");
    }
}
