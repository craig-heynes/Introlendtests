package util;

public class UrlBuilder {

    private static ConfigFileReader fileReader = new ConfigFileReader();
    private static EnvironmentReader environmentReader = new EnvironmentReader();

    public String getTmmUrl(String fname, String lname, String email, String address1, String phonenum,
                            String state, String zip, String city) throws Exception{

        return  fileReader.getFormFlowConfigId() + "?" +
                "type=" + fileReader.getFormType() +
                "&domain=" + fileReader.getFormDomain() +
                "&FNAME=" + replaceSpace(fname) +
                "&LNAME=" + replaceSpace(lname) +
                "&EMAIL=" + replaceSpace(email) +
                "&ADDRESS1=" + replaceSpace(address1) +
                "&PRI_PHONE=" + replaceSpace(phonenum) +
                "&STATE=" + replaceSpace(state) +
                "&ZIP=" + replaceSpace(zip) +
                "&CITY=" + replaceSpace(city);
    }

    private String replaceSpace(String oldName){
        String newName = oldName.replaceAll(" ", "%20");
        return newName;
    }

    public String getAutoLoginUrl(String planType, String clientKey, String authToken) throws Exception
    {
        String autoLoginUrl = fileReader.getAutoLoginEndpoint() +
            "?fnl=" + planType.toUpperCase() +
            "#clientkey=" + clientKey +
            "&token=" + authToken;
        System.out.println(environmentReader.getApplicationUrl() + autoLoginUrl);
        return autoLoginUrl;
    }

    public String getRedirectLoginUrl(String memberId, String authToken, String redirectUrl) throws Exception
    {
        String autoLoginUrl = fileReader.getAutoLoginEndpoint() +
                "#memberId=" + memberId +
                "&token=" + authToken +
                "&redirectUrl=" + redirectUrl;
        System.out.println(environmentReader.getApplicationUrl() + autoLoginUrl);
        return autoLoginUrl;
    }
}
