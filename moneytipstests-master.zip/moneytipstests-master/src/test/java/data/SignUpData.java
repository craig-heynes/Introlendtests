package data;

import com.tngtech.java.junit.dataprovider.DataProvider;

import java.util.UUID;

public class SignUpData {

    private static NewEmailAddress address = new NewEmailAddress();
    private static String password = "Terramatrix1";
    private static  String essentialClientKey = "043ff483-2851-42a6-96e2-c1b479f520e8";

    //create essential user using SSN that displays 3 questions
    @DataProvider
    public static Object[][] validEssentialCredsThreeQs() throws Exception {
    return new Object[][] {
            { "James", "Test",address.getValidEmail(),"Terramatrix1","300 Main Road",
            "10001", "5173453456","11111990","1234","666782158"},
        };
    }

    //create essential user using SSN that displays 3 questions
    @DataProvider
    public static Object[][] validEssentialTMMCreds() throws Exception {
        return new Object[][] {
                { "James", "Test",address.getValidEmail(),"19 Cambridge Rd, Great Neck, New York", "5173453456","NY",
                        "11023","Great Neck","1980","1234", password, "666782158"},
        };
    }

    //create essential user using SSN that displays 4 questions
    @DataProvider
    public static Object[][] validEssentialCredsFourQs() throws Exception {
        return new Object[][] {
                { "James", "Test",address.getValidEmail(),"Terramatrix1","300 Main Road",
                        "10001", "5173453456","11111990","1234","899010027"},
        };
    }

    //create premium user using SSN that displays 4 questions
    @org.testng.annotations.DataProvider
    public static Object[][] validPremiumCredsThreeQs() throws Exception {
        return new Object[][] {
                { "James", "Test",address.getValidEmail(),"Terramatrix1","300 Main Road",
                        "10001", "5173453456","11111990","1234","666782158","4111111111111111","123","112020","10001"},
        };
    }

    //create premium user using SSN that displays 4 questions
    @DataProvider
    public static Object[][] validPremiumCredsFourQs() throws Exception {
        return new Object[][] {
                { "James", "Test",address.getValidEmail(),"Terramatrix1","300 Main Road",
                        "10001", "5173453456","11111990","1234","899010027","4111111111111111","123","112020","10001"},
        };
    }

    //create premium user using SSN that displays 4 questions
    @org.testng.annotations.DataProvider
    public static Object[][] validCardInfo() throws Exception {
        return new Object[][] {
                { "4111111111111111","123","112020","10001"},
        };
    }

    @DataProvider
    public static Object[][] createMemberApi() throws Exception {

        UUID uuid = UUID.randomUUID();
        String visitorId = uuid.toString();

        return new Object[][] {
                {visitorId + "@mt.com", password, essentialClientKey, visitorId},
        };
    }
}
