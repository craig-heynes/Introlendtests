package data;

public class GlobalVariables
{
    public static String registrantId;
    public static String loanApplicationId;
    public static String memberId;

    public static boolean coBorrowerPresent = false;
    public static boolean isIntroLendTest = false;
    public static boolean doLogin = true;

    public static final String ESSENTIALCLIENTKEY = "6f2a1f31-c878-45f1-bcd0-f131a13a0767";
    public static final String PREMIUMCLIENTKEY = "0098b533-cdff-4a20-a110-1c23f694c336";
    public static final String ELITECLIENTKEY = "d62872e4-83c3-4e35-b796-c58410be7473";
}
