package data;

import com.tngtech.java.junit.dataprovider.DataProvider;
import util.EnvironmentReader;

import java.util.UUID;

    public class ApiData
    {
        private static EnvironmentReader fileReader = new EnvironmentReader();;
        private static NewEmailAddress address = new NewEmailAddress();
        private static String ssn = ssnToUse();
        private static String[] creditScoreInfo = clientKeyMemberIdToUse();
        private static boolean doThreeBTest = getDoThreeBTest();

        private static final String INTROLENDTOKEN = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiI5QjI1MTk1Qy0yOTBBLTRBQ0UtOTAzQi05MTM0RDREOUM5MTgiLCJzdWIiOiJCNkIzMjhCMC03M0EyLTQ5RjAtODVEQy1DODU4RDEzMDEwQTciLCJlbWFpbCI6Imphc29uK2FkbWluQGNyYWd1bi5uZXQiLCJuYmYiOjE1OTIzOTUyNjYsImV4cCI6MTYwMDE3MTI2NiwiaXNzIjoiY29tLm15YXZlbnUuaWRlbnRpdHkiLCJhdWQiOiJhdmVudSIsImlvLmF2ZW51LmNsYWltcy5maXJzdG5hbWUiOiJKYXNvbiIsImlvLmF2ZW51LmNsYWltcy5sYXN0bmFtZSI6IkFkbWluIiwiaW8uYXZlbnUuY2xhaW1zLnBob25lbnVtYmVyIjoiNjA5NzcxMTk5OSIsImlvLmF2ZW51LmNsYWltcy51c2Vyc3RhdHVzIjoiQWN0aXZlIiwiaW8uYXZlbnUuY2xhaW1zLnJvbGUiOiJTeXN0ZW0gQWRtaW4iLCJpby5hdmVudS5jbGFpbXMuYXNzb2NpYXRpb25pZCI6Ijc4Mzc0QTYwLTlEODgtNDc3Ri05N0RBLUI2NkY5NDc4QzRCMCIsImlvLmF2ZW51LmNsYWltcy5vcmdhbml6YXRpb25pZCI6IkNDQkI1NjhDLTI4M0UtNDUxNi1BODQwLTVBNzNCMkFEMTQ5QSIsImlvLmF2ZW51LmNsYWltcy5vcmdhbml6YXRpb25fc3RhcnRkYXRlIjoiMTIvMTUvMjAxOSIsImlvLmF2ZW51LmNsYWltcy5jYW5fZG9fZXZlcnl0aGluZyI6InRydWUiLCJpby5hdmVudS5jbGFpbXMuZW5yaWNoZWQiOiJ0cnVlIn0.48AnjjwmXQTMTLYIajNLFSt1n2WHAZ5KiYzNv-kLcTU";
        private static final String PASSWORD = "terramatrix";
        private static final String ESSENTIALCLIENTKEY = "043ff483-2851-42a6-96e2-c1b479f520e8";
        private static final String NONCE = "fake-valid-nonce";

        enum planType {
            ESSENTIAL,
            PREMIUM,
            ELITE
        }

        enum brainTreePlanId {
            premium_standard,
            elite_standard
        }

        public enum redirectUrl {
            creditmanager("/credit-manager"),
            mortgageapplication("/mortgage-application"),
            identityprotector("/identity-protector");

            public final String uri;

            private redirectUrl(String uri) {
                this.uri = uri;
            }
        }

        public static String ssnToUse()
        {
            String ssn = fileReader.getccmEndPoint();

            if (ssn.contains("stage-1")) {
                return "111000000";
            }
            else
            {
                return "111000000";
            }
        }

        public static Boolean getDoThreeBTest()
        {
            fileReader = new EnvironmentReader();
            String environment = fileReader.getccmEndPoint();

            if (environment.contains("stage-1")) {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static String[] clientKeyMemberIdToUse()
        {
            String ssn = fileReader.getccmEndPoint();

            String[] arrayList = new String[3];

            if (ssn.contains("stage-1")) {

                arrayList[0] = "55317fe1-4956-4a1c-bf76-455f5353025d";
                arrayList[1] = "489156";
                arrayList[2] = "577";

                return arrayList;
            }
            else
            {
                arrayList[0] = "d85bf2f8-12f4-4f22-b25d-12f7dfc9c67f";
                arrayList[1] = "4130361";
                arrayList[2] = "685";

                return arrayList;
            }
        }

        @org.testng.annotations.DataProvider
        public static Object[][] getCreditScore() {

            return new Object[][] {
                    {creditScoreInfo},
            };
        }

        @org.testng.annotations.DataProvider
        public static Object[][] createEssentialMember() throws Exception {

            UUID uuid = UUID.randomUUID();
            String visitorId = uuid.toString();

            return new Object[][] {
                    {address.getValidEmail(), PASSWORD, visitorId, "Joel", "Arbic", "104 60 QUEENS BOULEVARD", "11375", "08/13/1935", "4105328335", ssn, planType.ESSENTIAL.toString(),
                            redirectUrl.creditmanager.uri.toString(), false, "FOREST HILLS", "NY", "1935-08-13"},
            };
        }

        @org.testng.annotations.DataProvider
        public static Object[][] createEssentialMemberForFastTrack() throws Exception {

            UUID uuid = UUID.randomUUID();
            String visitorId = uuid.toString();

            return new Object[][] {
                    {address.getValidEmail(), PASSWORD, visitorId, "Joel", "Arbic", "104 60 QUEENS BOULEVARD", "11375", "08/13/1935", "4105328335", ssn, planType.ESSENTIAL.toString(),
                            redirectUrl.mortgageapplication.uri.toString(), false, "FOREST HILLS", "NY", "1935-08-13"},
            };
        }

        @org.testng.annotations.DataProvider
        public static Object[][] clientKeyUser() throws Exception {

            UUID uuid = UUID.randomUUID();
            String visitorId = uuid.toString();

            return new Object[][] {
                    {address.getValidEmail(), PASSWORD, visitorId, "Joel", "Arbic", "104 60 QUEENS BOULEVARD", "11375", "1994-01-01", "4105328335", ssn, planType.ESSENTIAL.toString(), redirectUrl.mortgageapplication.uri.toString(), false, "FOREST HILLS", "NY"},
            };
        }

        @DataProvider
        public static Object[][] newEmailAddress() throws Exception {

            UUID uuid = UUID.randomUUID();
            String visitorId = uuid.toString();

            return new Object[][] {
                    {address.getValidEmail()},
            };
        }

        @org.testng.annotations.DataProvider
        public static Object[][] createEssentialMemberForThreeB() throws Exception {

            UUID uuid = UUID.randomUUID();
            String visitorId = uuid.toString();

            return new Object[][] {
                    {address.getValidEmail(), PASSWORD, visitorId, "Joel", "Arbic", "104 60 QUEENS BOULEVARD", "11375", "08/13/1935", "4105328335", ssn, planType.ESSENTIAL.toString(),
                            redirectUrl.creditmanager.uri.toString(), true},
            };
        }

        @org.testng.annotations.DataProvider
        public static Object[][] createPremiumMember() throws Exception {

            UUID uuid = UUID.randomUUID();
            String visitorId = uuid.toString();

            return new Object[][] {
                    {address.getValidEmail(), PASSWORD, visitorId, "Joel", "Arbic", "104 60 QUEENS BOULEVARD", "11375", "08/13/1935", "4105328335", ssn, planType.PREMIUM.toString(),
                            NONCE, brainTreePlanId.premium_standard.toString(), redirectUrl.identityprotector.uri.toString(), "FOREST HILLS", "NY", "1935-08-13"},
            };
        }

        @org.testng.annotations.DataProvider
        public static Object[][] createPremiumMemberForUISignUp() throws Exception {

            UUID uuid = UUID.randomUUID();
            String visitorId = uuid.toString();

            return new Object[][] {
                    {address.getValidEmail(), PASSWORD, "Joel", "Arbic", "104 60 QUEENS BOULEVARD", "11375", "08/13/1935",
                            "4105328335", ssn, "4111111111111111", "123", "01/30", "12345", doThreeBTest},
            };
        }

        @org.testng.annotations.DataProvider
        public static Object[][] createEssentialMemberForUISignUp() throws Exception {

            UUID uuid = UUID.randomUUID();
            String visitorId = uuid.toString();

            return new Object[][] {
                    {address.getValidEmail(), PASSWORD, "Joel", "Arbic", "104 60 QUEENS BOULEVARD", "11375", "08/13/1935",
                            "4105328335", ssn, doThreeBTest},
            };
        }

        @org.testng.annotations.DataProvider
        public static Object[][] createEliteMember() throws Exception {

            UUID uuid = UUID.randomUUID();
            String visitorId = uuid.toString();

            return new Object[][] {
                    {address.getValidEmail(), PASSWORD, visitorId, "Joel", "Arbic", "104 60 QUEENS BOULEVARD", "11375", "08/13/1935", "4105328335", ssn, planType.ELITE.toString(),
                            NONCE, brainTreePlanId.elite_standard.toString(), redirectUrl.identityprotector.uri.toString(), "FOREST HILLS", "NY", "1935-08-13"},
            };
        }

        @org.testng.annotations.DataProvider
        public static Object[][] newVistor() throws Exception {

            UUID uuid = UUID.randomUUID();
            String visitorId = uuid.toString();

            return new Object[][] {
                    {address.getValidEmail(), visitorId},
            };
        }

        @org.testng.annotations.DataProvider
        public static Object[][] existingMember() throws Exception {

            return new Object[][] {
                    {"freecredit1@gmail.com"},
            };
        }

        @org.testng.annotations.DataProvider
        public static Object[][] createRegistrantEssential() throws Exception {

            UUID uuid = UUID.randomUUID();
            String visitorId = uuid.toString();

            return new Object[][] {
                    {"Jay", "Iron", address.getValidEmail(), PASSWORD, visitorId, planType.ESSENTIAL.toString()},
            };
        }

        @org.testng.annotations.DataProvider
        public static Object[][] createRegistrantPremium() throws Exception {

            UUID uuid = UUID.randomUUID();
            String visitorId = uuid.toString();

            return new Object[][] {
                    {"Jay", "Iron", address.getValidEmail(), PASSWORD, visitorId, planType.PREMIUM.toString()},
            };
        }

        @org.testng.annotations.DataProvider
        public static Object[][] createRegistrantElite() throws Exception {

            UUID uuid = UUID.randomUUID();
            String visitorId = uuid.toString();

            return new Object[][] {
                    {"Jay", "Iron", address.getValidEmail(), PASSWORD, visitorId, planType.ELITE.toString()},
            };
        }

        @org.testng.annotations.DataProvider
        public static Object[][] createEssentialRegistrantAllFields() throws Exception {

            UUID uuid = UUID.randomUUID();
            String visitorId = uuid.toString();

            return new Object[][] {
                    {"Jay", "Iron", address.getValidEmail(), PASSWORD, visitorId, "300 Main Road",
                            "New York", "NY", "10001", "01/01/1975", "5173453333", ESSENTIALCLIENTKEY,
                            planType.ESSENTIAL.toString(), null, null, null},
            };
        }

        @org.testng.annotations.DataProvider
        public static Object[][] createPremiumRegistrantAllFields() throws Exception {

            UUID uuid = UUID.randomUUID();
            String visitorId = uuid.toString();

            return new Object[][] {
                    {"Jay", "Iron", address.getValidEmail(), PASSWORD, visitorId, "300 Main Road",
                            "New York", "NY", "10001", "01/01/1975", "5173453333",
                            ESSENTIALCLIENTKEY, planType.PREMIUM.toString(), "fake-valid-nonce",
                            brainTreePlanId.premium_standard.toString()},
            };
        }

        @org.testng.annotations.DataProvider
        public static Object[][] createEliteRegistrantAllFields() throws Exception {

            UUID uuid = UUID.randomUUID();
            String visitorId = uuid.toString();

            return new Object[][] {
                    {"Jay", "Iron", address.getValidEmail(), PASSWORD, visitorId, "300 Main Road",
                            "New York", "NY", "10001", "01/01/1975", "5173453333",
                            ESSENTIALCLIENTKEY, planType.ELITE.toString(), "fake-valid-nonce",
                            brainTreePlanId.elite_standard.toString()},
            };
        }

        @org.testng.annotations.DataProvider
        public static Object[][] createApplicationId() throws Exception {
            return new Object[][] {
                    {INTROLENDTOKEN},
            };
        }

        @org.testng.annotations.DataProvider
        public static Object[][] createApplicantEmailAddress() throws Exception {
            return new Object[][] {
                    {address.getValidEmail(), INTROLENDTOKEN},
            };
        }

        @org.testng.annotations.DataProvider
        public static Object[][] createCoBorrowerEmailAddress() throws Exception {
            return new Object[][] {
                    {address.getValidEmail()},
            };
        }
    }
