package data;

public class OperatorData {
    public static final String CREDIT_REFRESH_JOB = "credit_refresh_email_sender_job";
    public static final String MEMBER_INSTRUCTION_JOB = "member_instruction_job";
    public static final String CREDIT_SCORE_CHANGE_JOB = "credit_score_changed_email_sender_job";
    public static final String ANNIVERSARY_JOB = "member_anniversary_email_sender_job";
    public static final String BIRTHDAY_JOB = "member_birthday_email_sender_job";
    public static final String DEBTCONSOLIDATION_JOB = "debt_consolidation_email_sender_job";
    public static final String SUBPRIME_JOB = "member_credit_sub_prime_email_sender_job";
    public static final String PRIME_JOB = "member_credit_prime_email_sender_job";
    public static final String CREDITSUMMARY_JOB = "credit_summary_email_sender_job";
    public static final String HOMEVALUE_JOB = "home_value_email_sender_job";
    public static final String PREMIUM_UPGRADE_JOB = "premium_upgrade_email_sender_job";

    public static final Integer SCORE_CHANGED_DAYS = 45;
    public static final Integer CREDIT_SCORE_REFRESH_DAYS = 30;

    //core_email_definition id's
    public static final String CREDITREFRESH_ID = "email.credit.refresh";
    public static final String CREDITSCORECHANGE_ID = "email.credit.score.change";
    public static final String BIRTHDAY_ID = "email.member.birthday";
    public static final String ANNIVERSARY_ID = "email.member.anniversary";
    public static final String SUBPRIME_ID = "email.member.offer.credit.subprime";
    public static final String PRIME_ID = "email.member.offer.credit.prime";
    public static final String CCMALERT_ID = "email.member.ccm.alert";
    public static final String ALERTLINKREMINDER_ID = "email.member.alert.link.reminder";
    public static final String PREMIUMGRDADE_ID = "email.member.upgrade.premium";
    public static final String ESSENTIAL_TO_PREMIUM_UPGRADE_ID = "email.essential.member.upgrade.premium";
    public static final String ESSENTIAL_TO_ELITE_UPGRADE_ID = "email.elite.upgrade.welcome";
    public static final String HOMEVALUEANALYSIS_ID = "email.member.home.value.analysis";
    public static final String DEBTCONSOLIDATION_ID = "email.member.debt.consolidation";
    public static final String CREDITSUMMARY_ID = "email.member.credit.summary";
}
