package data;

import org.json.simple.JSONObject;

import java.util.UUID;

public class IntroLendRequestBuilder
{
    private static final String nonce = "fake-valid-nonce";

    public JSONObject getMemberCreateRequestForAgentWithAddress(String emailAddress, String loanPurpose)
    {
        JSONObject applicationCreateRequest = new JSONObject();
        JSONObject loanOfficerParams = new JSONObject();
        org.json.JSONArray loanOfficerArray = new org.json.JSONArray();

        UUID uuid = UUID.randomUUID();
        String newGuid = uuid.toString();

        applicationCreateRequest.put("externalID", newGuid);
        applicationCreateRequest.put("firstName", "Armando");
        applicationCreateRequest.put("lastName", "CONTRERAS");
        applicationCreateRequest.put("emailAddress", emailAddress);
        applicationCreateRequest.put("mobilePhoneNumber", "4045049000");
        applicationCreateRequest.put("address1", "309 W 106th St");
        applicationCreateRequest.put("unitNumber", null);
        applicationCreateRequest.put("city", "New York");
        applicationCreateRequest.put("state", "NY");
        applicationCreateRequest.put("zipCode", "10025");
        applicationCreateRequest.put("suppressUserCorrespondence", false);
        applicationCreateRequest.put("suppressLenderCorrespondence", false);
        applicationCreateRequest.put("loanPurpose", loanPurpose);

        loanOfficerParams.put("guid", "93667bc0-0626-40c0-a4cb-c60bc56e9b7f");
        loanOfficerParams.put("firstName", "John");
        loanOfficerParams.put("lastName", "Cena");
        loanOfficerParams.put("emailAddress", "mtstage1+90001@gmail.com");
        loanOfficerParams.put("phoneNumber", "4045049001");
        loanOfficerParams.put("companyName", "WWE");

        loanOfficerArray.put(loanOfficerParams);
        applicationCreateRequest.put("loanOfficers", loanOfficerArray);

        System.out.println(applicationCreateRequest.toJSONString());
        return applicationCreateRequest;
    }

    public JSONObject getLoanOfficerCreateRequest(String loanApplicationId)
    {
        JSONObject applicationCreateRequest = new JSONObject();
        JSONObject loanOfficerParams = new JSONObject();
        org.json.JSONArray loanOfficerArray = new org.json.JSONArray();

        applicationCreateRequest.put("loanApplicationID", loanApplicationId);

        loanOfficerParams.put("firstName", "John");
        loanOfficerParams.put("lastName", "Cena");
        loanOfficerParams.put("emailAddress", "mtstage1+90001@gmail.com");
        loanOfficerParams.put("phoneNumber", "4045049001");
        loanOfficerParams.put("companyName", "WWE");

        loanOfficerArray.put(loanOfficerParams);
        applicationCreateRequest.put("loanOfficers", loanOfficerArray);

        System.out.println(applicationCreateRequest.toJSONString());
        return applicationCreateRequest;
    }

    public JSONObject getMemberCreateRequestForIntroLend(String emailAddress, String password, String visitorId, String firstName,
                                                         String lastName, String address, String zipCode, String dateOfBirth,
                                                         String phoneNumber, String ssn9, String planType, String redirectUrl,
                                                         String clientKey, String loanApplicationId)
    {
        JSONObject memberCreateRequest = new JSONObject();
        JSONObject memberDataParams = new JSONObject();
        memberDataParams.put("firstName", firstName);
        memberDataParams.put("lastName", lastName);
        memberDataParams.put("zipCode", zipCode);
        memberDataParams.put("password", password);
        memberDataParams.put("address", address);
        memberDataParams.put("phoneNumber", phoneNumber);
        memberDataParams.put("planType", planType);
        memberDataParams.put("clientKey", clientKey);
        memberDataParams.put("dateOfBirth", dateOfBirth);
        memberDataParams.put("email", emailAddress);
        memberDataParams.put("visitorId", visitorId);
        memberDataParams.put("loanApplicationID", loanApplicationId);
        memberCreateRequest.put("initialRedirectUri", redirectUrl);
        memberCreateRequest.put("realEstateAgentId", "06ce4a12-9b9d-4757-86e7-a3b798d57c89");
        memberCreateRequest.put("memberData", memberDataParams);

        System.out.println(memberCreateRequest.toJSONString());
        return memberCreateRequest;
    }
}
