package data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class QuestionAnswerData {

    public static Map<String,ArrayList<String> > getQuestionAnswer()
    {

        HashMap<String, ArrayList<String>> questions = new HashMap<>();

        ArrayList<String> answersList1=new ArrayList<>();
        answersList1.add("Ashwood");
        answersList1.add("Bowen");
        answersList1.add("Bond");
        answersList1.add("Cambridge");
        answersList1.add("Ashford Cables Dr");
        answersList1.add("None of the Above");
        questions.put("Which of these street names are you associated with?", answersList1);

        ArrayList<String> answersList2=new ArrayList<>();
        answersList2.add("New Hampshire");
        answersList2.add("California");
        answersList2.add("None of the Above");
        questions.put("What state was your social security number issued (this could be the state in which you were born or had your first job)?", answersList2);

        ArrayList<String> answersList3=new ArrayList<>();
        answersList3.add("None of the Above");
        questions.put("What is the term (in months) of your most recent auto loan or lease?", answersList3);

        ArrayList<String> answersList4=new ArrayList<>();
        answersList4.add("None of the Above");
        questions.put("What year was your most recent mortgage established?", answersList4);

        ArrayList<String> answersList5=new ArrayList<>();
        answersList5.add("Iec");
        answersList5.add("None of the Above");
        questions.put("Which of the following is a current or previous employer?", answersList5);

        ArrayList<String> answersList6=new ArrayList<>();
        answersList6.add("None of the Above");
        questions.put("What is the monthly payment of your student loan?", answersList6);

        ArrayList<String> answersList7=new ArrayList<>();
        answersList7.add("None of the Above");
        questions.put("What is the balance of your most recent mortgage?",answersList7);

        ArrayList<String> answersList8=new ArrayList<>();
        answersList8.add("None of the Above");
        questions.put("Which of these last names have you used previously?", answersList8);

        ArrayList<String> answersList9=new ArrayList<>();
        answersList9.add("None of the Above");
        questions.put("What was the original amount of your most recent auto loan or lease?", answersList9);

        ArrayList<String> answersList10=new ArrayList<>();
        answersList10.add("None of the Above");
        questions.put("What year was your most recent auto loan or lease established?", answersList10);

        ArrayList<String> answersList11=new ArrayList<>();
        answersList11.add("None of the Above");
        questions.put("What was the original amount of your most recent mortgage?", answersList11);

        ArrayList<String> answersList12=new ArrayList<>();
        answersList12.add("None of the Above");
        questions.put("What is the monthly payment of your most recent mortgage?", answersList12);

        ArrayList<String> answersList13=new ArrayList<>();
        answersList13.add("None of the Above");
        questions.put("What is the monthly payment of your most recent auto loan or lease?", answersList13);

        ArrayList<String> answersList14=new ArrayList<>();
        answersList14.add("None of the Above");
        questions.put("In 2007, what county did you live in?", answersList14);

        ArrayList<String> answersList15=new ArrayList<>();
        answersList15.add("Alpine");
        questions.put("In what county do you live?", answersList15);

        ArrayList<String> answersList16=new ArrayList<>();
        answersList16.add("Pepsi Co.");
        questions.put("Which of these businesses are you associated with?", answersList16);

        return questions;

    }

}
