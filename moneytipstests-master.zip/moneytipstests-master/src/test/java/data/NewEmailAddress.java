package data;

import java.util.Random;

public class NewEmailAddress {

    private String getGetRandomEmail() {
        Random randomGenerator = new Random();
        int randomInt = randomGenerator.nextInt(1000);
        return "mtstage1+" + randomInt + "@gmail.com";
    }

    private String getOffLineRandomEmail() {
        Random randomGenerator = new Random();
        int randomInt = randomGenerator.nextInt(10)
                + randomGenerator.nextInt(100)
                + randomGenerator.nextInt(1000)
                + randomGenerator.nextInt(10000)
                + randomGenerator.nextInt(100000)
                + randomGenerator.nextInt(1000000)
                + randomGenerator.nextInt(10000000);
        return "mtstage1+" + randomInt + "@gmail.com";
    }

    public String getValidEmail() throws Exception{
//        String email = getGetRandomEmail();
//        DatabaseUtil util = new DatabaseUtil();
//        while(util.checkEmailExists(email)){
//            email = getGetRandomEmail();
//        }
//        return email;

        return getOffLineRandomEmail();
    }
}
