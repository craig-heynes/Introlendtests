package data;

import org.json.simple.JSONObject;

public class ApiRequestBuilder
{
    private static final String nonce = "fake-valid-nonce";

    public JSONObject getMemberCreateRequestForEssential(String emailAddress, String password, String visitorId, String firstName,
                                                         String lastName, String address, String zipCode, String dateOfBirth,
                                                         String phoneNumber, String ssn9, String planType, String redirectUrl,
                                                         String clientKey, String loanPurpose, String memberSignUpSource, String lpKey)
    {
        JSONObject memberCreateRequest = new JSONObject();
        JSONObject memberDataParams = new JSONObject();
        memberDataParams.put("firstName", firstName);
        memberDataParams.put("lastName", lastName);
        memberDataParams.put("zipCode", zipCode);
        memberDataParams.put("password", password);
        memberDataParams.put("address", address);
        memberDataParams.put("phoneNumber", phoneNumber);
        memberDataParams.put("planType", planType);
        memberDataParams.put("clientKey", clientKey);
        memberDataParams.put("dateOfBirth", dateOfBirth);
        memberDataParams.put("email", emailAddress);
        memberDataParams.put("visitorId", visitorId);
        if (lpKey!=null) {
            memberDataParams.put("lpKey", lpKey);
        }
        if (loanPurpose!=null)
        {
            memberDataParams.put("loanPurpose", loanPurpose);
        }
        if (memberSignUpSource!=null)
        {
            memberDataParams.put("memberSignupSource", memberSignUpSource);
        }
        memberCreateRequest.put("initialRedirectUri", redirectUrl);
        memberCreateRequest.put("realEstateAgentId", visitorId);
        memberCreateRequest.put("memberData", memberDataParams);

        System.out.println(memberCreateRequest.toJSONString());
        return memberCreateRequest;
    }

    public JSONObject getMemberCreateRequestForPremium(String emailAddress, String password, String visitorId, String firstName, String lastName, String
            address, String zipCode, String dateOfBirth, String phoneNumber, String ssn9, String planType, String redirectUrl, String clientKey, String nonce, String btSubscriptionPlan)
    {
        JSONObject memberCreateRequest = new JSONObject();
        JSONObject memberDataParams = new JSONObject();

        memberDataParams.put("firstName", firstName);
        memberDataParams.put("lastName", lastName);
        memberDataParams.put("zipCode", zipCode);
        memberDataParams.put("password", password);
        memberDataParams.put("address", address);
        memberDataParams.put("phoneNumber", phoneNumber);
        memberDataParams.put("planType", planType);
        memberDataParams.put("clientKey", clientKey);
        memberDataParams.put("dateOfBirth", dateOfBirth);
        memberDataParams.put("email", emailAddress);
        memberDataParams.put("visitorId", visitorId);
        memberDataParams.put("nonce", nonce);
        memberDataParams.put("btSubscriptionPlanId", btSubscriptionPlan);

        memberCreateRequest.put("initialRedirectUri", redirectUrl);
        memberCreateRequest.put("realEstateAgentId", visitorId);
        memberCreateRequest.put("memberData", memberDataParams);

        System.out.println(memberCreateRequest.toJSONString());
        return memberCreateRequest;
    }

    public JSONObject getMemberCreateRequestForElite(String emailAddress, String password, String visitorId, String firstName, String lastName, String
            address, String zipCode, String dateOfBirth, String phoneNumber, String ssn9, String planType, String redirectUrl, String clientKey, String nonce, String btSubscriptionPlan)
    {
        JSONObject memberCreateRequest = new JSONObject();
        JSONObject memberDataParams = new JSONObject();

        memberDataParams.put("firstName", firstName);
        memberDataParams.put("lastName", lastName);
        memberDataParams.put("zipCode", zipCode);
        memberDataParams.put("password", password);
        memberDataParams.put("address", address);
        memberDataParams.put("phoneNumber", phoneNumber);
        memberDataParams.put("planType", planType);
        memberDataParams.put("clientKey", clientKey);
        memberDataParams.put("dateOfBirth", dateOfBirth);
        memberDataParams.put("email", emailAddress);
        memberDataParams.put("visitorId", visitorId);
        memberDataParams.put("nonce", nonce);
        memberDataParams.put("btSubscriptionPlanId", btSubscriptionPlan);

        memberCreateRequest.put("initialRedirectUri", redirectUrl);
        memberCreateRequest.put("realEstateAgentId", visitorId);
        memberCreateRequest.put("memberData", memberDataParams);

        System.out.println(memberCreateRequest.toJSONString());
        return memberCreateRequest;
    }

    public JSONObject getMemberCreateRequestFromRegistrant(String redirectUrl)
    {
        JSONObject memberCreateRequest = new JSONObject();

        memberCreateRequest.put("registrantId", GlobalVariables.registrantId);
        memberCreateRequest.put("initialRedirectUri", redirectUrl);

        return memberCreateRequest;
    }

    public JSONObject getEmailVerificationRequestForRegistrant(String emailAddress, String verificationDate)
    {
        JSONObject verificationRequest = new JSONObject();

        verificationRequest.put("registrantId", GlobalVariables.registrantId);
        verificationRequest.put("email", emailAddress);
        verificationRequest.put("emailVerificationDate", verificationDate);

        return verificationRequest;
    }

    public JSONObject getMobileVerificationRequestForRegistrant(String mobileNumber, String verificationDate)
    {
        JSONObject verificationRequest = new JSONObject();

        verificationRequest.put("registrantId", GlobalVariables.registrantId);
        verificationRequest.put("mobileNumber", mobileNumber);
        verificationRequest.put("phoneVerificationDate", verificationDate);

        return verificationRequest;
    }

    //registrant requests

    public JSONObject getRegistrantCreateRequest(String firstName, String lastName,
                                                 String emailAddress, String password,
                                                 String planType, String visitorId)
    {
        JSONObject registrantCreateRequest = new JSONObject();

        registrantCreateRequest.put("firstName", firstName);
        registrantCreateRequest.put("lastName", lastName);
        registrantCreateRequest.put("email", emailAddress);
        if (password!=null){
            registrantCreateRequest.put("password", password);
        }
        registrantCreateRequest.put("planType", planType);
        registrantCreateRequest.put("visitorId", visitorId);

        return registrantCreateRequest;
    }

    public JSONObject getRegistrantUpdateRequest(String address, String city, String state,
                                                 String zipCode, String dateOfBirth, String phoneNumber,
                                                 String clientKey, String nonce, String btSubscriptionPlanId)
    {
        JSONObject registrantUpdateRequest = new JSONObject();
        JSONObject metaData = new JSONObject();

        registrantUpdateRequest.put("address", address);
        registrantUpdateRequest.put("city", city);
        registrantUpdateRequest.put("state", state);
        registrantUpdateRequest.put("zipCode", zipCode);
        registrantUpdateRequest.put("dateOfBirth", dateOfBirth);
        registrantUpdateRequest.put("phoneNumber", phoneNumber);
        registrantUpdateRequest.put("clientKey", clientKey);
        if (nonce!=null)
        {
            registrantUpdateRequest.put("nonce", nonce);
        }
        if (btSubscriptionPlanId!=null)
        {
            registrantUpdateRequest.put("btSubscriptionPlanId", btSubscriptionPlanId);
        }
        registrantUpdateRequest.put("metaData", metaData);

        return registrantUpdateRequest;
    }

    public JSONObject getRegistrantCreateRequestAllFields(String firstName, String lastName, String emailAddress, String password,
                                                          String planType, String visitorId, String address, String city, String state,
                                                          String zipCode, String dateOfBirth, String phoneNumber,
                                                          String clientKey, String nonce, String btSubscriptionPlanId,
                                                          String lpKey, String memberSignUpSource, String loanPurpose)
    {
        JSONObject registrantCreateRequest = new JSONObject();
        JSONObject metaData = new JSONObject();

        registrantCreateRequest.put("firstName", firstName);
        registrantCreateRequest.put("lastName", lastName);
        registrantCreateRequest.put("email", emailAddress);
        registrantCreateRequest.put("planType", planType);
        registrantCreateRequest.put("visitorId", visitorId);
        registrantCreateRequest.put("address", address);
        registrantCreateRequest.put("city", city);
        registrantCreateRequest.put("state", state);
        registrantCreateRequest.put("zipCode", zipCode);
        registrantCreateRequest.put("dateOfBirth", dateOfBirth);
        registrantCreateRequest.put("phoneNumber", phoneNumber);
        registrantCreateRequest.put("clientKey", clientKey);

        if (nonce!=null)
        {
            registrantCreateRequest.put("nonce", nonce);
        }

        if (btSubscriptionPlanId!=null)
        {
            registrantCreateRequest.put("btSubscriptionPlanId", btSubscriptionPlanId);
        }

        registrantCreateRequest.put("metaData", metaData);
        if (password!=null){
            registrantCreateRequest.put("password", password);
        }

        if (lpKey!=null){
            registrantCreateRequest.put("lpKey", lpKey);
        }

        if (memberSignUpSource!=null){
            registrantCreateRequest.put("memberSignupSource", memberSignUpSource);
        }

        if (loanPurpose!=null){
            registrantCreateRequest.put("loanPurpose", loanPurpose);
        }

        System.out.println(registrantCreateRequest.toJSONString());

        return registrantCreateRequest;
    }

    public JSONObject getEmailCreateRequest(String sendgridTemplateId, String sendgridDomain,
                                            String emailAddress, String category, String recipientName,
                                            String subject, String fromAddress, String fromName,
                                            String baseUrl, String trackingVar)
    {
        JSONObject emailCreateRequest = new JSONObject();
        JSONObject data = new JSONObject();

        data.put("baseUrl", baseUrl);
        data.put("trackingVar", trackingVar);
        emailCreateRequest.put("sendgridTemplateId", sendgridTemplateId);
        emailCreateRequest.put("sendgridDomain", sendgridDomain);
        if(emailAddress!=null)
        {
            emailCreateRequest.put("email", emailAddress);
        }
        emailCreateRequest.put("category", category);
        emailCreateRequest.put("recipientName", recipientName);
        emailCreateRequest.put("subject", subject);
        emailCreateRequest.put("fromAddress", fromAddress);
        if(fromName!=null)
        {
            emailCreateRequest.put("fromName", fromName);
        }
        emailCreateRequest.put("data", data);

        return emailCreateRequest;
    }

    public JSONObject getThreeBPurchaseRequest(String memberId, String purchasePrice)
    {
        JSONObject threeBRequest = new JSONObject();

        threeBRequest.put("memberId", memberId);
        threeBRequest.put("nonce", nonce);
        threeBRequest.put("purchasePrice", purchasePrice);

        System.out.println(threeBRequest.toJSONString());

        return threeBRequest;
    }

    public JSONObject getCcmPersonalInfoRequest(String firstName, String lastName, String dateOfBirth,
                                                String address, String city, String state, String zipCode,
                                                String phoneNumber, String emailAdress, String socialSecurity) {
        JSONObject personalInfo = new JSONObject();
        JSONObject ssn = new JSONObject();
        JSONObject personInfoRequest = new JSONObject();
        String ssn4=null;
        String ssn9=null;

        if (socialSecurity==null)
        {
            ssn4="1234";
        }
        else {
            ssn9=socialSecurity;
        }

        personalInfo.put("firstName", firstName);
        personalInfo.put("lastName", lastName);
        personalInfo.put("dob", dateOfBirth);
        personalInfo.put("address", address);
        personalInfo.put("city", city);
        personalInfo.put("state", state);
        personalInfo.put("zip", zipCode);
        personalInfo.put("phone", phoneNumber);
        personalInfo.put("email", emailAdress);

        ssn.put("ssn4", ssn4);
        ssn.put("ssn9", ssn9);

        personInfoRequest.put("personalIdentifiableInfo", personalInfo);
        personInfoRequest.put("ssn", ssn);

        System.out.println(personalInfo.toJSONString());

        return personInfoRequest;
    }
}
