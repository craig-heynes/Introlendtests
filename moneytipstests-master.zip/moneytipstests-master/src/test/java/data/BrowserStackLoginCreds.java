package data;

public class BrowserStackLoginCreds {
    public static final String USERNAME = "moneytipsui1";
    public static final String AUTOMATE_KEY = "gcML8k83eV8EX8xv9hsH";
    public static final String URL = "https://" + USERNAME + ":" + AUTOMATE_KEY + "@hub-cloud.browserstack.com/wd/hub";
}
