package introlendhelpertests;

import data.ApiData;
import data.IntroLendRequestBuilder;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;
import io.restassured.specification.RequestSpecification;
import org.junit.Assert;
import org.testng.annotations.Test;

import javax.swing.*;
import java.util.UUID;

public class AddLoanOfficer {

    String loanApplicationId;

    @Test (dataProviderClass = ApiData.class, dataProvider = "createApplicationId")
    public void f_loadBids(String token)
    {
        if (loanApplicationId==null) {
            showApplicationDialog();

            if (loanApplicationId != null) {
                UUID uuid = UUID.randomUUID();
                String requestId = uuid.toString();
                RequestSpecification request = RestAssured.given();
                request.header("Authorization", "Bearer " + token);
                request.header("Content-Type", "application/json");
                request.header("x-requestid", requestId);
                IntroLendRequestBuilder requestBuilder = new IntroLendRequestBuilder();
                request.body(requestBuilder.getLoanOfficerCreateRequest(loanApplicationId).toJSONString());
                Response response = request.post("https://lending-api-dev.avenu.io/api/v1/Mortgage/" + loanApplicationId + "/bids");

                Assert.assertEquals(response.statusCode(), 200);
                ResponseBody bodyCreate = response.getBody();
                String bodyStringValue = bodyCreate.asString();
                System.out.println(bodyStringValue);
            }
        }
    }

    public void showApplicationDialog()
    {
        JFrame frame = new JFrame();
        String message = "Application Id";
        loanApplicationId = JOptionPane.showInputDialog(frame, message);
        if (loanApplicationId == null) {
            System.out.println("Unable to continue without loan application id");
        }
    }
}
