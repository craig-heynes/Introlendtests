package introlendhelpertests;

import data.ApiData;
import data.GlobalVariables;
import helperutil.IntroLendHelper;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.testng.annotations.Test;

import javax.swing.*;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class SelectBids {

    private static IntroLendHelper introLendHelper = new IntroLendHelper();

    @Test (dataProviderClass = ApiData.class, dataProvider = "createApplicationId")
    public void f_loadBids(String token)
    {
        if (GlobalVariables.loanApplicationId==null) {
            showApplicationDialog();

            if (GlobalVariables.loanApplicationId != null) {
                RequestSpecification request = RestAssured.given();
                request.header("Authorization", "Bearer " + token);
                Response response = request.get("https://lending-api-dev.avenu.io/api/v1/Mortgage/" + GlobalVariables.loanApplicationId + "/bids");

                boolean loopResponse = true;

                String bidIdPosition;
                String bidId;
                int position = 0;

                while (loopResponse) {
                    bidIdPosition = "bidID[" + position + "]";
                    bidId = response.jsonPath().getString(bidIdPosition);
                    if (bidId != null) {
                        introLendHelper.selectBid(bidId, token, GlobalVariables.loanApplicationId);
                        break;
                    } else {
                        loopResponse = false;
                    }
                }
            }
        }
    }

    public void showApplicationDialog()
    {
        JFrame frame = new JFrame();
        String message = "Application Id";
        GlobalVariables.loanApplicationId = JOptionPane.showInputDialog(frame, message);
        if (GlobalVariables.loanApplicationId == null) {
            System.out.println("Unable to continue without loan application id");
        }
    }
}
