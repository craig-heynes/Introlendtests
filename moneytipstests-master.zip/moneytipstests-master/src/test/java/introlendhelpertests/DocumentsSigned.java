package introlendhelpertests;

import data.ApiData;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.testng.annotations.Test;
import uitests.base.BaseTestBeforeClass;
import uitests.docusign.DocuSignTest;

import javax.swing.*;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class DocumentsSigned extends BaseTestBeforeClass
{
    String loanApplicationId;

    @Test (dataProviderClass = ApiData.class, dataProvider = "createApplicationId")
    public void d_signDocuments(String token) throws Exception
    {
        if (loanApplicationId==null) {
            showApplicationDialog();

            DocuSignTest docuSignTest = new DocuSignTest(getDriver());
            docuSignTest.d_signDocuments(token, loanApplicationId);
        }
    }

    public void showApplicationDialog()
    {
        JFrame frame = new JFrame();
        String message = "Application Id";
        loanApplicationId = JOptionPane.showInputDialog(frame, message);
        if (loanApplicationId == null) {
            System.out.println("Unable to continue without loan application id");
        }
    }
}
