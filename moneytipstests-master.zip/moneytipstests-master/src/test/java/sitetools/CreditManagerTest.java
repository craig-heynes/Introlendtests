package sitetools;

import com.tngtech.java.junit.dataprovider.DataProviderRunner;
import com.tngtech.java.junit.dataprovider.UseDataProvider;
import data.ApiData;
import org.junit.Test;
import org.junit.runner.RunWith;
import pages.HomePage;
import uitests.base.BaseTest;
import uitests.base.CreateEssentialMember;
import util.DatabaseUtil;

@RunWith(DataProviderRunner.class)
public class CreditManagerTest extends BaseTest{

    private static CreateEssentialMember essentialMember;
    private static String emailToLogin;
    private static String passwordToLogin;
    DatabaseUtil databaseUtil = new DatabaseUtil();
    HomePage homePage;

    @Test
    @UseDataProvider(location= ApiData.class, value = "createEssentialMemberForUISignUp")
    public void a_testSignUpEssential(String emailAddress, String password, String firstName, String lastName, String address,
                                          String zipCode, String dateOfBirth,
                                          String phoneNumber, String ssn, Boolean doThreeBTest) throws Exception{

        homePage = new HomePage(driver,"");
        essentialMember = new CreateEssentialMember(driver);

        essentialMember.testCreateEssentialMember(emailAddress, password, firstName, lastName, address, zipCode, dateOfBirth,
                phoneNumber, ssn, doThreeBTest);

        databaseUtil.setMemberMobileNumber(emailAddress);
        databaseUtil.setEmailPhoneVerified(emailAddress);
        homePage.navigateToDashboard();

        databaseUtil.dismissAllBanners(emailAddress);
        databaseUtil.truncateMemberInstruction();

        emailToLogin = emailAddress;
        passwordToLogin = password;
    }

    @Test
    public void b_testCreditManagerDataVerification() throws Exception
    {
        homePage = new HomePage(driver,"");
        homePage.signInMember(emailToLogin, passwordToLogin);
        homePage.navigateToCreditManager();

    }


}

