package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import util.ElementUtil;

public class CreditCardHostedFieldsPage {

    private WebDriver driver;
    private static ElementUtil util = new ElementUtil();

    public CreditCardHostedFieldsPage(WebDriver driver){
        this.driver=driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(id="credit-card-number")
    private WebElement credit_card_num;

    @FindBy(id="cvv")
    private WebElement credit_card_cvv;

    @FindBy(id="expiration")
    private WebElement credit_card_expiry_date;

    @FindBy(id="postal-code")
    private WebElement credit_card_zip;

    @FindBy(xpath = "//p[@class='amount']")
    private WebElement discountedAmountField;

    public void setCreditCardDetails(String cardNumber, String cardCVV, String cardExpiryDate, String cardZipCode) throws Exception{

        Thread.sleep(20000);

        driver.switchTo().frame(0);
        credit_card_num.clear();
        credit_card_num.sendKeys(cardNumber);
        driver.switchTo().defaultContent();

        //switch to cvv iframe and submit text
        driver.switchTo().frame(1);
        credit_card_cvv.clear();
        credit_card_cvv.sendKeys(cardCVV);
        driver.switchTo().defaultContent();

        //switch to expiry date iframe and submit text
        driver.switchTo().frame(2);
        credit_card_expiry_date.clear();
        credit_card_expiry_date.sendKeys(cardExpiryDate);
        driver.switchTo().defaultContent();

        //switch to zipcode iframe and submit text
        driver.switchTo().frame(3);
        credit_card_zip.clear();
        credit_card_zip.sendKeys(cardZipCode);
        driver.switchTo().defaultContent();
    }

    public String getDiscountedAmount()
    {
        return discountedAmountField.getText();
    }
}
