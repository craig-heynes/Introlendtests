package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import util.ElementUtil;

import java.util.List;

public class MortgageApplicationPage {

    private WebDriver driver;
    private static ElementUtil elementUtil = new ElementUtil();

    public MortgageApplicationPage(WebDriver driver){
        this.driver=driver;
        PageFactory.initElements(driver, this);
    }

    //Financial Accounts
    @FindBy(xpath="//p/a[@class='btn btn-secondary' and 1]")
    private WebElement btn_startApplication;

    @FindBy(xpath="//div[1]/a[@class='btn btn-secondary' and 1]")
    private WebElement btn_singleBorrowerApplication;

    @FindBy(xpath="//div[2]/a[@class='btn btn-secondary' and 1]")
    private WebElement btn_coBorrowerApplication;

    @FindBy(xpath="//a[text()='Checking Account']")
    private WebElement btn_checkingAccount;

    @FindBy(xpath="//a[text()='Savings Account']")
    private WebElement btn_savingsAccount;

    @FindBy(xpath="//div[3]/a[1 and @href='javascript:;']")
    private WebElement mutualFunds_button;

    @FindBy(xpath="//a[text()='Retirement Account']")
    private WebElement btn_retirementAccount;

    @FindBy(xpath="//a[text()='Other (Enter Manually)']")
    private WebElement btn_otherAccount;

    @FindBy(xpath="//div/input[1 and @name='financialInstitution']")
    private WebElement field_financialInstitution;

    @FindBy(xpath="//input[@class='currency-field']")
    private WebElement field_cashValue;

    @FindBy(xpath="//form/input[@class='btn btn-primary' and 1]")
    private WebElement btn_saveFinAccount;

    @FindBy(xpath="//div[@class='content-header']/a[1]")
    private WebElement link_addFinAccount;

    @FindBy(xpath="//a[text()='Cancel']")
    private WebElement link_cancel;

    @FindBy(xpath="//label[text()='Other Asset']")
    private WebElement radionBtn_otherAsset;

    @FindBy(xpath="//label[text()='Financial Asset']")
    private WebElement radionBtn_financialAsset;

    @FindBy(xpath="//select[@name='accountType']")
    private WebElement comboBox_accountType;

    @FindBy(xpath="//a[text()='Add another account']")
    private WebElement link_addAnotherFinAccount;

    @FindBy(xpath="//div[text()='Please enter a financial institution']") //error text "PLEASE ENTER A FINANCIAL INSTITUTION"
    private WebElement errorText_financialInstitution;

    @FindBy(xpath="//div[text()='Please select an account type']") //error text "PLEASE SELECT AN ACCOUNT TYPE"
    private WebElement errorText_accountType;

    @FindBy(xpath="//div[text()='Please enter a value']") //error text "PLEASE ENTER A VALUE"
    private WebElement errorText_assetValue;


    //Real Estate
    @FindBy(xpath="//label[@class='own-real-estate']")
    private WebElement radioBtn_ownRealEstate;

    @FindBy(xpath="//a[text()='Add Real Estate']")
    private WebElement btn_addRealEstate;

    @FindBy(xpath="//input[@id='address']")
    private WebElement btn_addRealEstateAddress;

    @FindBy(xpath="//label[text()='This is my current address']")
    private WebElement chkBox_currentAddress;

    @FindBy(xpath="//input[@class='currency-field']")
    private WebElement field_homeValue;

    @FindBy(xpath="//select[@id='property-types']")
    private WebElement comboBox_propertyType;

    @FindBy(id="//select[@id='status-types']")
    private WebElement comboBox_propertyStatus;

    @FindBy(xpath="//input[@id='mortgage-balance']")
    private WebElement field_firstMortgageValue;

    @FindBy(xpath="//a[text()='Add additional mortgage']")
    private WebElement link_addAnotherMortgage;

    @FindBy(xpath="//i[@class='ico-ma-trash']")
    private WebElement link_removeSecondMortgage;

    @FindBy(xpath="//input[@id='secondary-mortgage-balance']")
    private WebElement field_secondMortgageValue;

    @FindBy(xpath="//form/input[@class='btn btn-primary' and 1]")
    private WebElement btn_saveRealEstate;

    @FindBy(xpath="//div[text()='Please enter a valid address']") //error text "PLEASE ENTER A VALID ADDRESS"
    private WebElement errorText_propertyAddress;

    @FindBy(xpath="//div[text()='Please enter a home value']") //error text "PLEASE ENTER A HOME VALUE"
    private WebElement errorText_homeValue;

    @FindBy(xpath="//div[@class='total-assets-value']/p[1]")
    private WebElement label_totalAssets;

    @FindBy(xpath="//div[@class='content-footer']/a[@class='btn btn-primary' and 1]")
    private WebElement btn_NextStepOne;

    //Active Income

    @FindBy(xpath="//a[text()='Employment']")
    private WebElement btn_employment;

    @FindBy(xpath="//a[text()='Independent Contractor']")
    private WebElement btn_independentContractor;

    @FindBy(xpath="//a[text()='Self Employed']")
    private WebElement btn_selfEmployed;

    @FindBy(xpath="//select[@name='employmentType']")
    private WebElement comboBox_employmentType;

    @FindBy(xpath="//input[@name='companyName']")
    private WebElement field_companyName;

    @FindBy(id="percentOwnership")
    private WebElement field_percentOwnership;

    @FindBy(xpath="//input[@name='position']")
    private WebElement field_employmentPosition;

    @FindBy(xpath="//input[@class='address pac-target-input']")
    private WebElement field_employmentAddress;

    @FindBy(xpath="//*[1]/*[1 and @name='phoneNumber']")
    private WebElement field_employmentPhoneNumber;

    @FindBy(xpath="//*[@name='startDateMonth']")
    private WebElement comboBox_startMonth;

    @FindBy(xpath="//*[@name='startDateYear']")
    private WebElement comboBox_startYear;

    @FindBy(xpath="//*[@name='endDateMonth']")
    private WebElement comboBox_endMonth;

    @FindBy(xpath="//*[@name='endDateYear']")
    private WebElement comboBox_endYear;

    @FindBy(xpath="//*[text()='Current Employment']")
    private WebElement chkBox_currentEmployment;

    @FindBy(xpath="//*[@name='yearsInIndustry']")
    private WebElement field_yearsInIndustry;

    @FindBy(xpath="//*[@name='annualBaseIncome']")
    private WebElement field_annualBaseIncome;

    @FindBy(xpath="//form/input[@class='btn btn-primary' and 1]")
    private WebElement btn_saveActiveEmployment;

    @FindBy(xpath="//*[text()='Please enter a company name']") //error text "PLEASE ENTER A COMPANY NAME"
    private WebElement errorText_companyName;

    @FindBy(xpath="//*[text()='Please enter a position']") //error text "PLEASE ENTER A POSITION"
    private WebElement errorText_companyPosition;

    @FindBy(xpath="//*[text()='Please enter an address']") //error text "PLEASE ENTER AN ADDRESS"
    private WebElement errorText_companyAddress;

    @FindBy(xpath="//*[text()='Please enter a valid phone number']") //error text "PLEASE ENTER A VALID PHONE NUMBER"
    private WebElement errorText_companyPhoneNumber;

    @FindBy(xpath="//*[text()='Please select a valid start date']") //error text "PLEASE SELECT A VALID START DATE"
    private WebElement errorText_startDate;

    @FindBy(xpath="//*[text()='Please select a valid end date']") //error text "PLEASE SELECT A VALID END DATE"
    private WebElement errorText_endDate;

    @FindBy(xpath="//*[text()='Please enter years in industry']") //error text "PLEASE ENTER YEARS IN INDUSTRY"
    private WebElement errorText_yearsInIndustry;

    @FindBy(xpath="//*[text()='Please enter annual base income']") //error text "PLEASE ENTER ANNUAL BASE INCOME"
    private WebElement errorText_annualBaseIncome;

    @FindBy(xpath="//*[1]/div[2]/div[1]/*[2]/i[1]")
    private WebElement btn_editEmployment;

    @FindBy(xpath="//*[3]/div[1]/div[1]/div[1]/div[2]/p[1]")
    private WebElement label_totalMonthlyIncome;

    @FindBy(xpath="//*[2]/div[1]/div[1]/a[1]")
    private WebElement link_addEmployment;

    @FindBy(xpath="//*[text()='Remove income']")
    private WebElement link_removeEmployment;


    //Passive Income

    @FindBy(xpath="//a[text()='Social Security']")
    private WebElement btn_socialSecurity;

    @FindBy(xpath="//a[text()='Pension']")
    private WebElement btn_pension;

    @FindBy(xpath="//a[text()='Military Pay']")
    private WebElement btn_militaryPay;

    @FindBy(xpath="//a[text()='Other']")
    private WebElement btn_other;

    @FindBy(xpath="//*[@name='monthlyIncome']")
    private WebElement field_monthlyIncome;

    @FindBy(xpath="//div[2]/div[1]/div[2]/a[1]")
    private WebElement btn_savePassiveIncome;

    @FindBy(xpath="//*[text()='Enter a monthly income amount']") //error text "ENTER A MONTHLY INCOME AMOUNT"
    private WebElement errorText_passiveMonthlyIncome;

    @FindBy(xpath="//*[2]/div[2]/div[1]/div[2]/i[1]")
    private WebElement btn_editPassiveIncome;

    @FindBy(xpath="//*[2]/div[2]/div[1]/a[1]")
    private WebElement link_addPassiveIncome;

    @FindBy(xpath="//*[text()='Remove income']")
    private WebElement link_removePassiveIncome;

    @FindBy(xpath="//*[1]/select[1]")
    private WebElement comboBox_selectPassiveType;

    @FindBy(xpath="//*[text()='Next']")
    private WebElement btn_NextStepTwo;

    //Declarations

    @FindBy(xpath="//input[@id='address']")
    private WebElement field_currentAddress;

    @FindBy(xpath="//input[@id='yearsCurrentAddress']")
    private WebElement field_yearsAtAddress;

    @FindBy(xpath="//input[@class='currency-field']")
    private WebElement field_monthlyCost;

    @FindBy(xpath="//div[@class='check-box']/label[1]")
    private WebElement chkBox_sameAsCurrentAddress;

    @FindBy(xpath="//input[@id='yearsMailingAddress']")
    private WebElement field_yearsAtMailingAddress;

    @FindBy(xpath="//select[@name='creditType']")
    private WebElement comboBox_creditType;

    @FindBy(xpath="//select[@name='citizenship']")
    private WebElement comboBox_citizenship;

    @FindBy(xpath="//select[@name='gender']")
    private WebElement comboBox_gender;

    @FindBy(xpath="//select[@name='maritalStatus']")
    private WebElement comboBox_maritalStatus;

    @FindBy(xpath="//select[@name='ethnicity']")
    private WebElement comboBox_ethnicity;

    @FindBy(xpath="//select[@name='numberOfDependants']")
    private WebElement comboBox_numberOfDependants;

    @FindBy(xpath="//div[@class='content-footer']/input[@class='btn btn-primary' and 1]")
    private WebElement btn_reviewApplciation;

    @FindBy(xpath="//select[@id='get-a-home-select']")
    private WebElement comboBox_homeSelectionProcess;

    @FindBy(id="addresss")
    private WebElement field_purchaseHomeAddress;

    @FindBy(xpath="//input[@id='purchasePrice']")
    private WebElement field_homePurchasePrice;

    @FindBy(xpath="//input[@id='downPayment']")
    private WebElement field_homeDownPayment;

    @FindBy(xpath="//div[@class='save']/a[1 and @class='btn btn-primary']")
    private WebElement btn_saveNewHome;

    @FindBy(xpath="//p/a[@class='btn btn-primary' and 1]")
    private WebElement btn_getQuotes;

    @FindBy(xpath="//a[text()='Continue Now]")
    private WebElement btn_continueMortgageApplication;

    public void clickStartApplication() throws Exception
    {
        btn_startApplication.click();
        Thread.sleep(3000);
    }

    public void clickSingleApplication() throws Exception
    {
        Thread.sleep(2000);
        driver.findElement(By.xpath("//a[@class='btn btn-secondary btn-member']")).click();
    }

    public void clickApplicationLoanTerm(int loanTerm) throws Exception
    {
        Thread.sleep(2000);

        switch (loanTerm)
        {
            case 30:
                driver.findElement(By.xpath("//a[@class='btn btn-secondary btn-30']")).click();
                break;
            case 20:
                driver.findElement(By.xpath("//a[@class='btn btn-secondary btn-20']")).click();
                break;
            case 15:
                driver.findElement(By.xpath("//a[@class='btn btn-secondary btn-15']")).click();
                break;
        }
    }

    public void clickCoBorrowerApplication() throws Exception
    {
        Thread.sleep(2000);
        driver.findElement(By.xpath("//a[@class='btn btn-secondary btn-co-borrower']")).click();
    }

    public void addFinancialAccount(String financialInstitution, String cashValue) throws Exception
    {
        Thread.sleep(2000);
        btn_checkingAccount.click();
        field_financialInstitution.sendKeys(financialInstitution);
        field_cashValue.sendKeys(cashValue);
        btn_saveFinAccount.click();
    }

    public void clickStepOneNext() throws Exception
    {
        Thread.sleep(2000);
        btn_NextStepOne.click();
    }

//    public void addEmployment(String companyName, String percentOwnership, String companyPosition, String companyAddress, String companyPhoneNumber,
//                              String startMonth, String startYear, String endMonth, String endYear, String yearsInIndustry, String annualBaseIncome) throws Exception
//    {
//        Select employmentType = new Select(comboBox_employmentType);
//
//        if (employmentType.getFirstSelectedOption().getText().equals("Select Type"))
//        {
//            employmentType.selectByVisibleText("Employment");
//        }
//
//        field_companyName.sendKeys(companyName);
//
//        if (elementUtil.elementExists(field_percentOwnership))
//        {
//            field_percentOwnership.sendKeys(percentOwnership);
//        }
//
//        field_employmentPosition.sendKeys(companyPosition);
//        Thread.sleep(5000);
//        completeGoogleAddress(field_employmentAddress, companyAddress);
//
//        field_employmentPhoneNumber.sendKeys(companyPhoneNumber);
//        comboBox_startMonth.sendKeys(startMonth);
//        comboBox_startYear.sendKeys(startYear);
//
//        if (endMonth.equals(""))
//        {
//            chkBox_currentEmployment.click();
//        }
//        else {
//            comboBox_endMonth.sendKeys(endMonth);
//            comboBox_endYear.sendKeys(endYear);
//        }
//
//        field_yearsInIndustry.sendKeys(yearsInIndustry);
//        field_annualBaseIncome.sendKeys(annualBaseIncome);
//
//        btn_saveActiveEmployment.click();
//    }

    public void addEmployment(String companyName, String percentOwnership, String companyPosition, String companyAddress, String companyPhoneNumber,
                              String startMonth, String startYear, String endMonth, String endYear, String yearsInIndustry, String annualBaseIncome) throws Exception
    {
        field_companyName.sendKeys(companyName);
        field_employmentPosition.sendKeys(companyPosition);

        completeGoogleAddress(field_employmentAddress, companyAddress);

        field_employmentPhoneNumber.sendKeys(companyPhoneNumber);
        comboBox_startMonth.sendKeys(startMonth);
        comboBox_startYear.sendKeys(startYear);

        if (endMonth.equals(""))
        {
            chkBox_currentEmployment.click();
        }
        else {
            comboBox_endMonth.sendKeys(endMonth);
            comboBox_endYear.sendKeys(endYear);
        }

        field_yearsInIndustry.sendKeys(yearsInIndustry);
        field_annualBaseIncome.sendKeys(annualBaseIncome);

        btn_saveActiveEmployment.click();
    }

    public void clickAddEmploymentLink() throws Exception
    {
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[@class='content-header']/a[1]")).click();
    }

    public void clickSelfEmployed() throws Exception
    {
        Thread.sleep(1000);
        btn_selfEmployed.click();
    }

    public void clickEmployed() throws Exception
    {
        Thread.sleep(1000);
        btn_employment.click();
    }

    public void addCoBorrower(String firstName, String middleName, String lastName, String suffix,
                              String emailAddress, String dateOfBirth, String phoneNumber, String ssn9) throws Exception
    {
        Thread.sleep(1000);
        driver.findElement(By.id("firstName")).sendKeys(firstName);
        driver.findElement(By.id("middleName")).sendKeys(middleName);
        driver.findElement(By.id("lastName")).sendKeys(lastName);
        driver.findElement(By.id("email")).sendKeys(emailAddress);
        driver.findElement(By.id("dateOfBirth")).sendKeys(dateOfBirth);
        driver.findElement(By.id("phoneNumber")).sendKeys(phoneNumber);
        driver.findElement(By.id("ssn9")).sendKeys(ssn9);

        Thread.sleep(1000);
        driver.findElement(By.xpath("//div[@class='continue']")).click();
    }

    public void completeGoogleAddress(WebElement addressElement, String address) throws Exception
    {
        Thread.sleep(5000);
        Boolean isAddressComplete = false;

        if (addressElement.getAttribute("value").length()>0)
        {
            isAddressComplete = true;
        }
        else {
            addressElement.clear();
        }

        while (!isAddressComplete)
        {
            addressElement.sendKeys(address);
            List<WebElement> options = new WebDriverWait(driver, 10).until(ExpectedConditions.numberOfElementsToBeMoreThan(By.xpath("//div[3]/span[@class='pac-item-query' and 2]"), 0));
            int index = (int) (Math.random() * options.size());
            if (driver.findElement(By.xpath("//div[3]/span[@class='pac-item-query' and 2]")).isDisplayed())
            {
                options.get(index).click();
            }

            System.out.println("Current Address in field: 1" + addressElement.getAttribute("value"));

//            if (addressElement.getText().equals(address)){
//                addressElement.clear();
//            }
//            else {
//                isAddressComplete = true;
//            }

            if (addressElement.getAttribute("value").length()>0){
                isAddressComplete = true;
            }
            else {
                addressElement.clear();
                new Actions(driver).sendKeys(Keys.TAB).click();
            }
        }
    }

    public void clickStepTwoNext() throws Exception
    {
        Thread.sleep(10000);
        btn_NextStepTwo.click();
    }

    public void addDeclarations(String currentAddress, String yearsAtAddress, String monthlyCost, String yearsAtMailingAddress) throws Exception
    {
        elementUtil.waitForElement(driver, field_currentAddress);
        completeGoogleAddress(field_currentAddress, currentAddress);

        field_yearsAtAddress.sendKeys(yearsAtAddress);
        field_monthlyCost.sendKeys(monthlyCost);

        Thread.sleep(1000);
        chkBox_sameAsCurrentAddress.click();
        field_yearsAtMailingAddress.sendKeys(yearsAtMailingAddress);

        Select creditType = new Select(comboBox_creditType);
        creditType.selectByVisibleText("Individual credit");

        Select citizenship = new Select(comboBox_citizenship);
        citizenship.selectByVisibleText("U.S. Citizen");

        Select gender = new Select(comboBox_gender);
        gender.selectByVisibleText("Male");

        Select maritalStatus = new Select(comboBox_maritalStatus);
        maritalStatus.selectByVisibleText("Married");

        Select ethnicity = new Select(comboBox_ethnicity);
        ethnicity.selectByVisibleText("American Indian or Alaska Native");

        Select numberOfDependants = new Select(comboBox_numberOfDependants);
        numberOfDependants.selectByVisibleText("0");
    }

    public void clickReviewApplication() throws Exception
    {
        btn_reviewApplciation.click();
        Thread.sleep(10000);
    }

    public void addNewPurchaseHome(String address, String purchasePrice, String downPayment) throws Exception
    {
        completeGoogleAddress(driver.findElement(By.id("address")), address);

        while(!driver.findElement(By.id("purchasePrice")).isEnabled()){
            Thread.sleep(1000);
        }

        if(driver.findElement(By.id("purchasePrice")).getText().isEmpty()){
            driver.findElement(By.id("purchasePrice")).sendKeys(purchasePrice);
        }

        driver.findElement(By.id("downPayment")).sendKeys(downPayment);
    }

    public void addCountyState(String purchasePrice, String downPayment) throws Exception
    {
//        elementUtil.waitForElementToBeDisplayed(driver.findElement(By.xpath("//div[@class='select-mortgage-type-quotes']/h2[1]")));
        Thread.sleep(3000);
        Select state = new Select(driver.findElement(By.xpath("//select[@class='region-select form-control']")));
        state.selectByVisibleText("Alabama");

        Select county = new Select(driver.findElement(By.xpath("//select[@class='county-select form-control']")));
        county.selectByVisibleText("Autauga");

        field_homePurchasePrice.sendKeys(purchasePrice);
        field_homeDownPayment.sendKeys(downPayment);

        driver.findElement(By.xpath("//div[@class='save']")).click();
        Thread.sleep(15000);
    }

    public void clickCloseOnFailedPreApprovalModal()
    {
        driver.findElement(By.xpath("//div[@class='non-approval']/a[@class='btn btn-primary' and 1]")).click();
    }

    public void clickClosePreApprovalModal()
    {
        driver.findElement(By.xpath("//div[@id='modal-pre-approval']/div[@class='modal-dialog' and 1]/div[@class='modal-content' and 1]/a[@class='close' and 1]")).click();
    }

    public String getFailedPreApprovalText()
    {
        return driver.findElement(By.xpath("//h2[text()='Your Application is being reviewed']")).getText();
    }

    public void clickSavePurchaseHome() throws Exception
    {
        btn_saveNewHome.click();
        Thread.sleep(3500);
    }

    public void offerAcceptedHomeSelection() throws Exception
    {
        Select ethnicity = new Select(comboBox_homeSelectionProcess);
        ethnicity.selectByVisibleText("Offer accepted and ready to close");
        Thread.sleep(2000);
    }

    public String getSelectedHomeSummaryText(){
        return driver.findElement(By.xpath("//div[@class='home-address']/p[1]")).getText();
    }

    public void clickGetQuotes() throws Exception
    {
        btn_getQuotes.click();
//        driver.findElement(By.xpath("//div[@class='summary-footer']/a[@class='btn btn-primary' and 1]")).click();
        elementUtil.waitForElementToBeDisplayed(driver.findElement(By.xpath("//div[@class='modal-header']/h2[1]")));
    }

    public void clickGetQuotesForPreApprovedIntroLendUser() throws Exception{
        elementUtil.waitForElementToBeDisplayed(driver.findElement(By.xpath("//div[@class='summary-footer']/a[@class='btn btn-primary' and 1]")));
        driver.findElement(By.xpath("//div[@class='summary-footer']/a[@class='btn btn-primary' and 1]")).click();
//        driver.findElement(By.xpath("//div[@class='save']")).click();
    }

    public String getGetQuotesButtonText() throws Exception
    {
        return btn_getQuotes.getText();
    }

    public void clickPreApproval() throws Exception
    {
        btn_getQuotes.click();
        Thread.sleep(5000);
    }

    public void addRefiHome(String homeAddress) throws Exception
    {
        WebElement homeValueField = driver.findElement(By.id("homeValue"));
        Thread.sleep(1500);
        WebElement addressField = driver.findElement(By.id("address"));
        WebElement mortgageTypeComboBox = driver.findElement(By.xpath("//div[@class='col-md-2 form-group no-left-padding left-padding-xs left-padding-sm']/div[@class='input-container' and 1]/select[@class='mortgage-select form-control' and 1]"));
        completeGoogleAddress(addressField, homeAddress);
        Thread.sleep(2500);
        elementUtil.waitForElement(driver, homeValueField);
        driver.findElement(By.id("homeValue")).clear();
        driver.findElement(By.id("homeValue")).sendKeys("800000");
        driver.findElement(By.id("mortgage-balance")).sendKeys("400000");
        Select mortgageType = new Select(mortgageTypeComboBox);
        mortgageType.selectByVisibleText("30 YR Fixed");
        driver.findElement(By.id("interest-rate")).sendKeys("2");
        driver.findElement(By.id("monthlyPayment")).sendKeys("1234");
        Thread.sleep(2000);
        driver.findElement(By.xpath("//div[@class='save']")).click();
        Thread.sleep(6000);
    }

    public void selectQuote() throws Exception
    {
        Thread.sleep(10000);
        elementUtil.waitForElementToBeDisplayed(driver.findElement(By.xpath("//div[1]/div[@class='row' and 1]/div[@class='col-sm-12 col-md-4' and 3]/a[@class='btn btn-secondary' and 1]")));
        driver.findElement(By.xpath("//div[1]/div[@class='row' and 1]/div[@class='col-sm-12 col-md-4' and 3]/a[@class='btn btn-secondary' and 1]")).click();
        Thread.sleep(15000);
    }

    public void clickContinueMortgageApplication() throws Exception
    {
        Thread.sleep(5000);
        driver.switchTo().activeElement();
        driver.findElement(By.xpath("//div[@class='modal-body']/a[@class='btn btn-primary' and 2]")).click();
        Thread.sleep(5000);
    }

    public Boolean getSelectQuoteButtonsState()
    {
        Boolean state = false;
        state = driver.findElement(By.xpath("//*[1]/div[1 and @class='loan-officer-quote']/div[3 and @class='quote-detail-container']/div[1 and @class='quote-details']/a[1]")).isEnabled();
        return state;
    }

    public String getLoanOfficerText() throws Exception
    {
        Thread.sleep(15000);
        String getText = driver.findElement(By.xpath("//div[1]/div[@class='loan-officer-quote' and 1]/div[@class='quote-detail-container quote-not-ready' and 3]/p[@class='quote-not-ready' and 1]")).getText();
        return getText;
    }

    public String getBidMonthlyPaymentOfficer1()
    {
        return driver.findElement(By.xpath("//*[1]/div[1 and @class='loan-officer-quote']/div[3 and @class='quote-detail-container']/div[1 and @class='quote-details']/div[1]/div[1]")).getText();
    }

    public String getBidInterestRateOfficer1()
    {
        return driver.findElement(By.xpath("//*[1]/div[1 and @class='loan-officer-quote']/div[3 and @class='quote-detail-container']/div[1 and @class='quote-details']/div[2]/div[1]")).getText();
    }

    public String getBidTotalFeesOfficer1()
    {
        return driver.findElement(By.xpath("//*[1]/div[1 and @class='loan-officer-quote']/div[3 and @class='quote-detail-container']/div[1 and @class='quote-details']/div[2]/div[1]")).getText();
    }

    public String getBidMonthlyPaymentOfficer2()
    {
        return driver.findElement(By.xpath("//*[2]/div[1 and @class='loan-officer-quote']/div[3 and @class='quote-detail-container']/div[1 and @class='quote-details']/div[1]/div[1]")).getText();
    }

    public String getBidInterestRateOfficer2()
    {
        return driver.findElement(By.xpath("//*[2]/div[1 and @class='loan-officer-quote']/div[3 and @class='quote-detail-container']/div[1 and @class='quote-details']/div[2]/div[1]")).getText();
    }

    public String getBidTotalFeesOfficer2()
    {
        return driver.findElement(By.xpath("//*[2]/div[1 and @class='loan-officer-quote']/div[3 and @class='quote-detail-container']/div[1 and @class='quote-details']/div[3]/div[1]")).getText();
    }

    public String getTwoYearEmploymentErrorMessage() throws Exception
    {
        Thread.sleep(1000);
        return driver.findElement(By.xpath("//*[text()='Enter your last two years of active employment.']")).getText();
    }
}
