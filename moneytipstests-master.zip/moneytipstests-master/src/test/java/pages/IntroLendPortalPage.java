package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import util.ElementUtil;

public class IntroLendPortalPage {

    private WebDriver driver;
    private static ElementUtil elementUtil = new ElementUtil();
    private static String PAGEURL = "https://portal-dev.introlend.com/";

    @FindBy (xpath = "//input[@name='email']")
    private WebElement emailField;

    @FindBy(xpath = "//input[@name='password']")
    private WebElement passwordField;

    @FindBy(xpath = "//*[@name='address1']")
    private WebElement addressField;

    @FindBy(xpath = "//div[11]/div[@class='form-group has-danger' and 1]/span[1]/div[@class='select dropdown' and 1]/span[@class='form-control text-truncate' and 1]")
    private WebElement currentAddressUserDropdown;


    public IntroLendPortalPage(WebDriver driver){
        this.driver=driver;
        driver.get(PAGEURL);
        PageFactory.initElements(driver, this);
    }

    public void clickAddApplication() throws Exception
    {
        driver.findElement(By.xpath("//*[@class='bg-blue btn btn--action']")).click();
        Thread.sleep(2000);
    }

    public void loginIntroLendPortal() throws Exception
    {
        Thread.sleep(5000);
        emailField.sendKeys("jason+admin@cragun.net");
        passwordField.sendKeys("Password1#");
        driver.findElement(By.xpath("//span[@class='btn btn--icon login__block__btn waves-effect']")).click();
        Thread.sleep(3000);
    }

    public void clickLeadPointGroup() throws Exception
    {
        driver.findElement(By.xpath("//div[4]/span[@class='listview__content' and 1]")).click();
        Thread.sleep(3000);
    }

    public void addInitialApplicant(String firstName, String lastName, String emailAddress, String address, String phoneNumber) throws Exception
    {
        driver.findElement(By.xpath("//*[@name='firstName']")).sendKeys(firstName);
        driver.findElement(By.xpath("//*[@name='lastName']")).sendKeys(lastName);
        driver.findElement(By.xpath("//*[@name='emailAddress']")).sendKeys(emailAddress);
        new Actions(driver).sendKeys(Keys.TAB).perform();
        new Actions(driver).sendKeys(phoneNumber).perform();
        addressField.sendKeys(address);
        Thread.sleep(2000);
        driver.findElement(By.xpath("//*[text()='200 Front Street Northeast, Boardman, OR, USA']")).click();
        Thread.sleep(4000);
        driver.findElement(By.xpath("//button[@class='d-flex  justify-content-start btn btn-primary']")).click();
        Thread.sleep(5000);
    }

    public void clickApplicantFolder(){
        driver.findElement(By.xpath("//h5[@class='text-uppercase mb-2']")).click();
    }

    public void addCoBorrowerApplication(String firstName, String lastName, String emailAddress,
                                         String birthYear, String phoneNumber, String ssn9) throws Exception
    {
        clickApplicantFolder();
        driver.findElement(By.xpath("//*[text()='+ Add Co-Borrower']")).click();
        driver.findElement(By.xpath("//*[@class='modal-body']/*[@name='Add Applicant' and @class='row']/*[@class='col-6 col-md-6  col-lg-6']/*[@class='form-group']/*[@name='firstName' and @class='form-control']"))
                .sendKeys(firstName);
        driver.findElement(By.xpath("//*[@class='modal-body']/*[@name='Add Applicant' and @class='row']/*[@class='col-6 col-lg-6']/*[@class='form-group']/*[@name='lastName' and @class='form-control']"))
                .sendKeys(lastName);
        driver.findElement(By.xpath("//*[@class='modal-body']/*[@name='Add Applicant' and @class='row']/*[@class='col-12 col-md-6 col-lg-6']/*[@class='form-group']/*[@name='emailAddress' and @class='form-control']"))
                .sendKeys(emailAddress);

        Thread.sleep(3000);
        driver.findElement(By.xpath("//*[1]/*[6 and @class='col-12 col-md-6 col-lg-6']/*[1 and @class='form-group']/*[@style='display: flex;' and 1]/*[1 and @class='zmdi zmdi-eye zmdi-hc-2x pl-4']"))
                .click();

        driver.findElement(By.xpath("//*[@name='dateOfBirth']")).sendKeys(birthYear);
        driver.findElement(By.xpath("//*[@name='dateOfBirth']")).sendKeys(Keys.TAB);
        driver.findElement(By.xpath("//*[@name='dateOfBirth']")).sendKeys("0101");

        Thread.sleep(3000);

        driver.findElement(By.xpath("//*[@class='d-flex  justify-content-start btn btn-primary']")).click();

        Thread.sleep(3000);

        driver.findElement(By.xpath("//div[5]/div[@class='form-group has-danger' and 1]/input[@class='form-control form-control-danger' and 1]"))
                .sendKeys(phoneNumber);
        new Actions(driver).sendKeys(Keys.TAB).perform();
        new Actions(driver).sendKeys(Keys.TAB).perform();
        new Actions(driver).sendKeys(phoneNumber).perform();

        Thread.sleep(3000);

        driver.findElement(By.xpath("//div[7]/div[@class='form-group has-danger' and 1]/div[1]/input[@class='form-control' and 1]"))
                .sendKeys(ssn9);

        Thread.sleep(2000);

        driver.findElement(By.xpath("//*[8]/div[@class='form-group has-danger' and 1]/span[1]/div[@class='select dropdown' and 1]/*[@class='form-control text-truncate' and 1]")).click();
        driver.findElement(By.xpath("//*[@class='dropdown-menu show']/*[@value='USCitizen' and @type='button' and 3 and @class='dropdown-item']"))
                .click();

        driver.findElement(By.xpath("//*[9]/div[@class='form-group has-danger' and 1]/span[1]/div[@class='select dropdown' and 1]/*[@class='form-control text-truncate' and 1]")).click();
        driver.findElement(By.xpath("//*[@class='dropdown-menu show']/*[@value='Married' and @type='button' and 1 and @class='dropdown-item']")).click();

        driver.findElement(By.xpath("//*[10]/div[@class='form-group has-danger' and 1]/span[1]/div[@class='select dropdown' and 1]/*[@class='form-control text-truncate' and 1]")).click();
        driver.findElement(By.xpath("//*[@class='dropdown-menu show']/*[@value='None' and @type='button' and 2 and @class='dropdown-item']")).click();

        driver.findElement(By.xpath("//*[@class='d-flex  justify-content-start btn btn-primary']")).click();

        Thread.sleep(3000);
    }

    public String getApplicationId() throws Exception{
        Thread.sleep(5000);
        String currentUrl = driver.getCurrentUrl();
        if (currentUrl.length()>=86)
        {
            return currentUrl.substring(50, 86);
        }
        else{return "unable to get loanApplicationId";}
    }

    public void updateMainApplication(String ssn9, String birthYear) throws Exception
    {
        clickApplicantFolder();
        driver.findElement(By.xpath("//span[1]/div[@class='card-block' and 1]/form[@class='row' and 1]/div[@class='col-12 col-md-6 col-lg-6' and 7]/div[@class='form-group' and 1]/div[1]/i[@class='zmdi zmdi-eye zmdi-hc-2x' and 1]")).click();

        driver.findElement(By.xpath("//span[1]/div[@class='card-block' and 1]/form[@class='row' and 1]/div[6]/div[@class='form-group' and 1]/div[1]/i[@class='zmdi zmdi-eye zmdi-hc-2x pl-4' and 1]")).click();
        driver.findElement(By.xpath("//input[@class='form-control' and @name='dateOfBirth']")).
                sendKeys(birthYear);

        // tab to ssn field
        new Actions(driver).sendKeys(Keys.TAB).perform();
        new Actions(driver).sendKeys(Keys.TAB).perform();
        new Actions(driver).sendKeys(Keys.TAB).perform();
        new Actions(driver).sendKeys(ssn9).perform();

        driver.findElement(By.xpath("//button[text()='Save Changes']")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//div[8]/div[@class='form-group has-danger' and 1]/span[1]/div[@class='select dropdown' and 1]/span[@class='form-control text-truncate' and 1]"))
                .click();
        driver.findElement(By.xpath("//div[@class='dropdown-menu show']/button[@class='dropdown-item' and 3 and @value='USCitizen']"))
                .click();

        driver.findElement(By.xpath("//div[9]/div[@class='form-group has-danger' and 1]/span[1]/div[@class='select dropdown' and 1]/span[@class='form-control text-truncate' and 1]"))
                .click();
        driver.findElement(By.xpath("//div[@class='dropdown-menu show']/button[@class='dropdown-item' and 1 and @value='Married']"))
                .click();

        driver.findElement(By.xpath("//div[10]/div[@class='form-group has-danger' and 1]/span[1]/div[@class='select dropdown' and 1]/span[@class='form-control text-truncate' and 1]"))
                .click();
        driver.findElement(By.xpath("//div[@class='dropdown-menu show']/button[@class='dropdown-item' and 2 and @value='None']"))
                .click();

        Thread.sleep(1500);
        clickSaveChanges();
        Thread.sleep(6000);
    }

    public void clickSaveChanges(){
        driver.findElement(By.xpath("//button[text()='Save Changes']")).click();
    }

    public void updateMainApplicantForPreApproval(String yearsAtAddress, String employerName, String employmentStartYear,
                                                  String employmentPosition, String loanAmount, String downPaymentPercentage, String loanPurpose) throws Exception
    {
        clickSubmitApplication();

        Thread.sleep(2000);

        driver.findElement(By.xpath("//input[@name='YearsAtCurrentAddress']")).sendKeys(yearsAtAddress);
        driver.findElement(By.xpath("//div[@class='col-12 col-md-4']/div[@class='form-group has-danger' and 1]/span[1]/div[@class='select dropdown' and 1]/span[@class='form-control text-truncate' and 1 and @aria-haspopup='true']")).click();
        driver.findElement(By.xpath("//button[text()='Own']")).click();

        //employment
        driver.findElement(By.xpath("//div[3]/div[@class='form-group has-danger' and 1]/input[@class='form-control form-control-danger' and 1]"))
                .sendKeys(employerName);
        new Actions(driver).sendKeys(Keys.TAB).perform();
        new Actions(driver).sendKeys(Keys.TAB).perform();
        new Actions(driver).sendKeys("5179879878").perform();

        driver.findElement(By.xpath("//div[6]/div[@class='form-group has-danger' and 1]/input[@class='form-control form-control-danger' and 1]"))
                .sendKeys(employmentStartYear);
        driver.findElement(By.xpath("//div[6]/div[@class='form-group has-danger' and 1]/input[@class='form-control form-control-danger' and 1]"))
                .sendKeys(Keys.TAB);
        driver.findElement(By.xpath("//div[6]/div[@class='form-group has-danger' and 1]/input[@class='form-control form-control-danger' and 1]"))
                .sendKeys("0101");
        driver.findElement(By.xpath("//input[@class='form-control form-control-danger']"))
                .sendKeys(employmentPosition);

        Thread.sleep(2000);

        driver.findElement(By.xpath("//input[@name='PositionTitle']")).sendKeys(Keys.TAB);
        new Actions(driver).sendKeys("12000").perform();

        Thread.sleep(2000);

        new Actions(driver).sendKeys(Keys.TAB).perform();
        new Actions(driver).sendKeys(Keys.TAB).perform();
        new Actions(driver).sendKeys(Keys.TAB).perform();
        new Actions(driver).sendKeys(Keys.TAB).perform();
        new Actions(driver).sendKeys(Keys.TAB).perform();
        new Actions(driver).sendKeys(Keys.TAB).perform();
        new Actions(driver).sendKeys(Keys.SPACE).perform();

        Thread.sleep(2000);

        driver.findElement(By.xpath("//div[10]/div[2]/div[1]/div[1]/form[@name='Generated' and 1]/div[2]/div[1]/span[1]/div[1]/*[1]"))
                .click();
        driver.findElement(By.xpath("//*[text()='Single Family Residence']"))
                .click();
        driver.findElement(By.xpath("//*[@name='Generated']/div[8]/div[1]/span[1]/div[1]/*[1]"))
                .click();
//        driver.findElement(By.xpath("//*[text()='(FL) Alachua']"))
//                .click();

        driver.findElement(By.xpath("//div[11]/div[2]/div[1]/div[1]/form[@name='Generated' and 1]/div[2]/div[1]/input[@type='text' and 1]"))
                .sendKeys(loanAmount);
        driver.findElement(By.xpath("//div[11]/div[2]/div[1]/div[1]/form[@name='Generated' and 1]/div[4]/div[1]/span[1]/div[1]/*[1]"))
                .click();
        driver.findElement(By.xpath("//*[text()='" + loanPurpose + "']"))
                .click();
        driver.findElement(By.xpath("//div[11]/div[2]/div[1]/div[1]/form[@name='Generated' and 1]/div[5]/div[1]/span[1]/div[1]/*[1]"))
                .click();
        driver.findElement(By.xpath("//*[text()='Primary Home']"))
                .click();

//        driver.findElement(By.xpath("//div[12]/div[2]/div[1]/div[1]/form[@name='Generated' and 1]/*[2]/*[1]/input[@type='text' and 1]"))
//                .sendKeys(downPaymentPercentage);
//
//        driver.findElement(By.xpath("//div[12]/div[2]/div[1]/div[1]/form[@name='Generated' and 1]/div[4]/div[1]/span[1]/div[1]/*[1]"))
//                .click();
//        driver.findElement(By.xpath("//*[text()='At Least 20% Down']"))
//                .click();
//        driver.findElement(By.xpath("//div[12]/div[2]/div[1]/div[1]/form[@name='Generated' and 1]/div[5]/div[1]/span[1]/div[1]/*[1]"))
//                .click();
//        driver.findElement(By.xpath("//*[text()='Low Costs, High Rate']"))
//                .click();
        clickSaveChanges();
        Thread.sleep(3000);
    }

    public void updateApplicantForAllApplicants(String yearsAtAddress, String employerName, String employmentStartYear,
                                                  String employmentPosition, String loanAmount, String downPaymentPercentage, String coBorrowerEmailAddress, String coBorrowerCellPhone) throws Exception
    {
        clickSubmitApplication();

        Thread.sleep(2000);

        //current address
        driver.findElement(By.xpath("//input[@name='YearsAtCurrentAddress']")).sendKeys(yearsAtAddress);
        driver.findElement(By.xpath("//div[@class='col-12 col-md-4']/div[@class='form-group has-danger' and 1]/span[1]/div[@class='select dropdown' and 1]/span[@class='form-control text-truncate' and 1 and @aria-haspopup='true']")).click();
        driver.findElement(By.xpath("//button[text()='Own']")).click();
        Thread.sleep(2000);
//        driver.findElement(By.xpath("//div[11]/div[@class='form-group has-danger' and 1]/span[1]/div[@class='select dropdown' and 1]/span[@class='form-control text-truncate' and 1]")).click();
//        new Actions(driver).sendKeys(Keys.TAB).perform();
//        new Actions(driver).sendKeys(Keys.ENTER).perform();
//
//        new Actions(driver).sendKeys(Keys.TAB).perform();
//        new Actions(driver).sendKeys(Keys.SPACE).perform();


        driver.findElement(By.xpath("//div[2]/form[@class='row' and 1]/div[2]/div[@class='form-group' and 1]/div[1]/div[@class='dropdown' and 1]/div[@id='data-table_filter' and 1]/input[@class='form-control' and 1]"))
                .sendKeys("200 Mannheim");
        driver.findElement(By.xpath("//button[@id='dropdown_item_0']")).click();

        driver.findElement(By.xpath("//div[2]/form[@class='row' and 1 and @name='Generated']/div[@class='col-12 col-md-4' and 7]/div[@class='form-group' and 1]/input[@class='form-control' and 1 and @name='YearsAtCurrentAddress']"))
                .sendKeys("11");

        driver.findElement(By.xpath("//div[2]/form[@class='row' and 1 and @name='Generated']/div[@class='col-12 col-md-4' and 9]/div[@class='form-group' and 1]/span[1]/div[@class='select dropdown' and 1]/span[@class='form-control text-truncate' and 1]"))
                .click();
        driver.findElement(By.xpath("//div[@class='dropdown-menu show']/button[@class='dropdown-item' and 2 and @value='Rent']")).click();
        driver.findElement(By.xpath("//div[@class='col-12 col-md-8']/div[@class='form-group' and 1]/input[@class='form-control' and 1 and @value='0']")).sendKeys("1234");
        driver.findElement(By.xpath("//div[2]/form[@class='row' and 1 and @name='Generated']/div[@class='col-12 col-md-12' and 11]/div[@class='form-group' and 1]/span[1]/div[@class='select dropdown' and 1]/span[@class='form-control text-truncate' and 1]")).click();
        new Actions(driver).sendKeys(Keys.TAB).perform();
        new Actions(driver).sendKeys(Keys.TAB).perform();
        new Actions(driver).sendKeys(Keys.ENTER).perform();

        //contact info

        driver.findElement(By.xpath("//div[2]/div[@class='collapse show' and 2]/div[@class='card-block' and 1]/div[1]/form[@class='row' and 1 and @name='Generated']/div[@class='col-12 col-md-12' and 6]/div[@class='form-group has-danger' and 1]/span[1]/div[@class='select dropdown' and 1]/span[@class='form-control text-truncate' and 1]"))
                .click();
        new Actions(driver).sendKeys(Keys.TAB).perform();
        new Actions(driver).sendKeys(Keys.ENTER).perform();

        driver.findElement(By.xpath("//div[2]/div[@class='collapse show' and 2]/div[@class='card-block' and 1]/button[@class='btn btn-link' and 1]")).click();
        driver.findElement(By.xpath("//div[2]/form[@class='row' and 1 and @name='Generated']/div[3]/div[@class='form-group' and 1]/input[@class='form-control' and 1]")).sendKeys(Keys.TAB);
        new Actions(driver).sendKeys(coBorrowerCellPhone).perform();
        driver.findElement(By.xpath("//div[2]/form[@class='row' and 1 and @name='Generated']/div[@class='col-12 col-md-3' and 5]/div[@class='form-group' and 1]/input[@class='form-control' and 1 and @name='EmailAddress']"))
                .sendKeys(coBorrowerEmailAddress);

        Thread.sleep(2000);
        driver.findElement(By.xpath("//div[2]/form[@class='row' and 1 and @name='Generated']/div[@class='col-12 col-md-12' and 6]/div[@class='form-group' and 1]/span[1]/div[@class='select dropdown' and 1]/span[@class='form-control text-truncate' and 1]"))
                .click();
        new Actions(driver).sendKeys(Keys.TAB).perform();
        new Actions(driver).sendKeys(Keys.TAB).perform();
        new Actions(driver).sendKeys(Keys.ENTER).perform();

        //employment
        driver.findElement(By.xpath("//div[5]/div[@class='collapse show' and 2]/div[@class='card-block' and 1]/div[1]/form[@class='row' and 1 and @name='Generated']/div[2]/div[@class='form-group has-danger' and 1]/span[1]/div[@class='select dropdown' and 1]/span[@class='form-control text-truncate' and 1]"))
                .click();
        new Actions(driver).sendKeys(Keys.TAB).perform();
        new Actions(driver).sendKeys(Keys.ENTER).perform();

        driver.findElement(By.xpath("//input[@name='EmployerName']"))
                .sendKeys(employerName);
        driver.findElement(By.xpath("//div[5]/div[@class='form-group has-danger' and 1]/input[@class='form-control form-control-danger' and 1]"))
                .sendKeys("5179879878");
        driver.findElement(By.xpath("//input[@name='JobStartDate']"))
                .sendKeys(employmentStartYear);
        driver.findElement(By.xpath("//input[@name='JobStartDate']"))
                .sendKeys(Keys.TAB);
        driver.findElement(By.xpath("//input[@name='JobStartDate']"))
                .sendKeys("0101");
        driver.findElement(By.xpath("//input[@name='PositionTitle']"))
                .sendKeys(employmentPosition);

        Thread.sleep(2000);

        driver.findElement(By.xpath("//input[@name='PositionTitle']")).sendKeys(Keys.TAB);
        new Actions(driver).sendKeys("12000").perform();

        Thread.sleep(2000);

        new Actions(driver).sendKeys(Keys.TAB).perform();
        new Actions(driver).sendKeys(Keys.TAB).perform();
        new Actions(driver).sendKeys(Keys.TAB).perform();
        new Actions(driver).sendKeys(Keys.TAB).perform();
        new Actions(driver).sendKeys(Keys.TAB).perform();
        new Actions(driver).sendKeys(Keys.TAB).perform();
        new Actions(driver).sendKeys(Keys.SPACE).perform();

        Thread.sleep(2000);

        //other debts
        driver.findElement(By.xpath("//div[6]/div[@class='form-group has-danger' and 1]/span[1]/div[@class='select dropdown' and 1]/span[@class='form-control text-truncate' and 1]"))
                .click();
        new Actions(driver).sendKeys(Keys.TAB).perform();
        new Actions(driver).sendKeys(Keys.ENTER).perform();

        //declaration
        driver.findElement(By.xpath("//div[15]/div[@class='form-group has-danger' and 1]/span[1]/div[@class='select dropdown' and 1]/span[@class='form-control text-truncate' and 1]"))
                .click();
        new Actions(driver).sendKeys(Keys.TAB).perform();
        new Actions(driver).sendKeys(Keys.ENTER).perform();

        driver.findElement(By.xpath("//div[8]/div[@class='collapse show' and 2]/div[@class='card-block' and 1]/button[@class='btn btn-link' and 1]")).click();
        Thread.sleep(3000);
        driver.findElement(By.xpath("//div[8]/div[@class='collapse show' and 2]/div[@class='card-block' and 1]/div[2]/form[@class='row' and 1 and @name='Generated']/div[@class='col-12 col-md-12' and 15]/div[@class='form-group' and 1]/span[1]/div[@class='select dropdown' and 1]/span[@class='form-control text-truncate' and 1]")).click();
        new Actions(driver).sendKeys(Keys.TAB).perform();
        new Actions(driver).sendKeys(Keys.TAB).perform();
        new Actions(driver).sendKeys(Keys.ENTER).perform();

        //property info
        driver.findElement(By.xpath("//div[@class='col-12 col-md-12']/div[@class='form-group has-danger' and 1]/span[1]/div[@class='select dropdown' and 1]/span[@class='form-control text-truncate' and 1]"))
                .click();
        driver.findElement(By.xpath("//button[@value='Condo']"))
                .click();
        driver.findElement(By.xpath("//*[@name='Generated']/div[8]/div[1]/span[1]/div[1]/*[1]"))
                .click();
        driver.findElement(By.xpath("//*[text()='(FL) Alachua']"))
                .click();


//        driver.findElement(By.xpath("//div[11]/div[@class='collapse show' and 2]/div[@class='card-block' and 1]/div[1]/form[@class='row' and 1 and @name='Generated']/div[2]/div[@class='form-group' and 1]/input[@class='form-control' and 1]"))
//                .sendKeys(loanAmount);
//        driver.findElement(By.xpath("//div[11]/div[2]/div[1]/div[1]/form[@name='Generated' and 1]/div[4]/div[1]/span[1]/div[1]/*[1]"))
//                .click();
//        driver.findElement(By.xpath("//*[text()='Purchase']"))
//                .click();
//        driver.findElement(By.xpath("//div[11]/div[2]/div[1]/div[1]/form[@name='Generated' and 1]/div[5]/div[1]/span[1]/div[1]/*[1]"))
//                .click();
//        driver.findElement(By.xpath("//*[text()='Primary Home']"))
//                .click();
//
//        driver.findElement(By.xpath("//div[12]/div[2]/div[1]/div[1]/form[@name='Generated' and 1]/*[2]/*[1]/input[@type='text' and 1]"))
//                .sendKeys(downPaymentPercentage);
//
//        driver.findElement(By.xpath("//div[12]/div[2]/div[1]/div[1]/form[@name='Generated' and 1]/div[4]/div[1]/span[1]/div[1]/*[1]"))
//                .click();
//        driver.findElement(By.xpath("//*[text()='At Least 20% Down']"))
//                .click();
//        driver.findElement(By.xpath("//div[12]/div[2]/div[1]/div[1]/form[@name='Generated' and 1]/div[5]/div[1]/span[1]/div[1]/*[1]"))
//                .click();
//        driver.findElement(By.xpath("//*[text()='Low Costs, High Rate']"))
//                .click();
//        clickSaveChanges();
//        Thread.sleep(3000);
        driver.findElement(By.xpath("//div[11]/div[2]/div[1]/div[1]/form[@name='Generated' and 1]/div[2]/div[1]/input[@type='text' and 1]"))
                .sendKeys(loanAmount);
        driver.findElement(By.xpath("//div[11]/div[2]/div[1]/div[1]/form[@name='Generated' and 1]/div[4]/div[1]/span[1]/div[1]/*[1]"))
                .click();
        driver.findElement(By.xpath("//*[text()='Purchase']"))
                .click();
        driver.findElement(By.xpath("//div[11]/div[2]/div[1]/div[1]/form[@name='Generated' and 1]/div[5]/div[1]/span[1]/div[1]/*[1]"))
                .click();
        driver.findElement(By.xpath("//*[text()='Primary Home']"))
                .click();

        driver.findElement(By.xpath("//div[12]/div[2]/div[1]/div[1]/form[@name='Generated' and 1]/*[2]/*[1]/input[@type='text' and 1]"))
                .sendKeys(downPaymentPercentage);

        driver.findElement(By.xpath("//div[12]/div[2]/div[1]/div[1]/form[@name='Generated' and 1]/div[4]/div[1]/span[1]/div[1]/*[1]"))
                .click();
        driver.findElement(By.xpath("//*[text()='At Least 20% Down']"))
                .click();
        driver.findElement(By.xpath("//div[12]/div[2]/div[1]/div[1]/form[@name='Generated' and 1]/div[5]/div[1]/span[1]/div[1]/*[1]"))
                .click();
        driver.findElement(By.xpath("//*[text()='Low Costs, High Rate']"))
                .click();
        clickSaveChanges();
        Thread.sleep(5000);
    }

    public void clickSubmitApplication() throws Exception
    {
        driver.findElement(By.xpath("//*[text()='Submit Application']")).click();
    }

    public void clickBidsNavItem() throws Exception
    {
        elementUtil.waitForElementToBeDisplayed(driver.findElement(By.xpath("//a[text()='Bids']")));
        driver.findElement(By.xpath("//a[text()='Bids']")).click();
    }

    public void clickAddLoanOfficer() throws Exception
    {
        Thread.sleep(2000);
        driver.findElement(By.xpath("//span[@class='bg-blue btn btn--action']")).click();
    }

    public void addLoanOfficerDetails(String firstName, String lastName, String emailAddress, String phoneNumber, String company) throws  Exception
    {
        Thread.sleep(2000);
        driver.findElement(By.xpath("//input[@name='firstName']")).sendKeys(firstName);
        driver.findElement(By.xpath("//input[@name='lastName']")).sendKeys(lastName);
        driver.findElement(By.xpath("//input[@name='emailAddress']")).sendKeys(emailAddress);
        driver.findElement(By.xpath("//input[@name='emailAddress']")).sendKeys(Keys.TAB);
        new Actions(driver).sendKeys(phoneNumber).perform();
        driver.findElement(By.xpath("//input[@name='companyName']")).sendKeys(company);

        Thread.sleep(2000);
        driver.findElement(By.xpath("//button[@class='d-flex  justify-content-start btn btn-primary']")).click();
        Thread.sleep(2000);
    }
}
