package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import util.DatabaseUtil;
import util.ElementUtil;
import util.EnvironmentReader;

public class OperatorPage {

    private WebDriver driver;
    private static ElementUtil elementUtil = new ElementUtil();
    private static EnvironmentReader fileReader = new EnvironmentReader();
    private static String baseUrl = fileReader.getOperatorUrl();
    private static String adminNav = baseUrl + "/secure/operator/admin/batch/list";
    private static String discountNav = baseUrl + "/secure/operator/discounts/discount-offer-flow.est?execution=e2s1";

    public OperatorPage(WebDriver driver, String loginUrl){

        this.driver=driver;
        driver.get(baseUrl);
        //Initialise Elements
        PageFactory.initElements(driver,this);
    }

    @FindBy(xpath="//input[@name='j_username']")
    private WebElement username_field;

    @FindBy(xpath="//input[@name='j_password']")
    private WebElement password_field;

    @FindBy(xpath="//input[@name='submit']")
    private WebElement submit_button;

    @FindBy(xpath="//div/input[1 and @type='text']")
    private WebElement filter_feld;

    @FindBy(xpath="//input[@value='run']")
    private WebElement run_button;

    @FindBy(xpath = "//span[@id='button-actButton1-btnInnerEl']")
    private WebElement createDiscountOffer_button;

    @FindBy(xpath = "//div[1]/div[@class='uitkFields' and 2]/div[1]/div[@class='uitkSeparateEntry required' and 1]/input[@class='textInput' and 1]")
    private WebElement offerNamme_field;

    @FindBy(xpath = "//div[2]/div[@class='uitkFields' and 2]/div[1]/div[@class='uitkSeparateEntry required' and 1]/input[@class='textInput' and 1]")
    private WebElement brainTreeDiscountId;

    @FindBy(xpath = "//div[3]/div[@class='uitkFields' and 2]/div[1]/div[@class='uitkSeparateEntry required' and 1]/select[@class='uitkSelect' and 1]")
    private WebElement fromMembershipType_dropdown;

    @FindBy(xpath = "//div[4]/div[@class='uitkFields' and 2]/div[1]/div[@class='uitkSeparateEntry required' and 1]/select[@class='uitkSelect' and 1]")
    private WebElement toMembershipType_dropdown;

    @FindBy(xpath = "//div[@class='uitkSeparateEntry']/input[2]")
    private WebElement offerEnabled_chkbox;

    @FindBy(xpath = "//span[text()='Add / Update']")
    private WebElement addUpdate_button;

    public void signInOperator()
    {
        username_field.clear();
        username_field.sendKeys("rmanuel@estalea.com");
        password_field.clear();
        password_field.sendKeys("terramatrix");
        submit_button.click();
    }

    public void runOperatorJob(String filterText, String email) throws Exception
    {
        DatabaseUtil util = new DatabaseUtil();
        driver.navigate().to(adminNav);
        filterJobView(filterText);
        run_button.click();

        Integer count = 0;
        while (util.getMemberInstructionStatus(email).equals("PENDING"))
        {
            count = count + 1;
            Thread.sleep(5000);
            System.out.println(count);
            if (count==5)
            {
                break;
            }
        }
    }

    private void filterJobView(String filterText) throws Exception
    {
        elementUtil.waitForElement(driver, filter_feld);
        filter_feld.clear();
        filter_feld.sendKeys(filterText);
    }

    public void addDiscount()
    {
        driver.navigate().to(discountNav);
        if (!driver.getPageSource().contains("test1"))
        {
            createDiscountOffer_button.click();
            offerNamme_field.sendKeys("test1");
            brainTreeDiscountId.sendKeys("test1");
            Select dropdownFromMemberType = new Select(fromMembershipType_dropdown);
            dropdownFromMemberType.selectByVisibleText("ESSENTIAL");
            Select dropdownToMemberType = new Select(toMembershipType_dropdown);
            dropdownToMemberType.selectByVisibleText("PREMIUM");
            offerEnabled_chkbox.click();
            addUpdate_button.click();
        } else {
            System.out.println("Test1 id already exists");
        }
    }
}
