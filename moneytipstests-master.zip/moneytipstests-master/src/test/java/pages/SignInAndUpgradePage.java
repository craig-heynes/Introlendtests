package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import util.ElementUtil;
import util.EnvironmentReader;

public class SignInAndUpgradePage {

    private WebDriver driver;
    private static ElementUtil util = new ElementUtil();
    private static EnvironmentReader fileReader = new EnvironmentReader();
    private static String baseUrl = fileReader.getApplicationUrl();
    private static String PAGE_URL= baseUrl;

    public SignInAndUpgradePage(WebDriver driver, String url){
        this.driver=driver;
        driver.get(PAGE_URL + url);
        //Initialise Elements
        PageFactory.initElements(driver, this);
    }

    @FindBy(id="login")
    private WebElement linkSignIn;

    @FindBy(id="j_username")
    private WebElement usernamefield;

    @FindBy(id="j_password")
    private WebElement passwordfield;

    @FindBy(xpath="//input[@class='btn btn-primary']")
    private WebElement btnSignIn;

    //@FindBy(xpath = "//*[@class='col-xs-3 col-sm-4 col-md-3 no-left-padding top-padding-small text-right']/div[1]/div[@class='header-actions' and 1]/div[@class='row top-margin-small' and 1]/div[@class='col-xxs-7 col-xs-8 col-sm-9 col-lg-10 no-left-padding text-right']/div[@class='member-profile-type hidden-xs' and 1]/*[@class='hidden-xs' and 1]")
    @FindBy(xpath = "//*[3]/div[1 and @class='header-actions']/div[1 and @class='row top-margin-small']/div[1 and @class='col-xxs-7 col-xs-8 col-sm-9 col-lg-10 no-left-padding text-right']/div[1 and @class='member-profile-type hidden-xs']")
    private WebElement linkUpgrade;

    @FindBy(xpath = "//div[@class='membership']/a[@class='btn btn-blue' and 1]")
    private WebElement btnUpgradeToPremium;

    @FindBy(xpath = "//div[@class='membership']/a[@class='btn btn-yellow' and 1]")
    private WebElement btnUpgradeToElite;

    @FindBy(id="credit-card-number")
    private WebElement credit_card_num;

    @FindBy(id="cvv")
    private WebElement credit_card_cvv;

    @FindBy(id="expiration")
    private WebElement credit_card_expiry_date;

    @FindBy(id="postal-code")
    private WebElement credit_card_zip;

    @FindBy(xpath="//*[@name='addCreditCardForm']/*/*[@type='submit']")
    private WebElement btnViewScoreIdProtect;

    @FindBy(xpath = "//h1[text()='Offer Expired']")
    private WebElement offerExpiredTitle;

    @FindBy(xpath = "//div[@class='col-xs-12 offer-expired']/h2[1]")
    private WebElement offerExpiredText;

    public void clickSignInLink(){
        linkSignIn.click();
    }

    public void setSignInCred(String username, String password) throws Exception{
        Thread.sleep(5000);
        usernamefield.clear();
        usernamefield.sendKeys(username);

        passwordfield.clear();
        passwordfield.sendKeys(password);
    }

    public void clickBtnSignIn() throws Exception{
        btnSignIn.click();
        Thread.sleep(10000);
    }

    public void clickUpgradeLink()throws Exception{
        linkUpgrade.click();
        Thread.sleep(5000);
    }

    public void clickBtnUpgradeToPremium()throws Exception{
        util.waitForElement(driver, btnUpgradeToPremium);
        util.scrollToElement(driver, btnUpgradeToPremium);

        btnUpgradeToPremium.click();

        Thread.sleep(5000);
    }

    public void clickBtnUpgradeToElite()throws Exception{
        util.waitForElement(driver,btnUpgradeToElite);
        util.scrollToElement(driver,btnUpgradeToElite);

        btnUpgradeToElite.click();

        Thread.sleep(5000);
    }

    public void setCreditCardDetails(String cardNumber, String cardCVV, String cardExpiryDate, String cardZipCode) throws Exception{

        WebElement iframe = driver.findElement(By.xpath("//*[@title='Secure Credit Card Frame - Credit Card Number']"));
        util.waitForElement(driver,iframe);

        //switch to credit card number iframe and submit text

        driver.switchTo().frame(iframe);
        credit_card_num.clear();
        credit_card_num.sendKeys(cardNumber);
        driver.switchTo().defaultContent();

        //switch to cvv iframe and submit text
        iframe = driver.findElement(By.xpath("//*[@title='Secure Credit Card Frame - CVV']"));
        driver.switchTo().frame(iframe);
        credit_card_cvv.clear();
        credit_card_cvv.sendKeys(cardCVV);
        driver.switchTo().defaultContent();

        //switch to expiry date iframe and submit text
        iframe = driver.findElement(By.xpath("//*[@title='Secure Credit Card Frame - Expiration Date']"));
        driver.switchTo().frame(iframe);
        credit_card_expiry_date.clear();
        credit_card_expiry_date.sendKeys(cardExpiryDate);
        driver.switchTo().defaultContent();

        //switch to zipcode iframe and submit text
        iframe = driver.findElement(By.xpath("//*[@title='Secure Credit Card Frame - Postal Code']"));
        driver.switchTo().frame(iframe);
        credit_card_zip.clear();
        credit_card_zip.sendKeys(cardZipCode);
        driver.switchTo().defaultContent();
    }

    public void clickBtnIDProtect()throws Exception{
        btnViewScoreIdProtect.click();

        while (driver.getCurrentUrl().contains("upgrade")){
            Thread.sleep(1000);
        }
    }

    public String getOfferExpiredTitle()
    {
        return offerExpiredTitle.getText();
    }

    public String getOfferExpiredText()
    {
        return offerExpiredText.getText();
    }
}
