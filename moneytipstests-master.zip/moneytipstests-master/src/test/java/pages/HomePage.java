package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import util.ElementUtil;
import util.EnvironmentReader;

public class HomePage {

    private WebDriver driver;

    ElementUtil util = new ElementUtil();

    private static EnvironmentReader fileReader = new EnvironmentReader();
    private static String baseUrl = fileReader.getApplicationUrl();
    private static String PAGE_URL= baseUrl;

    public HomePage(WebDriver driver, String loginUrl){
        this.driver=driver;
        driver.get(PAGE_URL + loginUrl);
        //Initialise Elements
        PageFactory.initElements(driver, this);
    }

    @FindBy(id="login")
    private WebElement signIn_link;

    @FindBy(id="j_username")
    private WebElement email_field;

    @FindBy(id="j_password")
    private WebElement password_field;

    @FindBy(xpath="//input[@class='btn btn-primary']")
    private WebElement signIn_button;

    @FindBy(xpath="//div[@class='col-xs-4 col-sm-4 col-md-3 no-left-padding top-padding-small text-right']/div[@class='header-actions' and 1]/div[@class='row top-margin-small' and 1]/div[@class='col-xxs-5 col-xs-4 col-sm-3 col-lg-2 no-left-padding text-left pointer' and @onclick='upright.site.component.memberMenuActions()']/div[@class='member' and 1]")
    private WebElement profileDropDown_link;

    @FindBy(xpath = "//div[@class='relative animated slideInDown']/ul[@class='list-unstyled scrolly' and 1]/li[3]/a[1 and @href='/secure/membership-billing']")
    private WebElement memberbilling_link;

    @FindBy(xpath="//a[text()='cancel your membership']")
    private WebElement cancel_link;

    @FindBy(xpath="//a[text()='downgrade']")
    private WebElement downgrade_link;

    @FindBy(id="nav-credit-manager")
    private WebElement creditManagerNav_button;

    @FindBy(xpath="//a[@id='nav-home-purchaser']")
    private WebElement homePurchaseNav_button;


    @FindBy(xpath = "//div[1]/div[@class='field-message' and 2]/p[1]")
    private WebElement emailInvalidMessage;

    @FindBy(xpath = "//div[2]/div[@class='field-message' and 2]/p[1]")
    private WebElement passwordInvalidMessage;

    public void signInMember(String emailAddress, String password) throws Exception{
        util.waitForElement(driver, signIn_link);
        signIn_link.click();
        email_field.clear();
        Thread.sleep(5000);
        email_field.sendKeys(emailAddress);
        password_field.clear();
        password_field.sendKeys(password);
        signIn_button.click();
        Thread.sleep(10000);
    }

    public void navigateToMemberBilling() throws Exception
    {
        util.waitForElement(driver, profileDropDown_link);
        profileDropDown_link.click();
        util.waitForElement(driver, memberbilling_link);
        memberbilling_link.click();
    }

    public void navigateToDashboard() throws Exception
    {
//        driver.navigate().to(baseUrl);
        util.waitForElement(driver, profileDropDown_link);
    }

    public void navigateToCreditManager() throws Exception{
        creditManagerNav_button.click();
        Thread.sleep(3000);
    }

    public void navigateToHomePurchaser() throws Exception{
        homePurchaseNav_button.click();
        Thread.sleep(3000);
    }

    public String getInvalidEmailText()
    {
        return emailInvalidMessage.getText();
    }

    public String getInvalidPasswordText()
    {
        return passwordInvalidMessage.getText();
    }
}
