package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import util.ElementUtil;

public class DocuSignPage {

    private WebDriver driver;
    private static ElementUtil elementUtil = new ElementUtil();

    public DocuSignPage(WebDriver driver){
        this.driver=driver;
        PageFactory.initElements(driver, this);
    }

    public void signDocuments() throws Exception
    {
        driver.findElement(By.xpath("//label[@class='cb_label']")).click();
        Thread.sleep(3000);
        driver.findElement(By.xpath("//button[@id='action-bar-btn-continue']")).click();

        Thread.sleep(5000);
        driver.findElement(By.xpath("//button[@id='navigate-btn']")).click();
        Thread.sleep(3000);
        driver.findElement(By.cssSelector(".tab-image")).click();
        Thread.sleep(4000);
        driver.findElement(By.xpath("//*[text()='Adopt and Sign']")).click();
        Thread.sleep(6000);
        driver.findElement(By.xpath("//button[@id='action-bar-btn-finish']")).click();
        Thread.sleep(10000);
    }

}
