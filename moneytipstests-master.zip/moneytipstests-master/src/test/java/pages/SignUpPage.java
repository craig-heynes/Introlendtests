package pages;

import data.QuestionAnswerData;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import util.DatabaseUtil;
import util.ElementUtil;
import util.EnvironmentReader;

import java.util.ArrayList;
import java.util.Map;

public class SignUpPage {

    private WebDriver driver;
    private static ElementUtil util = new ElementUtil();
    private static EnvironmentReader fileReader;
    private static String baseUrl;
    private static String PAGE_URL;

    DatabaseUtil databaseUtil = new DatabaseUtil();

    public SignUpPage(WebDriver driver, String planType) throws Exception
    {
        fileReader =  new EnvironmentReader();

        baseUrl = fileReader.getApplicationUrl();

        if (baseUrl.contains("9443"))
        {
            databaseUtil.setClientKeyToNull("18ce9851-2df2-4486-b4b0-2d4900212551");
        }

        PAGE_URL = baseUrl + "/credit-manager/sign-up?planType=";
        this.driver=driver;
        driver.get(PAGE_URL+planType);
        //Initialise Elements
        PageFactory.initElements(driver, this);
    }

    //Step One during Sign Up

    @FindBy(id="firstName")
    private WebElement first_name;

    @FindBy(id="lastName")
    private WebElement last_name;

    @FindBy(id="email")
    private WebElement email_address;

//    @FindBy(id="password")
    @FindBy(xpath = "//input[@name='password']")
    private WebElement password_field;

    @FindBy(xpath="//div[@class='section-submit relative']/input[@class='btn btn-primary']")
    private WebElement btnNextStepOne;

    //Step Two during Sign Up

//    @FindBy(id="address")
    @FindBy(xpath = "//input[@name='address']")
    private WebElement street_address;

    @FindBy(id="zip")
    private WebElement zip_code;

    @FindBy(id="phoneNumber")
    private WebElement phone_number;

    @FindBy(id="dateOfBirth")
    private WebElement date_of_birth;

    @FindBy(id="socialSecurityNumber")
    private WebElement social_security_num;

    @FindBy(xpath="//div[@class='section-submit relative']/input[@class='btn btn-primary' and 1]")
    private WebElement btnNextStepTwo;


    //Step Three during Sign Up IDMA page
    //question one and radio buttons

    @FindBy(xpath="//*[1]/h2[1]")
    private WebElement ccm_question_one;

    @FindBy(xpath="//label[@for='question-0-answer-0']")
    private WebElement ccmQuestionOneAnswerOne;

    @FindBy(xpath="//label[@for='question-0-answer-1']")
    private WebElement ccmQuestionOneAnswerTwo;

    @FindBy(xpath="//label[@for='question-0-answer-2']")
    private WebElement ccmQuestionOneAnswerThree;

    @FindBy(xpath="//label[@for='question-0-answer-3']")
    private WebElement ccmQuestionOneAnswerFour;

    @FindBy(xpath="//label[@for='question-0-answer-4']")
    private WebElement ccmQuestionOneAnswerFive;

    //question two and radio buttons

    @FindBy(xpath="//*[2]/h2[1]")
    private WebElement ccm_question_two;

    @FindBy(xpath="//label[@for='question-1-answer-0']")
    private WebElement ccmQuestionTwoAnswerOne;

    @FindBy(xpath="//label[@for='question-1-answer-1']")
    private WebElement ccmQuestionTwoAnswerTwo;

    @FindBy(xpath="//label[@for='question-1-answer-2']")
    private WebElement ccmQuestionTwoAnswerThree;

    @FindBy(xpath="//label[@for='question-1-answer-3']")
    private WebElement ccmQuestionTwoAnswerFour;

    @FindBy(xpath="//label[@for='question-1-answer-4']")
    private WebElement ccmQuestionTwoAnswerFive;

    //question three and radio buttons

    @FindBy(xpath="//*[3]/h2[1]")
    private WebElement ccm_question_three;

    @FindBy(xpath="//label[@for='question-2-answer-0']")
    private WebElement ccmQuestionThreeAnswerOne;

    @FindBy(xpath="//label[@for='question-2-answer-1']")
    private WebElement ccmQuestionThreeAnswerTwo;

    @FindBy(xpath="//label[@for='question-2-answer-2']")
    private WebElement ccmQuestionThreeAnswerThree;

    @FindBy(xpath="//label[@for='question-2-answer-3']")
    private WebElement ccmQuestionThreeAnswerFour;

    @FindBy(xpath="//label[@for='question-2-answer-4']")
    private WebElement ccmQuestionThreeAnswerFive;

    //question three and radio buttons

    @FindBy(xpath="//*[4]/h2[1]")
    private WebElement ccm_question_four;

    @FindBy(xpath="//label[@for='question-3-answer-0']")
    private WebElement ccmQuestionFourAnswerOne;

    @FindBy(xpath="//label[@for='question-3-answer-1']")
    private WebElement ccmQuestionFourAnswerTwo;

    @FindBy(xpath="//label[@for='question-3-answer-2']")
    private WebElement ccmQuestionFourAnswerThree;

    @FindBy(xpath="//label[@for='question-3-answer-3']")
    private WebElement ccmQuestionFourAnswerFour;

    @FindBy(xpath="//label[@for='question-3-answer-4']")
    private WebElement ccmQuestionFourAnswerFive;

    //checkbox + get report button

    @FindBy(xpath="//label[@class='agree-terms']")
    private WebElement i_agree_check;

    @FindBy(xpath="//*[@value='Retrieve Report']")
    private WebElement btnGetReport;

    //credit card page
    @FindBy(id="credit-card-number")
    private WebElement credit_card_num;

    @FindBy(id="cvv")
    private WebElement credit_card_cvv;

    @FindBy(id="expiration")
    private WebElement credit_card_expiry_date;

    @FindBy(id="postal-code")
    private WebElement credit_card_zip;

    @FindBy(xpath="//*[@name='addCreditCardForm']/*/*[@type='submit']")
    private WebElement btnViewScoreIdProtect;

    @FindBy(xpath="//div[@class='error-notification']/p[1]")
    private WebElement ssnNineErrorMessage;

    public void setStepOneFields(String firstName, String lastName, String emailAddress, String password) throws InterruptedException
    {
        first_name.clear();
        first_name.sendKeys(firstName);

        last_name.clear();
        last_name.sendKeys(lastName);

        email_address.clear();
        email_address.sendKeys(emailAddress);

        Thread.sleep(2000);

        password_field.clear();
        password_field.sendKeys(password);
    }

    public void clickBtnNextStepOne(String firstName, String lastName, String emailAddress, String password) throws Exception
    {
        if (btnNextStepOne.isEnabled()) {
            btnNextStepOne.click();
        } else  {
            setStepOneFields(firstName, lastName, emailAddress, password);
            btnNextStepOne.click();
        }
    }

    public void setStepTwoFields(String address, String zipCode, String phoneNumber, String dateOfBirth, String social_security_Four) throws  Exception{

        util.waitForElementToBeDisplayed(street_address);

        street_address.clear();
        street_address.sendKeys(address);

        zip_code.clear();
        zip_code.sendKeys(zipCode);

        phone_number.clear();
        phone_number.sendKeys(phoneNumber);

        date_of_birth.clear();
        date_of_birth.sendKeys(dateOfBirth);

        social_security_num.clear();
        social_security_num.sendKeys(social_security_Four);
    }

    public  void setStepTwoSSNNine (String social_security_nine) throws Exception{
        if (!fileReader.getApplicationUrl().contains("9443")) {
            WebElement ssnNineLabel = driver.findElement(By.xpath("//div[@class='error-notification']/p[1]"));

            while (!ssnNineLabel.isDisplayed()) {
                Thread.sleep(1000);
            }

            social_security_num.sendKeys(social_security_nine);
        }
    }

    public void clickBtnNextStepTwo() throws Exception{
        Thread.sleep(2000);
        util.scrollToElement(driver,btnNextStepTwo);
        util.waitForElement(driver,btnNextStepTwo);
        btnNextStepTwo.click();
    }

    public void clickBtnNextAfterSsn9StepTwo() throws Exception
    {
        if (!fileReader.getApplicationUrl().contains("9443")) {
            util.waitForElement(driver, social_security_num);
            util.waitForElement(driver, btnNextStepTwo);
            util.scrollToElement(driver, btnNextStepTwo);
            btnNextStepTwo.click();
        }
    }

    public void setCorrectAnswersToQuestionsOneToThree() throws Exception
    {
        boolean elementExists = false;

        util.waitForElement(driver,ccm_question_one);

        while ((!ccm_question_one.isDisplayed()) && (!elementExists))
        {
            try{
                if (ccm_question_one.isDisplayed())
                {
                    elementExists = true;
                }
            }
            catch (NoSuchElementException e){
                Thread.sleep(1000);
            }
        }

        selectAndSetAnswer(setListofAnswers(ccmQuestionOneAnswerOne, ccmQuestionOneAnswerTwo, ccmQuestionOneAnswerThree,
                ccmQuestionOneAnswerFour, ccmQuestionOneAnswerFive), ccm_question_one, getPossibleAnswers(ccm_question_one));

        util.waitForElement(driver,ccm_question_two);
        util.scrollToElement(driver,ccm_question_two);
        selectAndSetAnswer(setListofAnswers(ccmQuestionTwoAnswerOne, ccmQuestionTwoAnswerTwo, ccmQuestionTwoAnswerThree,
                ccmQuestionTwoAnswerFour, ccmQuestionTwoAnswerFive), ccm_question_two, getPossibleAnswers(ccm_question_two));

        util.waitForElement(driver,ccm_question_three);
        util.scrollToElement(driver,ccm_question_three);
        selectAndSetAnswer(setListofAnswers(ccmQuestionThreeAnswerOne, ccmQuestionThreeAnswerTwo, ccmQuestionThreeAnswerThree,
                ccmQuestionThreeAnswerFour, ccmQuestionThreeAnswerFive), ccm_question_three, getPossibleAnswers(ccm_question_three));

        if (fileReader.getApplicationUrl().contains("9443"))
        {
            this.setCorrectAnswersToQuestionsFour();
        }
    }

    public void setCorrectAnswersToQuestionsFour() throws  Exception {
//        util.waitForElement(driver, ccmQuestionFourAnswerOne);
        util.scrollToElement(driver, ccm_question_four);
        selectAndSetAnswer(setListofAnswers(ccmQuestionFourAnswerOne, ccmQuestionFourAnswerTwo, ccmQuestionFourAnswerThree,
                ccmQuestionFourAnswerFour, ccmQuestionFourAnswerFive), ccm_question_four, getPossibleAnswers(ccm_question_four));
    }

    public void clickBtnGetIDProtect() throws Exception{
        util.waitForElement(driver,btnViewScoreIdProtect);
        btnViewScoreIdProtect.click();
//        WebDriverWait wait = new WebDriverWait(driver,30);
//        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//div[@class='main']/h1[1]")));
        while (!driver.getCurrentUrl().contains("identity"))
        {
            Thread.sleep(5000);
        }
    }

    public void clickIAgreeCheck() throws Exception
    {
        util.waitForElement(driver,i_agree_check);
        i_agree_check.click();
    }

    public void clickBtnGetReport() throws Exception{
        util.waitForElement(driver,btnGetReport);
        btnGetReport.click();

        while (!driver.getCurrentUrl().contains("verify")){
            Thread.sleep(5000);
        }
    }

    private ArrayList<String> getPossibleAnswers(WebElement ccmQuestion)
    {
        QuestionAnswerData qaMap = new QuestionAnswerData();

        ArrayList<String> possibleAnswers=new ArrayList<>();

        for(Map.Entry<String, ArrayList<String>> entry : qaMap.getQuestionAnswer().entrySet()) {
            String key = entry.getKey();

            if (key.equalsIgnoreCase(ccmQuestion.getText())) {

                possibleAnswers = entry.getValue();

                return possibleAnswers;
            }
        }

        return possibleAnswers;
    }

    private void selectAndSetAnswer(ArrayList<WebElement> answersToSelectFrom, WebElement ccmQuestion, ArrayList<String> answers) throws Exception{

        for (WebElement element:answersToSelectFrom) {
            for (String answer:answers
                    ) {
                if ((answer.equalsIgnoreCase(element.getText()))) {
                    util.waitForElement(driver,element);
                    element.click();
                    return;
                }
            }
        }
    }

    private ArrayList<WebElement> setListofAnswers(WebElement answerOne, WebElement answerTwo, WebElement answerThree,
                                                   WebElement answerFour, WebElement answerFive){

        ArrayList<WebElement> ccmQuestionAnswers = new ArrayList<>();
        ccmQuestionAnswers.add(answerOne);
        ccmQuestionAnswers.add(answerTwo);
        ccmQuestionAnswers.add(answerThree);
        ccmQuestionAnswers.add(answerFour);
        ccmQuestionAnswers.add(answerFive);

        return ccmQuestionAnswers;
    }

}
