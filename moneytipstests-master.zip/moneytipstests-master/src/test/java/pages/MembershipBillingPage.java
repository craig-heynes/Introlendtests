package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import util.ElementUtil;

public class MembershipBillingPage {

    private WebDriver driver;
    ElementUtil elementUtil = new ElementUtil();

    public MembershipBillingPage(WebDriver driver)
    {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath="//a[text()='cancel your membership']")
    private WebElement cancel_link;

    @FindBy(xpath="//div[@class='cancel-options']/a[@class='btn btn-primary' and 1]")
    private WebElement no_dont_cancel_btn;

    @FindBy(xpath="//div[@class='cancel-options']/a[@class='btn btn-primary' and 1]/..//a[@class='btn btn-default']")
    private WebElement yes_cancel_btn;

    @FindBy(xpath="//a[text()='Cancel Account']")
    private WebElement cancel_account_btn;

    @FindBy(xpath="//label[text()='Missing features I need']")
    private WebElement missing_features_radiobtn;

    public void cancelMemberShip() throws Exception
    {
        elementUtil.waitForElement(driver, cancel_link);
        cancel_link.click();
        elementUtil.waitForElement(driver, yes_cancel_btn);
        yes_cancel_btn.click();
        missing_features_radiobtn.click();
        cancel_account_btn.click();
        Thread.sleep(10000);
    }

    public void dismissCancelModalEssentialMember() throws Exception
    {
        elementUtil.waitForElement(driver, cancel_link);
        cancel_link.click();
        elementUtil.waitForElement(driver, no_dont_cancel_btn);
        no_dont_cancel_btn.click();
    }

    public void downgradePremiumMember() throws Exception
    {
        elementUtil.waitForElement(driver, cancel_link);
        cancel_link.click();
        elementUtil.waitForElement(driver, no_dont_cancel_btn);
        no_dont_cancel_btn.click();
        elementUtil.waitForElement(driver, cancel_link);
    }
}
