package pages;

import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import util.ElementUtil;

public class CreditManagerPage {

    private WebDriver driver;
    private static ElementUtil util = new ElementUtil();
//    private static ConfigFileReader fileReader = new ConfigFileReader();
//    private static String baseUrl = fileReader.getApplicationUrl();
//    private static String PAGE_URL= baseUrl;

    public CreditManagerPage(WebDriver driver){
        this.driver=driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath="//a[@class='btn btn-secondary']")
    private WebElement threeBPurchase_button;

    @FindBy(id="credit-card-number")
    private WebElement credit_card_num;

    @FindBy(id="cvv")
    private WebElement credit_card_cvv;

    @FindBy(id="expiration")
    private WebElement credit_card_expiry_date;

    @FindBy(id="postal-code")
    private WebElement credit_card_zip;

    @FindBy(xpath = "//div[@class='section-submit']/input[@class='btn btn-primary' and 1]")
    private WebElement submitCardForPurchase_button;

    @FindBy(xpath="//a[@class='btn btn-secondary']")
    private WebElement viewThreeBReport_button;

    @FindBy(xpath = "//img[@class='lgo-transunion']")
    private WebElement transunion_button;

    @FindBy(xpath = "//img[@class='lgo-equifax']")
    private WebElement equifax_button;

    @FindBy(xpath = "//img[@class='lgo-experian']")
    private WebElement experian_button;

    @FindBy(xpath = "//a[@class='btn btn-default btn-compare']")
    private WebElement update3BReport_button;

    @FindBy(xpath = "//a[text()='Go to Home']")
    private WebElement goToHome_button;

    //CreditScore
    @FindBy(xpath = "//span[@class='ico-dashboard-icon']")
    private WebElement creditScoreSideNav;

    @FindBy(xpath = "//div[@id='credit-score']")
    private WebElement creditScore_field;

    @FindBy(xpath = "//div[@class='refresh-text col-xs-12']/span[1]")
    private WebElement creditRefreshDate_field;

    @FindBy(xpath = "//li[@class='average']")
    private WebElement creditScoreState_field;

    //Better Credit

    @FindBy(xpath = "//span[@class='ico-ln-bettercredit']")
    private WebElement betterCreditSideNav;

    @FindBy(xpath = "//li[@class='active main-tab']")
    private WebElement creditCardUsageTab;

    @FindBy(xpath = "//div[@class='perc']")
    private WebElement creditCardUsagePercentage_field;

    @FindBy(xpath = "//h3[@class='tab-heading']")
    private WebElement tabHeading;

    @FindBy(xpath = "//div[@class='info-container']/span[@class='info-text currency' and 1]/span[@class='info-text-val' and 1]")
    private WebElement availableLimit_field;

    @FindBy(xpath = "//div[@class='info-container more-padding']/span[@class='info-text currency' and 1]/span[@class='info-text-val' and 1]")
    private WebElement totalBalance_field;

    //On Time

    @FindBy(xpath = "//li[@id='on-time']")
    private WebElement onTimePaymentPercentage;

    @FindBy(xpath = "//div[1]/div[1 and @class='info-container']/span[1 and @class='info-text']/span[1 and @class='info-text-val']")
    private WebElement totalPayments_field;

    @FindBy(xpath = "//span[@id='on-time-total']")
    private WebElement onTimePayments_field;

    //Total Accounts

    @FindBy(xpath = "//div[1]/p[1 and @class='type-amount']")
    private WebElement autoAccountsCount;

    @FindBy(xpath = "//div[2]/p[1 and @class='type-amount']")
    private WebElement creditCardsCount;

    @FindBy(xpath = "//div[3]/p[1 and @class='type-amount']")
    private WebElement mortgageCount;

    @FindBy(xpath = "//div[4]/p[1 and @class='type-amount']")
    private WebElement otherAccountsCount;

    @FindBy(xpath = "//p[@class='number-accounts']")
    private WebElement totalAccounts;

    @FindBy(xpath = "//span[@class='open-accounts']")
    private WebElement totalOpenAccounts;

    @FindBy(xpath = "//span[@class='closed-accounts']")
    private WebElement totalClosedAccounts;


    public void navigateToThreeBPurchase() throws Exception
    {
        threeBPurchase_button.click();
        Thread.sleep(3000);
    }

    public void completeThreeBPurchase() throws Exception
    {
        submitCardForPurchase_button.click();
        Thread.sleep(15000);
    }

    public void viewThreeBReport() throws Exception
    {
        viewThreeBReport_button.click();
        Thread.sleep(3000);
    }

    public void update3BReport() throws Exception
    {
        util.scrollToElement(driver,update3BReport_button);
        update3BReport_button.click();
        Thread.sleep(3000);
    }


    public Boolean getGoToHomeBbuttonPresence()
    {
        try{

            if (goToHome_button.isDisplayed());
            {return true;}
        }
        catch (NoSuchElementException e){
            return false;
        }
    }

    public Boolean get3BbuttonPresence()
    {
        try{

            if (transunion_button.isDisplayed());
            {return true;}
        }
        catch (NoSuchElementException e){
            return false;
        }
    }
}
