package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import util.ElementUtil;
import util.EnvironmentReader;

public class TMMSignUpPage {

    private WebDriver driver;

    ElementUtil util = new ElementUtil();

    private static EnvironmentReader fileReader = new EnvironmentReader();
    private static String baseUrl = fileReader.getApplicationUrl();
    private static String PAGE_URL= baseUrl + "/credit-manager/sign-up/";

    public TMMSignUpPage(WebDriver driver, String tmmurl){
        this.driver=driver;
//        driver.get(PAGE_URL+tmmurl);
        //Initialise Elements
        PageFactory.initElements(driver, this);
    }

    @FindBy(id="birthYear")
    private WebElement field_birthYear;

    @FindBy(id="password")
    private WebElement field_password;

    @FindBy(xpath = "//button[@id='identity-btn']")
    private WebElement btn_seeReportScore;

    @FindBy(id="ssn1")
    private WebElement ssn9part1;

    @FindBy(id="ssn2")
    private WebElement ssn9part2;

    @FindBy(id="ssn3")
    private WebElement ssn9part3;

    //div[@class='general-error text-center']

    public void setDOB(String birthYear){
        field_birthYear.sendKeys(birthYear);
    }

    public void setSSN4(String ssn4, String password){
        ssn9part3.clear();
        ssn9part3.sendKeys(ssn4);

        field_password.clear();
        field_password.sendKeys(password);
    }

    public void setSSN9(String ssn9)throws Exception{
        Thread.sleep(10000);
        ssn9part1.clear();
        ssn9part1.sendKeys(ssn9.substring(0,3));

        ssn9part2.clear();
        ssn9part2.sendKeys(ssn9.substring(3,5));

        ssn9part3.clear();
        ssn9part3.sendKeys(ssn9.substring(5,9));
    }

    public void clickBtnGetProtect(){
        btn_seeReportScore.click();
    }
}
