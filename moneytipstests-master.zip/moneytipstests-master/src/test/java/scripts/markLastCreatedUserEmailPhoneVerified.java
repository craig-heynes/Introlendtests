package scripts;

import org.testng.annotations.Test;
import util.DatabaseUtil;

public class markLastCreatedUserEmailPhoneVerified
{
    DatabaseUtil util = new DatabaseUtil();

    @Test
    public void d_executeDestPrepareScript() throws Exception
    {
        util.setLastCreatedUserEmailPhoneVerified();
    }
}
