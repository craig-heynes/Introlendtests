package scripts;

import org.testng.annotations.Test;
import util.DatabaseUtil;

public class executeDestPrepareScript
{
    DatabaseUtil util = new DatabaseUtil();

    @Test
    public void d_executeDestPrepareScript() throws Exception
    {
        util.executeDestPrepare();
    }
}
