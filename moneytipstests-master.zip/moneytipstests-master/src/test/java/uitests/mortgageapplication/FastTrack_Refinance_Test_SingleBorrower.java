package uitests.mortgageapplication;

import apitests.ApiAutoLogin1;
import apitests.ApiMemberCreate;
import data.ApiData;
import data.GlobalVariables;
import data.IntroLendRequestBuilder;
import helperutil.IntroLendHelper;
import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.MortgageApplicationPage;
import uitests.base.BaseTestBeforeMethod;
import uitests.base.CreateEssentialMember;
import uitests.docusign.DocuSignTest;
import util.DatabaseUtil;
import util.EnvironmentReader;
import util.LoggingDatabaseUtil;
import util.UrlBuilder;

import java.util.Map;
import java.util.UUID;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class FastTrack_Refinance_Test_SingleBorrower extends BaseTestBeforeMethod
{
    EnvironmentReader fileReader = new EnvironmentReader();
    IntroLendRequestBuilder  requestBuilder = new IntroLendRequestBuilder();
    ApiMemberCreate memberCreate;
    CreateEssentialMember essentialMember;
    HomePage homePage;
    MortgageApplicationPage mortgageApplicationPage;
    LoggingDatabaseUtil loggingDbUtil = new LoggingDatabaseUtil();
    DatabaseUtil dbutil = new DatabaseUtil();

    String emailToLogin = "";
    String passwordToLogin;
    String baseUri = fileReader.getApiBaseUri();
    String endpoint = "/members";
    String loanApplicationId;

    String authToken;
    UrlBuilder getLoginUrl = new UrlBuilder();
    String clientKeyUsed;
    String planTypeUsed;
    String redirectUrlUsed = "/mortgage-application";
    IntroLendHelper introLendHelper = new IntroLendHelper();

    @Test(dataProviderClass = ApiData.class, dataProvider = "createApplicantEmailAddress")
    public void a_getApplicationId(String emailAddress, String token) throws Exception
    {
        emailToLogin = emailAddress;

        RequestSpecification request = RestAssured.given();
        request.header("Content-Type", "application/json");
        request.header("x-requestid", UUID.randomUUID());
        request.header("Authorization", "Bearer " + token);

        request.body(requestBuilder.getMemberCreateRequestForAgentWithAddress(emailAddress, "Refinance").toJSONString());

        Response response = request.post("https://lending-api-dev.avenu.io/api/v1/Mortgage");

        JsonPath jsonPathEvaluator = response.jsonPath();
        loanApplicationId = jsonPathEvaluator.get("applicationID");
        int statusCode = response.getStatusCode();

        Assert.assertEquals(200,statusCode);

        System.out.println("Application ID: " + loanApplicationId);
    }

    @Test(dataProviderClass = ApiData.class, dataProvider = "createEssentialMemberForFastTrack")
    public void b_createMemberForApplication(String emailAddress, String password, String visitorId, String firstName, String lastName,
                                      String address, String zipCode, String dateOfBirth, String phoneNumber,
                                      String ssn9, String planType, String redirectUrl, Boolean doThreeBTest, String a, String b, String c) throws Exception
    {
        redirectUrlUsed = "/mortgage-application";

        memberCreate = new ApiMemberCreate(getDriver());
        memberCreate.memberCreateForClientKey(firstName, lastName, emailToLogin, password, address,
                zipCode, phoneNumber, dateOfBirth, "1234", ssn9, "fakecard", "fakecvv",
                "fakeexpiry", "fakezipcode");

        String clientKey = loggingDbUtil.getClientKeyForApiEnroll();

        System.out.println("Client Key = " + clientKey);

        RequestSpecification requestEnroll = RestAssured.given();
        requestEnroll.header("Content-Type", "application/json");

        requestEnroll.body(requestBuilder.getMemberCreateRequestForIntroLend(emailToLogin, password, visitorId, firstName,
                lastName, address, zipCode, dateOfBirth, phoneNumber, ssn9, planType, redirectUrlUsed, clientKey, loanApplicationId).toJSONString());

        Response response = requestEnroll.post(baseUri + endpoint);

        JsonPath jsonPathEvaluator = response.jsonPath();
        Map<String, String> successResponseMap = jsonPathEvaluator.get("response");
        Object value = successResponseMap.get("authToken");

        authToken = value.toString();
        clientKeyUsed = clientKey;
        planTypeUsed = planType;
        passwordToLogin = password;
    }

    @Test
    public void c_testCreateApplication() throws Exception
    {
        ApiAutoLogin1 login = new ApiAutoLogin1(getDriver(),getLoginUrl.getAutoLoginUrl(planTypeUsed, clientKeyUsed, authToken), redirectUrlUsed);

        if(GlobalVariables.doLogin) {
            login.testLogin();
        }
        else {
            System.exit(1);
        }
        mortgageApplicationPage = new MortgageApplicationPage(getDriver());

        mortgageApplicationPage.addRefiHome("23 Park Ave");
        mortgageApplicationPage.clickSingleApplication();
        mortgageApplicationPage.clickApplicationLoanTerm(30);

        String[] applicationSet = dbutil.getApplicationSetForMember(emailToLogin);

        Assert.assertEquals("REFINANCE", applicationSet[0]);
        Assert.assertEquals(loanApplicationId, applicationSet[1]);

        mortgageApplicationPage.addFinancialAccount("Chase Bank", "2300");
        mortgageApplicationPage.clickStepOneNext();
        mortgageApplicationPage.clickEmployed();
        mortgageApplicationPage.addEmployment("Estalea", "100", "QA", "45 Park Ave", "5173453454",
                "1","2015", "", "","11", "321000");
        mortgageApplicationPage.clickStepTwoNext();
        mortgageApplicationPage.addDeclarations("45 Park", "21", "3210", "12");
        mortgageApplicationPage.clickReviewApplication();

        Assert.assertEquals("REFINANCE", applicationSet[0]);
        Assert.assertEquals(loanApplicationId, applicationSet[1]);

        Assert.assertEquals(loanApplicationId, dbutil.getApplicationIdByULU(emailToLogin));
        Assert.assertTrue(getDriver().getCurrentUrl().contains("mortgage-application-summary"));

        mortgageApplicationPage.clickGetQuotesForPreApprovedIntroLendUser();
        mortgageApplicationPage.selectQuote();

        Assert.assertTrue(getDriver().getCurrentUrl().contains("mortgage-application-quotes"));
    }

    @Test (dataProviderClass = ApiData.class, dataProvider = "createApplicationId")
    public void d_signDocuments(String token) throws Exception
    {
        DocuSignTest docuSignTest = new DocuSignTest(getDriver());
        docuSignTest.d_signDocuments(token, loanApplicationId);
    }

    @Test (dataProviderClass = ApiData.class, dataProvider = "createApplicationId")
    public void e_testCheckDocusignStatus(String token) throws Exception
    {
        homePage = new HomePage(getDriver(), "");
        mortgageApplicationPage = new MortgageApplicationPage(getDriver());
        homePage.signInMember(emailToLogin, passwordToLogin);
        mortgageApplicationPage.clickContinueMortgageApplication();

        Assert.assertTrue(getDriver().getCurrentUrl().contains("quotes"));

        int count = 0;
        while (!introLendHelper.isDocuSignComplete(token, loanApplicationId))
        {
            Thread.sleep(5000);
            count++;
            if (count==5)
            {
                break;
            }
        }

        Assert.assertTrue(mortgageApplicationPage.getLoanOfficerText().contains("is currently working on your quote"));
    }

    @Test (dataProviderClass = ApiData.class, dataProvider = "createApplicationId")
    public void f_loadBids(String token) throws Exception
    {
        RequestSpecification request = RestAssured.given();
        request.header("Authorization", "Bearer " + token);

        Response response = request.get("https://lending-api-dev.avenu.io/api/v1/Mortgage/" + loanApplicationId + "/bids");

        String bidId1 = response.jsonPath().getString("bidID[0]");

        introLendHelper.loadBids1(bidId1, token, loanApplicationId);

        System.out.println(bidId1);
    }

    @Test
    public void g_testBidsLoaded() throws Exception
    {
        homePage = new HomePage(getDriver(), "");
        mortgageApplicationPage = new MortgageApplicationPage(getDriver());
        homePage.signInMember(emailToLogin, passwordToLogin);
        mortgageApplicationPage.clickContinueMortgageApplication();

        Assert.assertTrue(getDriver().getCurrentUrl().contains("quotes"));

        Thread.sleep(15000);

        Assert.assertTrue(mortgageApplicationPage.getBidMonthlyPaymentOfficer1().contains("1,400"));
        Assert.assertTrue(mortgageApplicationPage.getBidInterestRateOfficer1().contains("3.530"));

        Assert.assertEquals(true, mortgageApplicationPage.getSelectQuoteButtonsState().booleanValue());
    }
}
