package uitests.docusign;

import data.ApiData;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import pages.DocuSignPage;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class DocuSignTest
{
    DocuSignPage docuSignPage;
    WebDriver driver;

    public DocuSignTest (WebDriver driver)
    {
        this.driver = driver;
    }

    @Test (dataProviderClass = ApiData.class, dataProvider = "createApplicationId")
    public void d_signDocuments(String token, String loanApplicationId) throws Exception{

        RequestSpecification request = RestAssured.given();
        request.header("Authorization", "Bearer " + token);
        String getUrl = "https://lending-api-dev.avenu.io/api/v1/LoanApplications/" + loanApplicationId + "/docusign";

        Thread.sleep(35000);
        Response response = request.get(getUrl);

        System.out.println(getUrl);
        //writing out urls with status

        String url1 = response.jsonPath().getString("url[0]");
        String status1 = response.jsonPath().getString("status[0]");
        System.out.println(url1 + " " + status1);
        String url2 = response.jsonPath().getString("url[1]");
        String status2 = response.jsonPath().getString("status[1]");
        System.out.println(url2 + " " + status2);
        String url3 = response.jsonPath().getString("url[2]");
        String status3 = response.jsonPath().getString("status[2]");
        if (url3!=null){System.out.println(url3 + " " + status3);}

        Boolean loopResponse = true;

        String urlPosition = "";
        String statusPosition = "";
        String url;
        String status;
        Integer position = 0;

        docuSignPage = new DocuSignPage(driver);

        while (loopResponse) {
            urlPosition = "url[" + position + "]";
            statusPosition = "status[" + position + "]";
            url = response.jsonPath().getString(urlPosition);
            status = response.jsonPath().getString(statusPosition);
            if ((url!=null) && (status.equals("Pending"))) {
                driver.navigate().to(url);
                docuSignPage.signDocuments();
                position++;
            } else {
                loopResponse = false;
            }
        }
    }
}
