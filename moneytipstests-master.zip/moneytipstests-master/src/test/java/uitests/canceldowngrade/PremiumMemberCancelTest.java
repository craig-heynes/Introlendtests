package uitests.canceldowngrade;

import data.ApiData;
import data.OperatorData;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.MembershipBillingPage;
import pages.OperatorPage;
import uitests.base.BaseTestBeforeMethod;
import uitests.base.CreatePremiumMember;
import util.DatabaseUtil;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class PremiumMemberCancelTest extends BaseTestBeforeMethod
{
    CreatePremiumMember premiumMember;
    HomePage homePage;
    MembershipBillingPage billingPage;
    DatabaseUtil util = new DatabaseUtil();
    String emailToLogin;
    String passwordToLogin;

    @Test(dataProviderClass = ApiData.class, dataProvider = "createPremiumMemberForUISignUp")
    public void a_testCreatePremiumMemberToCancel(String emailAddress, String password, String firstName, String lastName, String address,
                                         String zipCode, String dateOfBirth, String phoneNumber, String ssn9,
                                         String cardNumber, String cardCvv, String cardExpiry, String cardZipcode, Boolean doThreeBTest) throws Exception
    {
        premiumMember = new CreatePremiumMember(getDriver());
        premiumMember.testSignUpPremiumThreeQs(emailAddress, password, firstName, lastName, address, zipCode, dateOfBirth,
                phoneNumber, ssn9, cardNumber, cardCvv, cardExpiry, cardZipcode, doThreeBTest);

        util.setMemberMobileNumber(emailAddress);
        util.setEmailPhoneVerified(emailAddress);
//        util.truncateMemberInstruction();

        emailToLogin = emailAddress;
        passwordToLogin = password;

        util.dismissAllBanners(emailAddress);
        util.setLastRefreshDateForMember(emailAddress);
    }

    @Test
    public void b_testMemberCancel() throws Exception
    {
        homePage = new HomePage(getDriver(),"");
        billingPage = new MembershipBillingPage(getDriver());
        homePage.signInMember(emailToLogin,passwordToLogin);
        homePage.navigateToMemberBilling();
        billingPage.cancelMemberShip();

        Assert.assertTrue(!getDriver().getPageSource().contains(emailToLogin));
    }

    @Test
    public void c_testCancelledMemberBanner() throws Exception
    {
        homePage = new HomePage(getDriver(),"");
        billingPage = new MembershipBillingPage(getDriver());
        homePage.signInMember(emailToLogin,passwordToLogin);

        Assert.assertTrue(getDriver().getPageSource().contains("Your Membership has been cancelled."));
        Assert.assertTrue(getDriver().getPageSource().contains("You will have access to your Premium Member membership until the end of the billing cycle at"));
    }

    @Test
    public void d_testExecuteOperatorJob() throws  Exception
    {
        util.setMemberInstructionDateForToday(emailToLogin);
        OperatorPage operatorPage = new OperatorPage(getDriver(),"");
        operatorPage.signInOperator();
        operatorPage.runOperatorJob(OperatorData.MEMBER_INSTRUCTION_JOB, emailToLogin);

        Assert.assertEquals("DONE", util.getMemberInstructionStatus(emailToLogin));
    }

    @Test
    public void e_testMemberBlockedAfterCancel() throws Exception
    {
        homePage = new HomePage(getDriver(),"");
        homePage.signInMember(emailToLogin,passwordToLogin);

        Assert.assertEquals("THE EMAIL ADDRESS YOU ENTERED IS INCORRECT.", homePage.getInvalidEmailText());
        Assert.assertEquals("THE PASSWORD YOU ENTERED IS INCORRECT.", homePage.getInvalidPasswordText());
    }
}
