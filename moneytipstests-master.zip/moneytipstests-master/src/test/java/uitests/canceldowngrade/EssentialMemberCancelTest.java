package uitests.canceldowngrade;

import data.ApiData;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.MembershipBillingPage;
import uitests.base.BaseTestBeforeMethod;
import uitests.base.CreateEssentialMember;
import util.DatabaseUtil;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class EssentialMemberCancelTest extends BaseTestBeforeMethod
{
    CreateEssentialMember essentialMember;
    MembershipBillingPage billingPage;
    DatabaseUtil util = new DatabaseUtil();
    HomePage homePage;

    String emailToLogin;
    String passwordToLogin;

    @Test (dataProviderClass = ApiData.class, dataProvider = "createEssentialMemberForUISignUp")
    public void a_testCreateMemberToCancel(String emailAddress, String password, String firstName, String lastName, String address,
                                         String zipCode, String dateOfBirth,
                                         String phoneNumber, String ssn, Boolean doThreeBTest) throws Exception
    {
        homePage = new HomePage(getDriver(), "");
        essentialMember = new CreateEssentialMember(getDriver());
        essentialMember.testCreateEssentialMember(emailAddress, password, firstName, lastName, address,
                zipCode, dateOfBirth, phoneNumber, ssn, doThreeBTest);
        util.setMemberMobileNumber(emailAddress);
        util.setEmailPhoneVerified(emailAddress);
        homePage.navigateToDashboard();

        emailToLogin = emailAddress;
        passwordToLogin = password;

        util.dismissAllBanners(emailAddress);
        util.setLastRefreshDateForMember(emailAddress);
    }

    @Test
    public void b_testEssentialMemberCancel() throws Exception
    {
        homePage = new HomePage(getDriver(),"");
        billingPage = new MembershipBillingPage(getDriver());
        homePage.signInMember(emailToLogin, passwordToLogin);
        homePage.navigateToMemberBilling();
        billingPage.dismissCancelModalEssentialMember();
        billingPage.cancelMemberShip();

        Assert.assertTrue(!getDriver().getPageSource().contains(emailToLogin));
    }

    @Test
    public void c_testMemberBlockedAfterCancel() throws Exception
    {
        homePage = new HomePage(getDriver(),"");
        homePage.signInMember(emailToLogin,passwordToLogin);

        Assert.assertEquals("THE EMAIL ADDRESS YOU ENTERED IS INCORRECT.", homePage.getInvalidEmailText());
        Assert.assertEquals("THE PASSWORD YOU ENTERED IS INCORRECT.", homePage.getInvalidPasswordText());
    }
}
