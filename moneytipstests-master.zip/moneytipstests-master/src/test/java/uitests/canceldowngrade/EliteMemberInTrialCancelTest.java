package uitests.canceldowngrade;

import data.ApiData;
import data.OperatorData;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.MembershipBillingPage;
import uitests.base.BaseTestBeforeMethod;
import uitests.base.CreateEliteMember;
import util.DatabaseUtil;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class EliteMemberInTrialCancelTest extends BaseTestBeforeMethod
{
    CreateEliteMember eliteMember;
    OperatorData getJob = new OperatorData();
    HomePage homePage;
    MembershipBillingPage billingPage;
    DatabaseUtil util = new DatabaseUtil();

    String emailToLogin;
    String passwordToLogin;

    @Test (dataProviderClass = ApiData.class, dataProvider = "createPremiumMemberForUISignUp")
    public void a_testCreateEliteMemberToCancel(String emailAddress, String password, String firstName, String lastName, String address,
                                         String zipCode, String dateOfBirth, String phoneNumber, String ssn9,
                                         String cardNumber, String cardCvv, String cardExpiry, String cardZipcode, Boolean doThreeBTest) throws Exception
    {
        eliteMember = new CreateEliteMember(getDriver());
        eliteMember.testSignUpEliteThree(emailAddress, password, firstName, lastName, address, zipCode, dateOfBirth, phoneNumber, ssn9,
                 cardNumber, cardCvv, cardExpiry, cardZipcode, doThreeBTest);

        emailToLogin = emailAddress;
        passwordToLogin = password;

//        databaseUtil.truncateMemberInstruction();
        util.dismissAllBanners(emailAddress);
        util.dismissCreditRefreshBanner(emailAddress);
        util.setEmailPhoneVerified(emailAddress);
        util.setMemberMobileNumber(emailAddress);
    }

    @Test
    public void b_testMemberCancel() throws Exception
    {
        homePage = new HomePage(getDriver(),"");
        billingPage = new MembershipBillingPage(getDriver());
        homePage.signInMember(emailToLogin, passwordToLogin);
        homePage.navigateToMemberBilling();
        billingPage.cancelMemberShip();

        Assert.assertTrue(!getDriver().getPageSource().contains(emailToLogin));
    }

    @Test
    public void c_testMemberBlockedAfterCancel() throws Exception
    {
        homePage = new HomePage(getDriver(),"");
        homePage.signInMember(emailToLogin, passwordToLogin);

        Assert.assertEquals("THE EMAIL ADDRESS YOU ENTERED IS INCORRECT.", homePage.getInvalidEmailText());
        Assert.assertEquals("THE PASSWORD YOU ENTERED IS INCORRECT.", homePage.getInvalidPasswordText());
    }
}
