package uitests.canceldowngrade;

import data.ApiData;
import data.OperatorData;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.testng.annotations.Test;
import pages.HomePage;
import pages.MembershipBillingPage;
import uitests.base.BaseTestBeforeMethod;
import uitests.base.CreateEliteMember;
import util.DatabaseUtil;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class EliteMemberInTrialDowngradeTest extends BaseTestBeforeMethod
{
    CreateEliteMember eliteMember;
    OperatorData getJob = new OperatorData();
    HomePage homePage;
    MembershipBillingPage billingPage;
    DatabaseUtil util = new DatabaseUtil();

    String emailToLogin;
    String passwordToLogin;

    @Test (dataProviderClass = ApiData.class, dataProvider = "createPremiumMemberForUISignUp")
    public void a_testCreatePremiumMemberToCancel(String emailAddress, String password, String firstName, String lastName, String address,
                                                String zipCode, String dateOfBirth, String phoneNumber, String ssn9,
                                                String cardNumber, String cardCvv, String cardExpiry, String cardZipcode, Boolean doThreeBTest) throws Exception
    {
        eliteMember = new CreateEliteMember(getDriver());
        eliteMember.testSignUpEliteThree(emailAddress, password, firstName, lastName, address, zipCode, dateOfBirth, phoneNumber, ssn9,
                cardNumber, cardCvv, cardExpiry, cardZipcode, doThreeBTest);

        emailToLogin = emailAddress;
        passwordToLogin = password;

//        databaseUtil.truncateMemberInstruction();
        util.dismissAllBanners(emailAddress);
        util.dismissCreditRefreshBanner(emailAddress);
        util.setEmailPhoneVerified(emailAddress);
        util.setMemberMobileNumber(emailAddress);
    }

    @Test
    public void b_testMemberDowngrade() throws Exception
    {
        homePage = new HomePage(getDriver(),"");
        billingPage = new MembershipBillingPage(getDriver());
        homePage.signInMember(emailToLogin,passwordToLogin);
        homePage.navigateToMemberBilling();

        Assert.assertTrue(getDriver().getPageSource().contains("No billing transactions"));

        billingPage.downgradePremiumMember();

        Thread.sleep(10000);

        Assert.assertEquals("ESSENTIAL", util.getMemberShipType(emailToLogin));
        Assert.assertEquals("ENROLLED", util.getTUEnrollStatus(emailToLogin));
    }

    @Test
    public void c_testMemberDowngradeSuccess() throws Exception
    {
        homePage = new HomePage(getDriver(),"");
        homePage.signInMember(emailToLogin,passwordToLogin);

        Assert.assertTrue(getDriver().getPageSource().contains(emailToLogin));
        Assert.assertEquals("ESSENTIAL", util.getMemberShipType(emailToLogin));
        Assert.assertEquals("ENROLLED", util.getTUEnrollStatus(emailToLogin));
    }
}
