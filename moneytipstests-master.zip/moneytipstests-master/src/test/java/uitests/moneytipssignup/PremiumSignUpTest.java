package uitests.moneytipssignup;

import data.ApiData;
import org.testng.annotations.Test;
import uitests.base.BaseTestBeforeClass;
import uitests.base.CreatePremiumMember;

public class PremiumSignUpTest extends BaseTestBeforeClass
{
    CreatePremiumMember createPremiumMember;

    @Test (dataProviderClass = ApiData.class, dataProvider = "createPremiumMemberForUISignUp")
    public void testSignUpPremiumThreeQs(String emailAddress, String password, String firstName, String lastName, String address,
                                         String zipCode, String dateOfBirth, String phoneNumber, String ssn9,
                                         String cardNumber, String cardCvv, String cardExpiry, String cardZipcode, Boolean doThreeBTest) throws Exception
    {
        createPremiumMember = new CreatePremiumMember(getDriver());
        createPremiumMember.testSignUpPremiumThreeQs(emailAddress, password, firstName, lastName, address, zipCode, dateOfBirth,
                phoneNumber, ssn9, cardNumber, cardCvv, cardExpiry, cardZipcode, doThreeBTest);

        //assert happens in CreatePremiumMember
    }
}

