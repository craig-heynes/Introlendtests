package uitests.moneytipssignup;

import data.ApiData;
import org.testng.annotations.Test;
import uitests.base.BaseTestBeforeClass;
import uitests.base.CreateEssentialMember;

public class EssentialSignUpTest extends BaseTestBeforeClass
{
    CreateEssentialMember essentialMember;

    @Test (dataProviderClass = ApiData.class, dataProvider = "createEssentialMemberForUISignUp")
    public void testSignUpEssentialThreeQ(String emailAddress, String password, String firstName, String lastName, String address,
                                          String zipCode, String dateOfBirth,
                                          String phoneNumber, String ssn, Boolean doThreeBTest) throws Exception
    {
        essentialMember = new CreateEssentialMember(getDriver());
        essentialMember.testCreateEssentialMember(emailAddress, password, firstName, lastName, address, zipCode, dateOfBirth,
                phoneNumber, ssn, doThreeBTest);

        //Assert happens in CreateEssentialMember
    }
}

