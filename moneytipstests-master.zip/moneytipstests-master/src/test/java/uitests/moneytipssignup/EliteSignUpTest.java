package uitests.moneytipssignup;

import data.ApiData;
import org.testng.annotations.Test;
import uitests.base.BaseTestBeforeClass;
import uitests.base.CreateEliteMember;

public class EliteSignUpTest extends BaseTestBeforeClass
{
    CreateEliteMember eliteMember;

    @Test(dataProviderClass = ApiData.class, dataProvider = "createPremiumMemberForUISignUp")
    public void testSignUpEliteThree(String emailAddress, String password, String firstName, String lastName, String address,
                                     String zipCode, String dateOfBirth, String phoneNumber, String ssn9,
                                     String cardNumber, String cardCvv, String cardExpiry, String cardZipcode, Boolean doThreeBTest) throws Exception
    {
        eliteMember = new CreateEliteMember(getDriver());
        eliteMember.testSignUpEliteThree(emailAddress, password, firstName, lastName, address,
                 zipCode, dateOfBirth, phoneNumber, ssn9, cardNumber, cardCvv, cardExpiry, cardZipcode, doThreeBTest);

        //Assert happens in CreateEliteMember
    }
}

