package uitests.moneytipssignup;

import data.ApiData;
import data.SignUpData;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.testng.annotations.Test;
import pages.CreditCardHostedFieldsPage;
import pages.OperatorPage;
import pages.SignInAndUpgradePage;
import uitests.base.BaseTestBeforeMethod;
import uitests.base.CreateEssentialMember;
import util.DatabaseUtil;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class EssentialDiscountedPremiumUpgradeTest extends BaseTestBeforeMethod
{
    CreateEssentialMember essentialMember;
    SignInAndUpgradePage signInAndUpgradePage;
    CreditCardHostedFieldsPage creditCardHostedFieldsPage;
    DatabaseUtil util = new DatabaseUtil();

    String emailToLogin;
    String passwordToLogin;

    @Test(dataProviderClass = ApiData.class, dataProvider = "createEssentialMemberForUISignUp")
    public void a_testCreatePremiumMemberToUpgrade(String emailAddress, String password, String firstName, String lastName, String address,
                                                 String zipCode, String dateOfBirth,
                                                 String phoneNumber, String ssn, Boolean doThreeBTest) throws Exception
    {
        essentialMember = new CreateEssentialMember(getDriver());
        essentialMember.testCreateEssentialMember(emailAddress, password, firstName, lastName, address,
                zipCode, dateOfBirth, phoneNumber, ssn, doThreeBTest);

        util.setEmailPhoneVerified(emailAddress);

        emailToLogin = emailAddress;
        passwordToLogin = password;
    }

    @Test
    public void b_createDiscount()
    {
        OperatorPage operatorPage = new OperatorPage(getDriver(),"");
        operatorPage.signInOperator();
        operatorPage.addDiscount();
    }

    @Test (dataProviderClass = SignUpData.class, dataProvider = "validCardInfo")
    public void c_upgradeEssentialToDiscountedPremiumTest(String cardNum, String cardCvv, String cardExpiry, String cardZipCode) throws Exception
    {
        int endIndex = util.getPromotionUrl("test1").length();

        signInAndUpgradePage = new SignInAndUpgradePage(getDriver(), util.getPromotionUrl("test1").substring(28,endIndex));
        creditCardHostedFieldsPage = new CreditCardHostedFieldsPage(getDriver());
        signInAndUpgradePage.setSignInCred(emailToLogin, passwordToLogin);
        signInAndUpgradePage.clickBtnSignIn();

        System.out.println(creditCardHostedFieldsPage.getDiscountedAmount());

        Assert.assertEquals("9.95/MO", creditCardHostedFieldsPage.getDiscountedAmount());

        creditCardHostedFieldsPage.setCreditCardDetails(cardNum, cardCvv, cardExpiry, cardZipCode);
        signInAndUpgradePage.clickBtnIDProtect();

        Assert.assertEquals("PREMIUM", util.getMemberShipType(emailToLogin));
        Assert.assertEquals("ENROLLED", util.getTUEnrollStatus(emailToLogin));
        Assert.assertEquals("ENROLLED", util.getExperianEnrollStatus(emailToLogin));
    }

    @Test
    public void d_ExpiredEssentialToDiscountedPremiumTest() throws Exception
    {
        signInAndUpgradePage = new SignInAndUpgradePage(getDriver(),  "/secure/member/upgrade/init?planType=PREMIUM&discountId=test-2");
        creditCardHostedFieldsPage = new CreditCardHostedFieldsPage(getDriver());
        signInAndUpgradePage.setSignInCred("freecredit1@gmail.com", "terramatrix");
        signInAndUpgradePage.clickBtnSignIn();

        Assert.assertTrue(getDriver().getCurrentUrl().contains("offerExpired=true"));
        Assert.assertTrue(signInAndUpgradePage.getOfferExpiredTitle().contains("OFFER EXPIRED"));
        Assert.assertTrue(signInAndUpgradePage.getOfferExpiredText().contains("Sorry this offer has expired."));
    }
}
