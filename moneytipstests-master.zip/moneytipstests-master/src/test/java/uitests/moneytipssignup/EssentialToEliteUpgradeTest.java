package uitests.moneytipssignup;

import data.ApiData;
import data.SignUpData;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.testng.annotations.Test;
import pages.CreditCardHostedFieldsPage;
import pages.SignInAndUpgradePage;
import uitests.base.BaseTestBeforeMethod;
import uitests.base.CreateEssentialMember;
import util.DatabaseUtil;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class EssentialToEliteUpgradeTest extends BaseTestBeforeMethod
{
    CreateEssentialMember essentialMember;
    DatabaseUtil util = new DatabaseUtil();
    SignInAndUpgradePage signInAndUpgradePage;
    CreditCardHostedFieldsPage creditCardHostedFieldsPage;

    String emailToLogin;
    String passwordToLogin;

    @org.testng.annotations.Test(dataProviderClass = ApiData.class, dataProvider = "createEssentialMemberForUISignUp")
    public void a_testCreateEliteMemberToUpgrade(String emailAddress, String password, String firstName, String lastName, String address,
                                                 String zipCode, String dateOfBirth,
                                                 String phoneNumber, String ssn, Boolean doThreeBTest) throws Exception
    {
        essentialMember = new CreateEssentialMember(getDriver());
        essentialMember.testCreateEssentialMember(emailAddress, password, firstName, lastName, address,
                zipCode, dateOfBirth, phoneNumber, ssn, doThreeBTest);

        util.setEmailPhoneVerified(emailAddress);

        emailToLogin = emailAddress;
        passwordToLogin = password;
    }

    @Test (dataProviderClass = SignUpData.class, dataProvider = "validCardInfo")
    public void b_upgradeEssentialToEliteTest(String cardNum, String cardCvv, String cardExpiry, String cardZipCode) throws Exception
    {
        signInAndUpgradePage = new SignInAndUpgradePage(getDriver(), "");
        creditCardHostedFieldsPage = new CreditCardHostedFieldsPage(getDriver());
        signInAndUpgradePage.clickSignInLink();
        signInAndUpgradePage.setSignInCred(emailToLogin, passwordToLogin);
        signInAndUpgradePage.clickBtnSignIn();
        signInAndUpgradePage.clickUpgradeLink();
        signInAndUpgradePage.clickBtnUpgradeToElite();
        creditCardHostedFieldsPage.setCreditCardDetails(cardNum, cardCvv, cardExpiry, cardZipCode);
        signInAndUpgradePage.clickBtnIDProtect();

        Assert.assertEquals("ELITE", util.getMemberShipType(emailToLogin));
        Assert.assertEquals("ENROLLED", util.getTUEnrollStatus(emailToLogin));
        Assert.assertEquals("ENROLLED", util.getExperianEnrollStatus(emailToLogin));
    }
}
