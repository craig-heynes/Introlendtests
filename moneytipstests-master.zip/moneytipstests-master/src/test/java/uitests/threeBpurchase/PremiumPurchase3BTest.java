package uitests.threeBpurchase;

import data.ApiData;
import data.SignUpData;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.CreditCardHostedFieldsPage;
import pages.CreditManagerPage;
import pages.HomePage;
import uitests.base.BaseTestBeforeMethod;
import uitests.base.CreatePremiumMember;
import util.DatabaseUtil;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class PremiumPurchase3BTest extends BaseTestBeforeMethod
{
    CreatePremiumMember createPremiumMember;
    DatabaseUtil databaseUtil = new DatabaseUtil();
    HomePage homePage;
    CreditManagerPage creditManagerPage;
    CreditCardHostedFieldsPage creditCardHostedFieldsPage;

    String emailToLogin;
    String passwordToLogin;

    @Test(dataProviderClass = ApiData.class, dataProvider = "createPremiumMemberForUISignUp")
    public void a_testCreatePremiumMemberFor3BPurchase(String emailAddress, String password, String firstName, String lastName, String address,
                                                         String zipCode, String dateOfBirth, String phoneNumber, String ssn9,
                                                         String cardNumber, String cardCvv, String cardExpiry, String cardZipcode, Boolean doThreeBTest) throws Exception
    {
        if (doThreeBTest) {

            homePage = new HomePage(getDriver(), "");

            createPremiumMember = new CreatePremiumMember(getDriver());
            createPremiumMember.testSignUpPremiumThreeQs(emailAddress, password, firstName, lastName, address, zipCode, dateOfBirth,
                    phoneNumber, ssn9, cardNumber, cardCvv, cardExpiry, cardZipcode, doThreeBTest);

            databaseUtil.setMemberMobileNumber(emailAddress);
            databaseUtil.setEmailPhoneVerified(emailAddress);
            homePage.navigateToDashboard();

            databaseUtil.dismissAllBanners(emailAddress);

            emailToLogin = emailAddress;
            passwordToLogin = password;
        }
        else {
            System.out.println("Unable to run 3B Purchase Test, point environment to ccm-stage2");
            System.exit(0);
        }
    }

    @Test
    public void b_test3BUpSellMessage() throws Exception
    {
        homePage = new HomePage(getDriver(),"");
        homePage.signInMember(emailToLogin, passwordToLogin);
        homePage.navigateToCreditManager();

        Assert.assertTrue(getDriver().getPageSource().contains("Check all <span>3</span> reports for"));
        Assert.assertTrue(getDriver().getPageSource().contains("or upgrade to <span>MoneyTips Elite</span> and get all 3-Bureau reports &amp; scores once a month"));
    }

    @Test(dataProviderClass = SignUpData.class, dataProvider = "validCardInfo")
    public void c_test3BPurchase(String cardNum, String cardCvv, String cardExpiry, String cardZipCode) throws Exception
    {
        homePage = new HomePage(getDriver(),"");
        creditManagerPage = new CreditManagerPage(getDriver());
        creditCardHostedFieldsPage = new CreditCardHostedFieldsPage(getDriver());

        homePage.signInMember(emailToLogin, passwordToLogin);
        homePage.navigateToCreditManager();
        creditManagerPage.navigateToThreeBPurchase();
        creditCardHostedFieldsPage.setCreditCardDetails(cardNum, cardCvv, cardExpiry, cardZipCode);
        creditManagerPage.completeThreeBPurchase();

        Assert.assertTrue(getDriver().getPageSource().contains("Order Summary"));
//        Assert.assertTrue(getDriver().getPageSource().contains("Three Bureau Report Purchase"));

        creditManagerPage.viewThreeBReport();

        Assert.assertTrue(getDriver().getCurrentUrl().contains("/credit-manager"));
        Assert.assertTrue(creditManagerPage.get3BbuttonPresence());
    }

    @Test(dataProviderClass = SignUpData.class, dataProvider = "validCardInfo")
    public void d_testPurchase3BAgainWith24hours(String cardNum, String cardCvv, String cardExpiry, String cardZipCode) throws Exception
    {
        homePage = new HomePage(getDriver(),"");
        creditManagerPage = new CreditManagerPage(getDriver());
        creditCardHostedFieldsPage = new CreditCardHostedFieldsPage(getDriver());

        homePage.signInMember(emailToLogin, passwordToLogin);
        homePage.navigateToCreditManager();
        creditManagerPage.update3BReport();
        creditCardHostedFieldsPage.setCreditCardDetails(cardNum, cardCvv, cardExpiry, cardZipCode);
        creditManagerPage.completeThreeBPurchase();

        Assert.assertTrue(creditManagerPage.getGoToHomeBbuttonPresence());
    }
}
