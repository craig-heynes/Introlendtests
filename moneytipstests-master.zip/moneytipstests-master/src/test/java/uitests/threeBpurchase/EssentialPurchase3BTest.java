package uitests.threeBpurchase;

import data.ApiData;
import data.SignUpData;
import org.junit.Assert;
import org.junit.FixMethodOrder;
import org.junit.runners.MethodSorters;
import org.testng.annotations.Test;
import pages.CreditCardHostedFieldsPage;
import pages.CreditManagerPage;
import pages.HomePage;
import uitests.base.BaseTestBeforeMethod;
import uitests.base.CreateEssentialMember;
import util.DatabaseUtil;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class EssentialPurchase3BTest extends BaseTestBeforeMethod
{
    CreateEssentialMember essentialMember;
    DatabaseUtil util = new DatabaseUtil();
    HomePage homePage;
    CreditManagerPage creditManagerPage;
    CreditCardHostedFieldsPage creditCardHostedFieldsPage;

    String emailToLogin;
    String passwordToLogin;

    @Test(dataProviderClass = ApiData.class, dataProvider = "createEssentialMemberForUISignUp")
    public void a_testCreateEssentialMemberFor3BPurchase(String emailAddress, String password, String firstName, String lastName, String address,
                                                 String zipCode, String dateOfBirth,
                                                 String phoneNumber, String ssn, Boolean doThreeBTest) throws Exception
    {
        if (doThreeBTest) {

            homePage = new HomePage(getDriver(), "");

            essentialMember = new CreateEssentialMember(getDriver());
            essentialMember.testCreateEssentialMember(emailAddress, password, firstName, lastName, address,
                    zipCode, dateOfBirth, phoneNumber, ssn, doThreeBTest);

            util.setMemberMobileNumber(emailAddress);
            util.setEmailPhoneVerified(emailAddress);
            homePage.navigateToDashboard();

            util.dismissAllBanners(emailAddress);

            emailToLogin = emailAddress;
            passwordToLogin = password;
        }
        else {
            System.out.println("Unable to run 3B Purchase Test, point environment to ccm-stage2");
            System.exit(0);
        }
    }

    @Test
    public void b_test3BUpSellMessage() throws Exception
    {
        homePage = new HomePage(getDriver(),"");
        homePage.signInMember(emailToLogin, passwordToLogin);
        homePage.navigateToCreditManager();

        Assert.assertTrue(getDriver().getPageSource().contains("Check all <span>3</span> reports for"));
        Assert.assertTrue(getDriver().getPageSource().contains("or upgrade to <span>MoneyTips Elite</span> and get all 3-Bureau reports &amp; scores once a month"));
    }

    @Test(dataProviderClass = SignUpData.class, dataProvider = "validCardInfo")
    public void c_test3BPurchase(String cardNum, String cardCvv, String cardExpiry, String cardZipCode) throws Exception
    {
        homePage = new HomePage(getDriver(),"");
        creditManagerPage = new CreditManagerPage(getDriver());
        creditCardHostedFieldsPage = new CreditCardHostedFieldsPage(getDriver());

        homePage.signInMember(emailToLogin, passwordToLogin);
        homePage.navigateToCreditManager();
        creditManagerPage.navigateToThreeBPurchase();
        creditCardHostedFieldsPage.setCreditCardDetails(cardNum, cardCvv, cardExpiry, cardZipCode);
        creditManagerPage.completeThreeBPurchase();

        Assert.assertTrue(getDriver().getPageSource().contains("Order Summary"));
        Assert.assertTrue(getDriver().getPageSource().contains("Three Bureau Report Purchase"));

        creditManagerPage.viewThreeBReport();

        Assert.assertTrue(getDriver().getCurrentUrl().contains("/credit-manager"));
        Assert.assertTrue(creditManagerPage.get3BbuttonPresence());
    }

    @Test(dataProviderClass = SignUpData.class, dataProvider = "validCardInfo")
    public void d_testPurchase3BAgainWith24hours(String cardNum, String cardCvv, String cardExpiry, String cardZipCode) throws Exception
    {
        homePage = new HomePage(getDriver(),"");
        creditManagerPage = new CreditManagerPage(getDriver());
        creditCardHostedFieldsPage = new CreditCardHostedFieldsPage(getDriver());

        homePage.signInMember(emailToLogin, passwordToLogin);
        homePage.navigateToCreditManager();
        creditManagerPage.update3BReport();
        creditCardHostedFieldsPage.setCreditCardDetails(cardNum, cardCvv, cardExpiry, cardZipCode);
        creditManagerPage.completeThreeBPurchase();

        Assert.assertTrue(creditManagerPage.getGoToHomeBbuttonPresence());
    }
}
