package uitests.base;

import data.GlobalVariables;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import util.DriverFactory;

import java.util.concurrent.TimeUnit;

public class BaseTestBeforeClass
{
    WebDriver driver;

    public WebDriver getDriver()
    {
        return driver;
    }

    @BeforeClass
    public void setup() throws Exception
    {
        driver = DriverFactory.getDriver(DriverFactory.getBrowserTypeByProperty());
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }

    @AfterClass
    public void close()
    {
        if (GlobalVariables.loanApplicationId!=null) {
            System.out.println("Application Id = " + GlobalVariables.loanApplicationId);
        }

        try
        {
            driver.close();
        }
        catch (Exception e)
        {
            System.out.println("Nothing to do with it");
        }

        try
        {
            driver.quit();
        }
        catch (Exception e)
        {
            System.out.println("Nothing to do with it");
        }
    }
}
