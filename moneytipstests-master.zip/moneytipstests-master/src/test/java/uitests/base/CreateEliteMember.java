package uitests.base;

import data.ApiData;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import pages.CreditCardHostedFieldsPage;
import pages.SignUpPage;
import util.DatabaseUtil;

public class CreateEliteMember extends BaseTestBeforeClass
{
    SignUpPage signUpPage;
    CreditCardHostedFieldsPage creditCardHostedFieldsPage;
    DatabaseUtil util = new DatabaseUtil();

    public CreateEliteMember(WebDriver driver){
        this.driver = driver;
    }

    @Test(dataProviderClass = ApiData.class, dataProvider = "createPremiumMemberForUISignUp")
    public void testSignUpEliteThree(String emailAddress, String password, String firstName, String lastName, String address,
                                     String zipCode, String dateOfBirth, String phoneNumber, String ssn9,
                                     String cardNumber, String cardCvv, String cardExpiry, String cardZipcode, Boolean doThreeBTest) throws Exception
    {
        creditCardHostedFieldsPage = new CreditCardHostedFieldsPage(driver);

        signUpPage = new SignUpPage(driver,"elite");
        signUpPage.setStepOneFields(firstName,lastName, emailAddress, password);
        signUpPage.clickBtnNextStepOne(firstName,lastName, emailAddress, password);
        signUpPage.setStepTwoFields(address, zipCode, phoneNumber, dateOfBirth, ssn9);
        signUpPage.clickBtnNextStepTwo();
        signUpPage.setStepTwoSSNNine(ssn9);
        signUpPage.clickBtnNextAfterSsn9StepTwo();
        signUpPage.setCorrectAnswersToQuestionsOneToThree();
        signUpPage.clickIAgreeCheck();
        signUpPage.clickBtnNextStepTwo();
        creditCardHostedFieldsPage.setCreditCardDetails(cardNumber, cardCvv, cardExpiry, cardZipcode);
        signUpPage.clickBtnGetIDProtect();

        System.out.println("Email Address: " + emailAddress);
        System.out.println("Password: " + password);
        System.out.println("Client Key: " + util.getClientKey(emailAddress));

        //assert values in DB
        Assert.assertEquals("ELITE", util.getMemberShipType(emailAddress));
        Assert.assertEquals("ENROLLED", util.getTUEnrollStatus(emailAddress));
        Assert.assertEquals("ENROLLED", util.getExperianEnrollStatus(emailAddress));
    }
}

