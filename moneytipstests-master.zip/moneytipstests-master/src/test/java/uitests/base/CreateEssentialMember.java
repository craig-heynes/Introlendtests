package uitests.base;

import data.ApiData;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;
import pages.SignUpPage;
import util.DatabaseUtil;

public class CreateEssentialMember extends BaseTestBeforeClass
{
    SignUpPage signUpPage;
    DatabaseUtil util = new DatabaseUtil();

    public CreateEssentialMember(WebDriver driver){
       this.driver = driver;
    }

    @Test (dataProviderClass = ApiData.class, dataProvider = "createEssentialMemberForUISignUp")
    public void testCreateEssentialMember(String emailAddress, String password, String firstName, String lastName, String address,
                                                 String zipCode, String dateOfBirth,
                                                 String phoneNumber, String ssn, Boolean doThreeBTest) throws Exception
    {
        signUpPage = new SignUpPage(driver,"essential");
        signUpPage.setStepOneFields(firstName, lastName, emailAddress, password);
        signUpPage.clickBtnNextStepOne(firstName,lastName, emailAddress, password);
        signUpPage.setStepTwoFields(address, zipCode, phoneNumber, dateOfBirth, ssn);
        signUpPage.clickBtnNextStepTwo();
        signUpPage.setStepTwoSSNNine(ssn);
        signUpPage.clickBtnNextAfterSsn9StepTwo();
        signUpPage.setCorrectAnswersToQuestionsOneToThree();
        signUpPage.clickIAgreeCheck();
        signUpPage.clickBtnGetReport();

        System.out.println("Email Address: " + emailAddress);
        System.out.println("Password: " + password);
        System.out.println("Client Key: " + util.getClientKey(emailAddress));

        Assert.assertEquals("ESSENTIAL", util.getMemberShipType(emailAddress));
        Assert.assertEquals("ENROLLED", util.getTUEnrollStatus(emailAddress));
        Assert.assertTrue(driver.getCurrentUrl().contains("secure/verify/essential"));
    }
}

