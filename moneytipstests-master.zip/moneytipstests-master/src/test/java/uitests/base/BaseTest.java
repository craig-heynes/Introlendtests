package uitests.base;

import data.GlobalVariables;
import org.junit.After;
import org.junit.Before;
import org.openqa.selenium.WebDriver;
import util.DatabaseUtil;
import util.DriverFactory;

import java.util.concurrent.TimeUnit;

public class BaseTest {

    public static WebDriver driver;
    public static DatabaseUtil util = new DatabaseUtil();

    @Before
    public void setup() throws Exception
    {
        driver = DriverFactory.getDriver(DriverFactory.getBrowserTypeByProperty());
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }

    @After
    public void close()
    {
        if (GlobalVariables.loanApplicationId!=null) {
            System.out.println("Application Id = " + GlobalVariables.loanApplicationId);
        }

        try {
            driver.close();
        }
        catch (Exception e){
            System.out.println("Nothing to do with it");
        }

        try{
            driver.quit();
        }catch (Exception e){
            System.out.println("Nothing to do with it");
        }
    }
}
