package uitests.base;

import data.GlobalVariables;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import util.DriverFactory;

import java.util.concurrent.TimeUnit;

public class BaseTestBeforeMethod
{
    WebDriver driver;

    public WebDriver getDriver()
    {
        return driver;
    }

    @BeforeMethod
    public void setup() throws Exception
    {
        driver = DriverFactory.getDriver(DriverFactory.getBrowserTypeByProperty());
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }

    @AfterMethod
    public void close()
    {
        if (GlobalVariables.loanApplicationId!=null) {
            System.out.println("Application Id = " + GlobalVariables.loanApplicationId);
        }

        try {
            driver.close();
        }
        catch (Exception e){
            System.out.println("Nothing to do with it");
        }

        try{
            driver.quit();
        }catch (Exception e){
            System.out.println("Nothing to do with it");
        }
    }
}
